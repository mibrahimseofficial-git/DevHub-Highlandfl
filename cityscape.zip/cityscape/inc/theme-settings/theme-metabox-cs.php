<?php
/**
 * Theme Metabox Options
 * @package cityscape
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); // exit if access directly
}

if (class_exists('CSF')) {

    $allowed_html = cityscape()->kses_allowed_html(array('mark'));

    $prefix = 'cityscape';

    /*-------------------------------------
        Post Format Options
    -------------------------------------*/
    CSF::createMetabox($prefix . '_post_video_options', array(
        'title' => esc_html__('Video Post Format Options', 'cityscape'),
        'post_type' => 'post',
        'post_formats' => 'video'
    ));
    CSF::createSection($prefix . '_post_video_options', array(
        'fields' => array(
            array(
                'id' => 'video_url',
                'type' => 'text',
                'title' => esc_html__('Enter Video URL', 'cityscape'),
                'desc' => wp_kses(__('enter <mark>video url</mark> to show in frontend', 'cityscape'), $allowed_html)
            )
        )
    ));
    CSF::createMetabox($prefix . '_post_gallery_options', array(
        'title' => esc_html__('Gallery Post Format Options', 'cityscape'),
        'post_type' => 'post',
        'post_formats' => 'gallery'
    ));
    CSF::createSection($prefix . '_post_gallery_options', array(
        'fields' => array(
            array(
                'id' => 'gallery_images',
                'type' => 'gallery',
                'title' => esc_html__('Select Gallery Photos', 'cityscape'),
                'desc' => wp_kses(__('select <mark>gallery photos</mark> to show in frontend', 'cityscape'), $allowed_html)
            )
        )
    ));
	
	/*-------------------------------------
        listing Format Options
    -------------------------------------*/
    CSF::createMetabox($prefix . '_listing_meta_options', array(
        'title' => esc_html__('Listing Meta Options', 'cityscape'),
        'post_type' => 'at_biz_dir',
    ));
    CSF::createSection($prefix . '_listing_meta_options', array(
        'fields' => array(
            array(
                'id' => 'bed',
                'type' => 'text',
                'title' => esc_html__('Enter bed', 'cityscape'),
                'default' => esc_html__('3 Beds', 'cityscape'),
            ),
            array(
                'id' => 'bath',
                'type' => 'text',
                'title' => esc_html__('Enter bed', 'cityscape'),
                'default' => esc_html__('3 Baths', 'cityscape'),
            ),
        )
    ));

    /*-------------------------------------
      Page Container Options
    -------------------------------------*/
    CSF::createMetabox($prefix . '_page_container_options', array(
        'title' => esc_html__('Page Options', 'cityscape'),
        'post_type' => array('page'),
    ));
    CSF::createSection($prefix . '_page_container_options', array(
        'title' => esc_html__('Layout & Colors', 'cityscape'),
        'icon' => 'fa fa-columns',
        'fields' => Cityscape_Group_Fields::page_layout()
    ));
    CSF::createSection($prefix . '_page_container_options', array(
        'title' => esc_html__('Header Footer & Breadcrumb', 'cityscape'),
        'icon' => 'fa fa-header',
        'fields' => Cityscape_Group_Fields::Page_Container_Options('header_options')
    ));
    CSF::createSection($prefix . '_page_container_options', array(
        'title' => esc_html__('Width & Padding', 'cityscape'),
        'icon' => 'fa fa-file-o',
        'fields' => Cityscape_Group_Fields::Page_Container_Options('container_options')
    ));

    
    //	Service Meta Box
    CSF::createMetabox($prefix . '_service_options', array(
        'title' => esc_html__('Service Options', 'cityscape'),
        'post_type' => 'service',
    ));
    CSF::createSection($prefix . '_service_options', array(
        'fields' => array(
            array(
                'id' => 'service_icon',
                'type' => 'media',
                'title' => esc_html__('Icon', 'cityscape'),
                'desc' => wp_kses(__('Select Your Icon', 'cityscape'), $allowed_html)
            ),
            array(
                'id' => 'service_subtitle',
                'type' => 'text',
                'title' => esc_html__('service subtitle', 'cityscape'),
                'desc' => wp_kses(__('Type Your service subtitle', 'cityscape'), $allowed_html)
            ),
            array(
                'id' => 'service_content',
                'type' => 'textarea',
                'title' => esc_html__('service content', 'cityscape'),
                'desc' => wp_kses(__('Select Your service content', 'cityscape'), $allowed_html)
            ),
        )
    ));

    /*-------------------------------------
     Team Options
    -------------------------------------*/
    CSF::createMetabox($prefix . '_team_options', array(
        'title' => esc_html__('Team Options', 'cityscape'),
        'post_type' => array('team'),
        'priority' => 'high'
    ));
    CSF::createSection($prefix . '_team_options', array(
        'title' => esc_html__('Team Icon', 'cityscape'),
        'id' => 'cityscape-team-icon',
        'fields' => array(
            array(
                'id' => 'team_icon',
                'type' => 'media',
                'title' => esc_html__('Icon', 'cityscape'),
                'desc' => wp_kses(__('Select Your Icon', 'cityscape'), $allowed_html)
            )
        )
    ));
    
    CSF::createSection($prefix . '_team_options', array(
        'title' => esc_html__('Team Info', 'cityscape'),
        'id' => 'cityscape-info',
        'fields' => array(
            array(
                'id' => 'designation',
                'type' => 'text',
                'title' => esc_html__('Designation', 'cityscape'),
            ),
            array(
                'id' => 'description',
                'type' => 'textarea',
                'title' => esc_html__('Description', 'cityscape'),
                'default' => esc_html__('This category focuses on the design and construction of buildings and the This  category focuses on the design and construction of buildings and  arrangement of furniture and decorative elements within themarrangement', 'cityscape'),
            ),
            array(
                'id' => 'description_2',
                'type' => 'textarea',
                'title' => esc_html__('Description Two', 'cityscape'),
                'default' => esc_html__('This category focuses on the design and construction of buildings and the This  category focuses on the design and construction of buildings', 'cityscape'),
            ),
            array(
                'id' => 'team-info',
                'type' => 'repeater',
                'title' => esc_html__('Team Info', 'cityscape'),
                'fields' => array(

                    array(
                        'id' => 'title',
                        'type' => 'text',
                        'title' => esc_html__('Title', 'cityscape')
                    ),
                    array(
                        'id' => 'value',
                        'type' => 'text',
                        'title' => esc_html__('Value', 'cityscape')
                    ),

                ),
            ),
        )
    ));
    CSF::createSection($prefix . '_team_options', array(
        'title' => esc_html__('Social Info', 'cityscape'),
        'id' => 'social-info',
        'fields' => array(
            array(
                'id' => 'social-icons',
                'type' => 'repeater',
                'title' => esc_html__('Social Info', 'cityscape'),
                'fields' => array(

                    array(
                        'id' => 'title',
                        'type' => 'text',
                        'title' => esc_html__('Title', 'cityscape')
                    ),
                    array(
                        'id' => 'icon',
                        'type' => 'icon',
                        'title' => esc_html__('Icon', 'cityscape')
                    ),
                    array(
                        'id' => 'url',
                        'type' => 'text',
                        'title' => esc_html__('URL', 'cityscape')
                    ),

                ),
            ),
        )
    ));

    //	Project Meta Box
    CSF::createMetabox($prefix . '_project_options', array(
        'title' => esc_html__('Project Options', 'cityscape'),
        'post_type' => 'project',
    ));

    CSF::createSection($prefix . '_project_options', array(
        'fields' => array(
            array(
                'id' => 'project_subtitle',
                'type' => 'text',
                'title' => esc_html__('Project Subtitle', 'cityscape'),
                'default' => esc_html__('Development Coaches', 'cityscape'),
            ),
            array(
                'id' => 'project_icon',
                'type' => 'media',
                'title' => esc_html__('Icon', 'cityscape'),
                'desc' => wp_kses(__('Select Your Icon', 'cityscape'), $allowed_html)
            ),
        )
    ));

    //	Event Meta Box
    CSF::createMetabox($prefix . '_event_options', array(
        'title' => esc_html__('Event Options', 'cityscape'),
        'post_type' => 'event',
    ));
    CSF::createSection($prefix . '_event_options', array(
        'fields' => array(
            array(
                'id' => 'event_icon',
                'default' => 'flaticon-protection',
                'type' => 'icon',
                'title' => esc_html__('Icon', 'cityscape'),
                'desc' => wp_kses(__('Select Your Icon', 'cityscape'), $allowed_html)
            ),
            array(
                'id' => 'event_date_option',
                'type' => 'text',
                'title' => esc_html__('Event Date', 'cityscape'),
                'default' => esc_html__('21', 'cityscape'),
            ),
            array(
                'id' => 'event_month_option',
                'type' => 'text',
                'title' => esc_html__('Event Month', 'cityscape'),
                'default' => esc_html__('Feb', 'cityscape'),
            ),
            array(
                'id' => 'event_year_option',
                'type' => 'text',
                'title' => esc_html__('Event Year', 'cityscape'),
                'default' => esc_html__('2024', 'cityscape'),
            ),
            array(
                'id' => 'event_time_option',
                'type' => 'text',
                'title' => esc_html__('Event Time', 'cityscape'),
                'default' => esc_html__('10:00am', 'cityscape'),
            ),
            array(
                'id' => 'event_location_option',
                'type' => 'text',
                'title' => esc_html__('Event Location', 'cityscape'),
                'default' => esc_html__('684 Ann St. FL 34608', 'cityscape'),
            )
        )
    ));

    //	Courses Meta Box
    CSF::createMetabox($prefix . '_courses_options', array(
        'title' => esc_html__('Courses Options', 'cityscape'),
        'post_type' => 'courses',
    ));

    CSF::createSection($prefix . '_courses_options', array(
        'title' => esc_html__('Social Info', 'cityscape'),
        'id' => 'social-info',
        'fields' => array(
            array(
                'id' => 'course_start_date_option',
                'type' => 'text',
                'title' => esc_html__('Start From', 'cityscape'),
                'default' => esc_html__('Thursday, Nov 4, 2024', 'cityscape'),
            ),
            array(
                'id' => 'study-option',
                'type' => 'repeater',
                'title' => esc_html__('Study Options', 'cityscape'),
                'fields' => array(

                    array(
                        'id' => 'qualification',
                        'type' => 'text',
                        'title' => esc_html__('Qualification', 'cityscape'),
                        'default' => esc_html__('Bachelor of Aviation (Hons)', 'cityscape'),
                    ),
                    array(
                        'id' => 'length',
                        'type' => 'text',
                        'title' => esc_html__('Length', 'cityscape'),
                        'default' => esc_html__('9 months full time', 'cityscape'),
                    ),
                    array(
                        'id' => 'code',
                        'type' => 'text',
                        'title' => esc_html__('Code', 'cityscape'),
                        'default' => esc_html__('ba1x', 'cityscape'),
                    ),
                ),
            ),
            array(
                'id' => 'course_module_option',
                'type' => 'text',
                'title' => esc_html__('Course Module Title', 'cityscape'),
                'default' => esc_html__('Download full course Module', 'cityscape'),
            ),
            array(
                'id' => 'course_module_button_title',
                'type' => 'text',
                'title' => esc_html__('Course Module Button Title', 'cityscape'),
                'default' => esc_html__('Download', 'cityscape'),
            ),
            array(
                'id' => 'course_module_button_url',
                'type' => 'text',
                'title' => esc_html__('Course Module Button URL', 'cityscape'),
                'default' => esc_html__('#', 'cityscape'),
            ),
        )
    ));
}//endif