<?php

/**
 * Theme Options
 * @package cityscape
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); // exit if access directly
}
// Control core classes for avoid errors
if (class_exists('CSF')) {

    $allowed_html = cityscape()->kses_allowed_html(array('mark'));
    $prefix = 'cityscape';
    // Create options
    CSF::createOptions($prefix . '_theme_options', array(
        'menu_title' => esc_html__('Theme Options', 'cityscape'),
        'menu_slug' => 'cityscape_theme_options',
        'menu_parent' => 'cityscape_theme_options',
        'menu_type' => 'submenu',
        'footer_credit' => ' ',
        'menu_icon' => 'fa fa-filter',
        'show_footer' => false,
        'enqueue_webfont' => false,
        'show_search' => true,
        'show_reset_all' => true,
        'show_reset_section' => true,
        'show_all_options' => false,
        'theme' => 'dark',
        'framework_title' => cityscape()->get_theme_info('name')
    ));

    /*-------------------------------------------------------
        ** General  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('General', 'cityscape'),
        'id' => 'general_options',
        'icon' => 'fas fa-cogs',
    ));
    /* Preloader */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Preloader & SVG Enable', 'cityscape'),
        'id' => 'theme_general_preloader_options',
        'icon' => 'fa fa-spinner',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Preloader Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'preloader_enable',
                'title' => esc_html__('Preloader', 'cityscape'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to enable/disable preloader', 'cityscape'), $allowed_html),
                'default' => false,
            ),
            array(
                'id' => 'preloader_bg_color',
                'title' => esc_html__('Background Color', 'cityscape'),
                'type' => 'color',
                'default' => '#ffffff',
                'desc' => wp_kses(__('you can set <mark>overlay color</mark> for preloader background image', 'cityscape'), $allowed_html),
                'dependency' => array('preloader_enable', '==', 'true')
            ),
            array(
                'id' => 'enable_svg_upload',
                'type' => 'switcher',
                'title' => esc_html__('Enable Svg Upload ?', 'cityscape'),
                'desc' => esc_html__('If you want to enable or disable svg upload you can set ( YES / NO )', 'cityscape'),
                'default' => false,
            ),
        )
    ));

    /*-------------------------------------------------------
           ** Typography  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'typography',
        'title' => esc_html__('Typography', 'cityscape'),
        'icon' => 'fas fa-text-height',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Body Font Options', 'cityscape') . '</h3>',
            ),
            array(
                'type' => 'typography',
                'title' => esc_html__('Typography', 'cityscape'),
                'id' => '_body_font',
                'default' => array(
                    'font-family' => 'Jost',
                    'font-size' => '16',
                    'line-height' => '26',
                    'unit' => 'px',
                    'type' => 'google',
                ),
                'color' => false,
                'subset' => false,
                'text_align' => false,
                'text_transform' => false,
                'letter_spacing' => false,
                'line_height' => false,
                'desc' => wp_kses(__('you can set <mark>font</mark> for all html tags (if not use different heading font)', 'cityscape'), $allowed_html),
            ),
            array(
                'id' => 'body_font_variant',
                'type' => 'select',
                'title' => esc_html__('Load Font Variant', 'cityscape'),
                'multiple' => true,
                'chosen' => true,
                'options' => array(
                    '300' => esc_html__('Light 300', 'cityscape'),
                    '400' => esc_html__('Regular 400', 'cityscape'),
                    '500' => esc_html__('Medium 500', 'cityscape'),
                    '600' => esc_html__('Semi Bold 600', 'cityscape'),
                    '700' => esc_html__('Bold 700', 'cityscape'),
                    '800' => esc_html__('Extra Bold 800', 'cityscape'),
                ),
                'default' => array('500', '600', '700')
            ),
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Heading Font Options', 'cityscape') . '</h3>',
            ),
            array(
                'type' => 'switcher',
                'id' => 'heading_font_enable',
                'title' => esc_html__('Heading Font', 'cityscape'),
                'desc' => wp_kses(__('you can set <mark>yes</mark> to select different heading font', 'cityscape'), $allowed_html),
                'default' => true
            ),
            array(
                'type' => 'typography',
                'title' => esc_html__('Typography', 'cityscape'),
                'id' => 'heading_font',
                'default' => array(
                    'font-family' => 'Vidaloka',
                    'type' => 'google',
                ),
                'color' => false,
                'subset' => false,
                'text_align' => false,
                'text_transform' => false,
                'letter_spacing' => false,
                'font_size' => false,
                'line_height' => false,
                'desc' => wp_kses(__('you can set <mark>font</mark> for  for heading tag .eg: h1,h2mh3,h4,h5,h6', 'cityscape'), $allowed_html),
                'dependency' => array('heading_font_enable', '==', 'true')
            ),
            array(
                'id' => 'heading_font_variant',
                'type' => 'select',
                'title' => esc_html__('Load Font Variant', 'cityscape'),
                'multiple' => true,
                'chosen' => true,
                'options' => array(
                    '300' => esc_html__('Light 300', 'cityscape'),
                    '400' => esc_html__('Regular 400', 'cityscape'),
                    '500' => esc_html__('Medium 500', 'cityscape'),
                    '600' => esc_html__('Semi Bold 600', 'cityscape'),
                    '700' => esc_html__('Bold 700', 'cityscape'),
                    '800' => esc_html__('Extra Bold 800', 'cityscape'),
                ),
                'default' => array('400', '500', '600', '700'),
                'dependency' => array('heading_font_enable', '==', 'true')
            ),
        )
    ));

    /* Preloader */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Back To Top', 'cityscape'),
        'id' => 'theme_general_back_top_options',
        'icon' => 'fa fa-arrow-up',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Back Top Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'back_top_enable',
                'title' => esc_html__('Back Top', 'cityscape'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to show/hide back to top', 'cityscape'), $allowed_html),
                'default' => true,
            ),
            array(
                'id' => 'back_top_icon',
                'title' => esc_html__('Back Top Icon', 'cityscape'),
                'type' => 'icon',
                'default' => 'fa fa-angle-up',
                'desc' => wp_kses(__('you can set <mark>icon</mark> for back to top.', 'cityscape'), $allowed_html),
                'dependency' => array('back_top_enable', '==', 'true')
            ),
        )
    ));

    /* Preloader */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('sitebar', 'cityscape'),
        'id' => 'theme_general_sitebar_options',
        'icon' => 'fa fa-arrow-up',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Sitebar Option', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'sitebar_logo',
                'type' => 'media',
                'title' => esc_html__('Sitebar Logo', 'cityscape'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'cityscape'), $allowed_html),
            ),
            array(
                'id' => 'sitebar_address',
                'type' => 'text',
                'title' => esc_html__('Sitebar Address', 'cityscape'),
                'default' => esc_html__('Lavaca Street, Suite 2000', 'cityscape'),
            ),
            array(
                'id' => 'sitebar_phone',
                'type' => 'text',
                'title' => esc_html__('Sitebar phone', 'cityscape'),
                'default' => esc_html__('(+880) 172570051', 'cityscape'),
            ),
            array(
                'id' => 'sitebar_phone_2',
                'type' => 'text',
                'title' => esc_html__('Sitebar phone 2', 'cityscape'),
                'default' => esc_html__('(+880) 172570051', 'cityscape'),
            ),
            array(
                'id' => 'sitebar_email',
                'type' => 'text',
                'title' => esc_html__('Sitebar email', 'cityscape'),
                'default' => esc_html__('email@evha.com', 'cityscape'),
            ),
            array(
                'id' => 'sitebar_email_2',
                'type' => 'text',
                'title' => esc_html__('Sitebar email 2', 'cityscape'),
                'default' => esc_html__('email@evha.com', 'cityscape'),
            ),
            array(
                'id' => 'gmap_address',
                'type' => 'text',
                'title' => esc_html__('iframe google map Address', 'cityscape'),
            ),
            array(
                'id' => 'sitebar_facebook',
                'type' => 'text',
                'title' => esc_html__('Sitebar facebook url', 'cityscape'),
                'default' => esc_html__('#', 'cityscape'),
            ),
            array(
                'id' => 'sitebar_twitter',
                'type' => 'text',
                'title' => esc_html__('Sitebar twitter url', 'cityscape'),
                'default' => esc_html__('#', 'cityscape'),
            ),
            array(
                'id' => 'sitebar_instagram',
                'type' => 'text',
                'title' => esc_html__('Sitebar instagram', 'cityscape'),
                'default' => esc_html__('#', 'cityscape'),
            ),
            array(
                'id' => 'sitebar_linkedin',
                'type' => 'text',
                'title' => esc_html__('Sitebar linkedin', 'cityscape'),
                'default' => esc_html__('#', 'cityscape'),
            ),
            array(
                'id' => 'map_enable',
                'title' => esc_html__('map Enable', 'cityscape'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to enable/disable preloader', 'cityscape'), $allowed_html),
                'default' => true,
            ),
        )
    ));

    /*----------------------------------
        Header & Footer Style
    -----------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Set Header & Footer Type', 'cityscape'),
        'id' => 'header_footer_style_options',
        'icon' => 'eicon-banner',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => esc_html__('Global Header Style', 'cityscape'),
            ),
            array(
                'id' => 'navbar_type',
                'title' => esc_html__('Navbar Type', 'cityscape'),
                'type' => 'image_select',
                'options' => array(
                    '' => CITYSCAPE_THEME_SETTINGS_IMAGES . '/header/01.png',
                    'style-01' => CITYSCAPE_THEME_SETTINGS_IMAGES . '/header/02.png',
                    'style-02' => CITYSCAPE_THEME_SETTINGS_IMAGES . '/header/03.png'
                ),
                'default' => '',
                'desc' => wp_kses(__('you can set <mark>navbar type</mark> it will show in every page except you select specific navbar type form page settings.', 'cityscape'), $allowed_html),
            ),
            array(
                'type' => 'subheading',
                'content' => esc_html__('Global Footer Style', 'cityscape'),
            ),
            array(
                'id' => 'footer_type',
                'title' => esc_html__('Footer Type', 'cityscape'),
                'type' => 'image_select',
                'options' => array(
                    '' => CITYSCAPE_THEME_SETTINGS_IMAGES . '/footer/01.png'
                ),
                'default' => '',
                'desc' => wp_kses(__('you can set <mark>footer type</mark> it will show in every page except you select specific navbar type form page settings.', 'cityscape'), $allowed_html),
            ),
        )
    ));

    /* Breadcrumb */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Breadcrumb', 'cityscape'),
        'id' => 'breadcrumb_options',
        'icon' => ' eicon-product-breadcrumbs',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Breadcrumb Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'breadcrumb_enable',
                'title' => esc_html__('Breadcrumb', 'cityscape'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to show/hide breadcrumb', 'cityscape'), $allowed_html),
                'default' => true,
            ),
            array(
                'id' => 'breadcrumb_bg',
                'title' => esc_html__('Background Image', 'cityscape'),
                'type' => 'background',
                'desc' => wp_kses(__('you can set <mark>background</mark> for breadcrumb', 'cityscape'), $allowed_html),
                'default' => array(
                    'background-size' => '',
                    'background-position' => 'center bottom',
                    'background-repeat' => 'no-repeat',
                ),
                'background_color' => false,
                'dependency' => array('breadcrumb_enable', '==', 'true')
            ),
            array(
                'id' => 'breadcrumb_bg_color',
                'title' => esc_html__('Breadcrumb Background Color', 'cityscape'),
                'type' => 'color',
                'default' => 'rgba(232,0,0, 0.6);',
                'desc' => wp_kses(__('you can set <mark>overlay color</mark> for Breadcrumb background image', 'cityscape'), $allowed_html),
                'dependency' => array('breadcrumb_enable', '==', 'true')
            ),
        )
    ));


    /*-------------------------------------------------------
       ** Entire Site Header  Options
   --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'headers_settings',
        'title' => esc_html__('Headers', 'cityscape'),
        'icon' => 'fa fa-home'
    ));

    /* Header Style 01 */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Header One', 'cityscape'),
        'id' => 'theme_header_one_options',
        'icon' => 'fa fa-image',
        'parent' => 'headers_settings',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Header Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'header_one_logo',
                'type' => 'media',
                'title' => esc_html__('Logo', 'cityscape'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'cityscape'), $allowed_html),
            ),
            array(
                'id' => 'header_one_btn_text',
                'type' => 'text',
                'title' => esc_html__('Btn Text', 'cityscape'),
                'default' => esc_html__('Add Listing', 'cityscape')
            ),
        )
    ));

    /* Header Style 02 */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Header Two', 'cityscape'),
        'id' => 'theme_header_two_options',
        'icon' => 'fa fa-image',
        'parent' => 'headers_settings',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Navbar Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'header_two_phone_number',
                'type' => 'text',
                'title' => esc_html__('Phone Number', 'cityscape'),
                'default' => esc_html__('(629) 555-0129', 'cityscape'),
            ),
            array(
                'id' => 'header_two_email',
                'type' => 'text',
                'title' => esc_html__('Email', 'cityscape'),
                'default' => esc_html__('info@example.com', 'cityscape'),
            ),
            array(
                'id' => 'header_two_address',
                'type' => 'text',
                'title' => esc_html__('Address', 'cityscape'),
                'default' => esc_html__('6391 Elgin St. Celina, 10299', 'cityscape'),
            ),
            array(
                'id' => 'header_two_logo',
                'type' => 'media',
                'title' => esc_html__('Logo', 'cityscape'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'cityscape'), $allowed_html),
            ),
            array(
                'id' => 'header_right_bar_status',
                'title' => esc_html__('Right bar status', 'cityscape'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to show/hide right bar', 'cityscape'), $allowed_html),
                'default' => true,
            ),
            array(
                'id' => 'header_two_btn_text',
                'type' => 'text',
                'title' => esc_html__('Btn Text', 'cityscape'),
                'default' => esc_html__('Add Listing', 'cityscape')
            ),
        )
    ));

    /* Header Style 03 */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Header Three', 'cityscape'),
        'id' => 'theme_header_three_options',
        'icon' => 'fa fa-image',
        'parent' => 'headers_settings',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Navbar Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'header_three_logo',
                'type' => 'media',
                'title' => esc_html__('Logo', 'cityscape'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'cityscape'), $allowed_html),
            ),

            array(
                'id' => 'header_three_phone_number',
                'type' => 'text',
                'title' => esc_html__('Phone Number', 'cityscape'),
                'default' => esc_html__('(629) 555-0129', 'cityscape'),
            ),
            array(
                'id' => 'header_three_email',
                'type' => 'text',
                'title' => esc_html__('Email', 'cityscape'),
                'default' => esc_html__('info@example.com', 'cityscape'),
            ),
            array(
                'id' => 'header_three_address',
                'type' => 'text',
                'title' => esc_html__('Address', 'cityscape'),
                'default' => esc_html__('6391 Elgin St. Celina, 10299', 'cityscape'),
            ),
            array(
                'id' => 'header_three_right_btn_text',
                'type' => 'text',
                'title' => esc_html__('Right Btn text', 'cityscape'),
                'default' => 'Get A Quote ',
            ),
            array(
                'id' => 'header_three_right_btn_url',
                'type' => 'text',
                'title' => esc_html__('Right Btn url', 'cityscape'),
                'default' => esc_html__('#', 'cityscape'),
            ),
            array(
                'id' => 'header_three_social_repeater',
                'type' => 'repeater',
                'title' => esc_html__('Social Repeater', 'cityscape'),
                'fields' => array(
                    array(
                        'id' => 'header_three_social_icon',
                        'type' => 'icon',
                        'title' => esc_html__('Icon', 'cityscape'),
                    ),
                    array(
                        'id' => 'header_three_social_url',
                        'type' => 'text',
                        'title' => esc_html__('Info URL', 'cityscape'),
                        'default' => '#'
                    ),
                )
            ),
        )
    ));
	
	/* Header Style 04 */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Header Four', 'cityscape'),
        'id' => 'theme_header_four_options',
        'icon' => 'fa fa-image',
        'parent' => 'headers_settings',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Header Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'header_four_logo',
                'type' => 'media',
                'title' => esc_html__('Logo', 'cityscape'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'cityscape'), $allowed_html),
            ),
			array(
                'id' => 'header_four_phone_title',
                'type' => 'text',
                'title' => esc_html__('Phone Title', 'cityscape'),
                'default' => esc_html__('Call Us Now', 'cityscape'),
            ),
			array(
                'id' => 'header_four_phone_num',
                'type' => 'text',
                'title' => esc_html__('Phone Number', 'cityscape'),
                'default' => esc_html__('+025 757 576 560', 'cityscape'),
            ),
            array(
                'id' => 'header_four_btn_text',
                'type' => 'text',
                'title' => esc_html__('Btn Text', 'cityscape'),
                'default' => esc_html__('Add Listing', 'cityscape'),
            ),
        )
    ));

    /*-------------------------------------------------------
           ** Footer  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Footer', 'cityscape'),
        'id' => 'footer_options',
        'icon' => ' eicon-footer',
    ));
    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'footer_options',
        'id' => 'footer_general_options',
        'title' => esc_html__('Footer One', 'cityscape'),
        'icon' => 'fa fa-list-ul',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Settings One', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'footer_shortcode',
                'type' => 'textarea',
                'title' => esc_html__('Footer Shortcode', 'cityscape'),
                'shortcoder' => 'cityscape_shortcodes'
            ),
            array(
                'id' => 'footer_one_bg_image',
                'type' => 'media',
                'title' => esc_html__('Footer Background Image', 'cityscape'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> background image</mark> here it will overwrite customizer uploaded logo', 'cityscape'), $allowed_html),
            ),
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Copyright Area Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'copyright_text',
                'title' => esc_html__('Copyright Area Text', 'cityscape'),
                'type' => 'textarea',
                'desc' => wp_kses(__('use  <mark>{copy}</mark> for copyright symbol, use <mark>{year}</mark> for current year, ', 'cityscape'), $allowed_html)
            )
        )
    ));

    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'footer_options',
        'id' => 'footer_two_options',
        'title' => esc_html__('Footer Two', 'cityscape'),
        'icon' => 'fa fa-list-ul',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Top Settings', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'footer_two_bg_image',
                'type' => 'media',
                'title' => esc_html__('Footer Background Image', 'cityscape'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> background image</mark> here it will overwrite customizer uploaded logo', 'cityscape'), $allowed_html),
            ),
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Copyright Area Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'footer_two_copyright_text',
                'title' => esc_html__('Footer Two Copyright Area Text', 'cityscape'),
                'type' => 'textarea',
                'desc' => wp_kses(__('use  <mark>{copy}</mark> for copyright symbol, use <mark>{year}</mark> for current year, ', 'cityscape'), $allowed_html)
            )
        )
    ));

    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'footer_options',
        'id' => 'footer_three_options',
        'title' => esc_html__('Footer Three', 'cityscape'),
        'icon' => 'fa fa-list-ul',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Top Settings', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'footer_three_bg_image',
                'type' => 'media',
                'title' => esc_html__('Footer Background Image', 'cityscape'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> background image</mark> here it will overwrite customizer uploaded logo', 'cityscape'), $allowed_html),
            ),
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Copyright Area Options', 'cityscape') . '</h3>'
            ),
            array(
                'id' => 'footer_three_copyright_text',
                'title' => esc_html__('Footer Two Copyright Area Text', 'cityscape'),
                'type' => 'textarea',
                'desc' => wp_kses(__('use  <mark>{copy}</mark> for copyright symbol, use <mark>{year}</mark> for current year, ', 'cityscape'), $allowed_html)
            )
        )
    ));

    /*-------------------------------------------------------
          ** Blog  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'blog_settings',
        'title' => esc_html__('Blog Settings', 'cityscape'),
        'icon' => 'fa fa-book'
    ));
    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'blog_settings',
        'id' => 'blog_post_options',
        'title' => esc_html__('Blog Post', 'cityscape'),
        'icon' => 'fa fa-list-ul',
        'fields' => Cityscape_Group_Fields::post_meta('blog_post', esc_html__('Blog Page', 'cityscape'))
    ));
    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'blog_settings',
        'id' => 'blog_single_post_options',
        'title' => esc_html__('Single Post', 'cityscape'),
        'icon' => 'fa fa-list-alt',
        'fields' => Cityscape_Group_Fields::post_meta('blog_single_post', esc_html__('Blog Single Page', 'cityscape'))
    ));

    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'shop_settings',
        'title' => esc_html__('Shop Settings', 'cityscape'),
        'icon' => 'fas fa-shopping-basket',
    ));
    /*  Product page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'product_shop_page',
        'title' => esc_html__('Product Page', 'cityscape'),
        'parent' => 'shop_settings',
        'icon' => 'fas fa-shopping-basket',
        'fields' => Cityscape_Group_Fields::page_layout_options(esc_html__('Product Shop Page', 'cityscape'), 'product_shop')
    ));
    /*  Product single page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'product_shop_single_page',
        'title' => esc_html__('Product Single Page', 'cityscape'),
        'parent' => 'shop_settings',
        'icon' => 'fas fa-shopping-basket',
        'fields' => array(
            array(
                'id' => 'product_shop_single_page_bg_color',
                'type' => 'color',
                'title' => esc_html__('Page Background Color', 'cityscape'),
                'default' => '#fff'
            ),
            array(
                'id' => 'product_shop_single_page_spacing_top',
                'title' => esc_html__('Page Spacing Top', 'cityscape'),
                'type' => 'slider',
                'desc' => wp_kses(__('you can set <mark>Padding Top</mark> for page content area.', 'cityscape'), $allowed_html),
                'min' => 0,
                'max' => 500,
                'step' => 1,
                'unit' => 'px',
                'default' => 120,
            ),
            array(
                'id' => 'product_shop_single_page_spacing_bottom',
                'title' => esc_html__('Page Spacing Bottom', 'cityscape'),
                'type' => 'slider',
                'desc' => wp_kses(__('you can set <mark>Padding Bottom</mark> for page content area.', 'cityscape'), $allowed_html),
                'min' => 0,
                'max' => 500,
                'step' => 1,
                'unit' => 'px',
                'default' => 100,
            ),
        ),
    ));

    /*-------------------------------------------------------
          ** Pages & templates Options
   --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'pages_and_template',
        'title' => esc_html__('Pages Settings', 'cityscape'),
        'icon' => 'fa fa-files-o'
    ));
    /*  404 page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => '404_page',
        'title' => esc_html__('404 Page', 'cityscape'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-exclamation-triangle',
        'fields' => array(
            array(
                'id' => 'error_bg_switch',
                'title' => esc_html__('404 Image Enable', 'cityscape'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to show/hide breadcrumb', 'cityscape'), $allowed_html),
                'default' => true,
            ),
            array(
                'id' => 'error_bg',
                'title' => esc_html__('404 Image', 'cityscape'),
                'type' => 'media',
                'desc' => wp_kses(__('you can set <mark>background</mark> for breadcrumb', 'cityscape'), $allowed_html),
                'dependency' => array('error_bg_switch', '==', 'true')
            ),
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('404 Page Options', 'cityscape') . '</h3>',
            ),
            array(
                'id' => '404_bg_color',
                'type' => 'color',
                'title' => esc_html__('Page Background Color', 'cityscape'),
                'default' => '#ffffff'
            ),
            array(
                'id' => '404_title',
                'title' => esc_html__('Title', 'cityscape'),
                'type' => 'text',
                'info' => wp_kses(__('you can change <mark>title</mark> of 404 page', 'cityscape'), $allowed_html),
                'attributes' => array('placeholder' => esc_html__('Sorry! The Page Not Found', 'cityscape'))
            ),
            array(
                'id' => '404_paragraph',
                'title' => esc_html__('Paragraph', 'cityscape'),
                'type' => 'textarea',
                'info' => wp_kses(__('you can change <mark>paragraph</mark> of 404 page', 'cityscape'), $allowed_html),
                'attributes' => array('placeholder' => esc_html__('Oops! The page you are looking for does not exit. it might been moved or deleted.', 'cityscape'))
            ),
            array(
                'id' => '404_button_text',
                'title' => esc_html__('Button Text', 'cityscape'),
                'type' => 'text',
                'info' => wp_kses(__('you can change <mark>button text</mark> of 404 page', 'cityscape'), $allowed_html),
                'attributes' => array('placeholder' => esc_html__('back to home', 'cityscape'))
            ),
            array(
                'id' => '404_spacing_top',
                'title' => esc_html__('Page Spacing Top', 'cityscape'),
                'type' => 'slider',
                'desc' => wp_kses(__('you can set <mark>Padding Top</mark> for page content area.', 'cityscape'), $allowed_html),
                'min' => 0,
                'max' => 500,
                'step' => 1,
                'unit' => 'px',
                'default' => 120,
            ),
            array(
                'id' => '404_spacing_bottom',
                'title' => esc_html__('Page Spacing Bottom', 'cityscape'),
                'type' => 'slider',
                'desc' => wp_kses(__('you can set <mark>Padding Bottom</mark> for page content area.', 'cityscape'), $allowed_html),
                'min' => 0,
                'max' => 500,
                'step' => 1,
                'unit' => 'px',
                'default' => 120,
            ),
        )
    ));

    /*  blog page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'blog_page',
        'title' => esc_html__('Blog Page', 'cityscape'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-indent',
        'fields' => Cityscape_Group_Fields::page_layout_options(esc_html__('Blog', 'cityscape'), 'blog')
    ));
    /*  blog single page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'blog_single_page',
        'title' => esc_html__('Blog Single Page', 'cityscape'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-indent',
        'fields' => Cityscape_Group_Fields::page_layout_options(esc_html__('Blog Single', 'cityscape'), 'blog_single')
    ));
    /*  archive page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'archive_page',
        'title' => esc_html__('Archive Page', 'cityscape'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-archive',
        'fields' => Cityscape_Group_Fields::page_layout_options(esc_html__('Archive', 'cityscape'), 'archive')
    ));
    /*  search page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'search_page',
        'title' => esc_html__('Search Page', 'cityscape'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-search',
        'fields' => Cityscape_Group_Fields::page_layout_options(esc_html__('Search', 'cityscape'), 'search')
    ));

    /*-------------------------------------------------------
           ** Backup  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'backup',
        'title' => esc_html__('Import / Export', 'cityscape'),
        'icon' => 'eicon-export-kit',
        'fields' => array(
            array(
                'type' => 'notice',
                'style' => 'warning',
                'content' => esc_html__('You can save your current options. Download a Backup and Import.', 'cityscape'),
            ),
            array(
                'type' => 'backup',
                'title' => esc_html__('Backup & Import', 'cityscape')
            )
        )
    ));
}