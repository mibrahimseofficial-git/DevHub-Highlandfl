<?php
/**
 * Theme Default Header
 * @package cityscape
 * @since 1.0.0
 */
?>

<?php 
    $preloader_enable = cs_get_option('preloader_enable');
    if($preloader_enable == true) :
?>
    <div class="preloader"  id="preloader">
        <div class="loader"></div>
    </div>
<?php endif; ?>

<div class="side-overlay"></div>

<?php
    $header_two_phone_number = cs_get_option('header_two_phone_number');
    $header_two_email = cs_get_option('header_two_email');
    $header_two_address = cs_get_option('header_two_address');
?>

<div class="header-top">
    <div class="container container-two">
        <div class="flx-between">    
            <div class="header-info flx-align">
                <?php if($header_two_phone_number) : ?>
                    <div class="header-info__item flx-align">
                        <span class="header-info__icon"><i class="fa fa-phone"></i></span>
                        <a href="tel:" class="header-info__text"><?php echo esc_html($header_two_phone_number, 'cityscape'); ?></a>
                    </div>
                <?php endif; ?>
                <?php if($header_two_email) : ?>
                    <div class="header-info__item flx-align">
                        <span class="header-info__icon"><i class="fa fa-envelope"></i></span>
                        <a href="mailto:" class="header-info__text"><?php echo esc_html($header_two_email, 'cityscape'); ?></a>
                    </div>
                <?php endif; ?>
            </div>
            <?php if($header_two_address) : ?>
                <div class="header-info flx-align d-sm-block d-none">
                    <div class="header-info__item flx-align">
                        <span class="header-info__icon"><i class="fa fa-map-marker"></i></span>
                        <span class="email"><?php echo esc_html($header_two_address, 'cityscape'); ?></span>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="header">
    <div class="container container-two">
        <nav class="header-inner flx-between">
            <!-- Logo Start -->
            <div class="logo">
                <?php
                    $header_two_logo = cs_get_option('header_two_logo');
                    if (has_custom_logo() && empty($header_two_logo['id'])) {
                        the_custom_logo();
                    } elseif (!empty($header_two_logo['id'])) {
                        printf('<a class="site-logo" href="%1$s"><img src="%2$s" alt="%3$s"/></a>', esc_url(get_home_url()), $header_two_logo['url'], $header_two_logo['alt']);
                    } else {
                        printf('<h4 class="mb-0"><a class="site-title" href="%1$s">%2$s</a></h4>', esc_url(get_home_url()), esc_html(get_bloginfo('title')));
                    }
                ?>
            </div>
            <!-- Logo End  -->

            <!-- Menu Start  -->
            <div class="header-menu d-lg-block d-none">
                <?php
                    wp_nav_menu(array(
                        'theme_location' => 'main-menu',
                        'menu_class' => 'nav-menu flx-align',
                        'container' => 'div',
                        'container_class' => 'nav-menu flx-align',
                        'container_id' => 'cityscape_main_menu',
                        'fallback_cb' => 'cityscape_theme_fallback_menu',
                    ));
                ?>
            </div>
            <!-- Menu End  -->
            
            <?php
                $header_right_bar_status = cs_get_option('header_right_bar_status');
                $header_two_btn_text = cs_get_option('header_two_btn_text');
            ?>
            <!-- Header Right start -->
            <div class="header-right flx-align">
                <?php if($header_right_bar_status == true) : ?>
                    <button type="button" class="offcanvas-btn d-lg-block d-none">
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="24" viewBox="0 0 30 24" fill="none">
                            <line x1="0.0078125" y1="12.293" x2="30.0078" y2="12.293" stroke="#181616" stroke-width="3"/>
                            <path d="M5.00781 22.293H30.0078" stroke="#181616" stroke-width="3"/>
                            <path d="M10.0078 2.29297H30.0078" stroke="#181616" stroke-width="3"/>
                        </svg>
                    </button>
                <?php endif; ?>
                <?php if ( is_user_logged_in() ) { ?>
                    <?php if($header_two_btn_text) : ?>
                        <a href="dashboard/" class="btn btn-outline-light d-lg-block d-none">
                            <?php echo esc_html('Dashboard', 'cityscape'); ?> 
                            <span class="icon-right icon"> 
                                <i class="fa fa-arrow-right"></i>
                            </span> 
                        </a>
                    <?php endif; ?>
                <?php }else { ?>
                    <a href="add-listing/" class="btn btn-outline-light d-lg-block d-none">
                            <?php echo esc_html($header_two_btn_text, 'cityscape'); ?> 
                            <span class="icon-right icon"> 
                                <i class="fa fa-arrow-right"></i>
                            </span> 
                        </a>
                <?php } ?>
                <button type="button" class="toggle-mobileMenu d-lg-none ms-3"> <i class="las la-bars"></i> </button>
            </div>
            <!-- Header Right End  -->
        </nav>
    </div>
</div>

<!-- ==================== Right Offcanvas Start Here ==================== -->
<div class="common-offcanvas">
    <div class="flx-between">
        <?php
            $sitebar_logo = cs_get_option('sitebar_logo');
            if (has_custom_logo() && empty($sitebar_logo['id'])) {
                the_custom_logo();
            } elseif (!empty($sitebar_logo['id'])) {
                printf('<a class="mobile-menu__logo" href="%1$s"><img src="%2$s" alt="%3$s"/></a>', esc_url(get_home_url()), $sitebar_logo['url'], $sitebar_logo['alt']);
            } else {
                printf('<h4 class="mb-0"><a class="site-title text-white" href="%1$s">%2$s</a></h4>', esc_url(get_home_url()), esc_html(get_bloginfo('title')));
            }
        ?>
        <button type="button" class="close-button d-flex position-relative top-0 end-0"> <i class="fa fa-times"></i> </button>
    </div>
	<div class="menubar-info d-lg-none d-block">
		<?php
			wp_nav_menu(array(
				'theme_location' => 'main-menu',
				'menu_class' => 'nav-menu flx-align nav-menu--mobile',
				'container' => 'div',
				'container_class' => 'nav-menu flx-align nav-menu--mobile',
				'container_id' => 'cityscape_main_menu',
				'fallback_cb' => 'cityscape_theme_fallback_menu',
			));
		?>
	</div>
    <div class="sidebar-info d-lg-block d-none">
		<div class="search-box mt-5">
			<form action="<?php echo esc_url(home_url('/'))?>">
				<input type="text" name="s" class="common-input common-input--light" placeholder="<?php echo esc_attr__('Search...','cityscape');?>">
				<button type="submit" class="icon"> <i class="fa fa-search"></i> </button>
			</form>
		</div>

		<?php
			$sitebar_address = cs_get_option('sitebar_address');
			$sitebar_phone = cs_get_option('sitebar_phone');
			$sitebar_phone_2 = cs_get_option('sitebar_phone_2');
			$sitebar_email = cs_get_option('sitebar_email');
			$sitebar_email_2 = cs_get_option('sitebar_email_2');
			$sitebar_facebook = cs_get_option('sitebar_facebook');
			$sitebar_twitter = cs_get_option('sitebar_twitter');
			$sitebar_instagram = cs_get_option('sitebar_instagram');
			$sitebar_linkedin = cs_get_option('sitebar_linkedin');
			$map_enable = cs_get_option('map_enable');
		?>
		<ul class="address-list mt-5">
			<?php if($sitebar_address) : ?>
				<li class="address-list__item flx-align">
					<span class="address-list__icon"><i class="fa fa-map-marker"></i></span>
					<div class="address-list__content">
						<p class="address-list__text"><?php echo esc_html($sitebar_address, 'cityscape'); ?></p>
					</div>
				</li>
			<?php endif; ?>
			<?php if($sitebar_phone) : ?>
				<li class="address-list__item flx-align">
					<span class="address-list__icon"> <i class="fa fa-phone"></i></span>
					<div class="address-list__content">
						<a href="tel:" class="address-list__text"><?php echo esc_html($sitebar_phone, 'cityscape'); ?></a>
						<a href="tel:" class="address-list__text"><?php echo esc_html($sitebar_phone_2, 'cityscape'); ?></a>
					</div>
				</li>
			<?php endif; ?>
			<?php if($sitebar_address) : ?>
				<li class="address-list__item flx-align">
					<span class="address-list__icon"> <i class="fas fa-envelope"></i></span>
					<div class="address-list__content">
						<a href="mailto:" class="address-list__text"><?php echo esc_html($sitebar_email, 'cityscape'); ?></a>
						<a href="mailto:" class="address-list__text"><?php echo esc_html($sitebar_email_2, 'cityscape'); ?></a>
					</div>
				</li>
			<?php endif; ?>
		</ul>
		<div class="google-map mt-5">
			<iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d1511.2499674845235!2d-73.99553882767792!3d40.75102778252164!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sbd!4v1686536419224!5m2!1sen!2sbd" loading="lazy" class="w-100 h-100"></iframe>
		</div> 
		<ul class="social-list">
			<?php if($sitebar_facebook) : ?>
				<li class="social-list__item"><a href="<?php echo esc_url($sitebar_facebook, 'cityscape'); ?>" class="social-list__link flx-center"><i class="fa fa-facebook"></i></a> </li>
			<?php endif; ?>
			<?php if($sitebar_twitter) : ?>
				<li class="social-list__item"><a href="<?php echo esc_url($sitebar_twitter, 'cityscape'); ?>" class="social-list__link flx-center"> <i class="fa fa-twitter"></i></a></li>
			<?php endif; ?>
			<?php if($sitebar_instagram) : ?>
				<li class="social-list__item"><a href="<?php echo esc_url($sitebar_instagram, 'cityscape'); ?>" class="social-list__link flx-center"> <i class="fa fa-linkedin"></i></a></li>
			<?php endif; ?>
			<?php if($sitebar_linkedin) : ?>
				<li class="social-list__item"><a href="<?php echo esc_url($sitebar_linkedin, 'cityscape'); ?>" class="social-list__link flx-center"> <i class="fa fa-instagram"></i></a></li>
			<?php endif; ?>
		</ul>
	</div>
</div>
<!-- ==================== Right Offcanvas End Here ==================== -->