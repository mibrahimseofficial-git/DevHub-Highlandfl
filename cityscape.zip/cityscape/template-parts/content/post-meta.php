<?php
/**
 * Post Meta Functions
 * @package cityscape
 * @since 1.0.0
 */

$cityscape = cityscape();
$post_meta = Cityscape_Group_Fields_Value::post_meta('blog_post');
?>
<div class="post-meta-wrap">
    <ul class="post-meta">
        <?php if ($post_meta['posted_by']): ?>
            <li>
                <i class="fa fa-user"></i>
                <?php $cityscape->posted_by(); ?>
            </li>
        <?php endif; ?>
        <li>
            <i class="fa fa-calendar"></i>
            <?php
            $cityscape->posted_on();
            ?>
        </li>
        <li>
            <i class="fa fa-comments"></i>
            <?php
            $cityscape->comment_count();
            ?>
        </li>
    </ul>
</div>