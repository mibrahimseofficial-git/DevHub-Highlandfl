<?php
/**
 * Post Thumbnail Functions
 * @package cityscape
 * @since 1.0.0
 */

$cityscape = cityscape();
if (has_post_thumbnail()): ?>
    <div class="thumbnail">
        <?php $cityscape->post_thumbnail('post-thumbnail'); ?>
    </div>
<?php endif; ?>