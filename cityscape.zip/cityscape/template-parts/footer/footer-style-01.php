<?php
/**
 * Footer Style 01
 * @package cityscape
 * @since 1.0.0
 */
$copyright_text = !empty(cs_get_option('copyright_text')) ? cs_get_option('copyright_text') : esc_html__('© Cityscape 2024 All Rights Reserved', 'cityscape');
$copyright_text = str_replace('{copy}', '&copy;', $copyright_text);
$copyright_text = str_replace('{year}', date('Y'), $copyright_text);

$footer_shortcode = cs_get_option('footer_shortcode');
$footer_one_bg_image = cs_get_option('footer_one_bg_image');

$footer_one_bg_img_url = '';
if(!empty($footer_one_bg_image['url'])){
    $footer_one_bg_img_url = $footer_one_bg_image['url'];
}

$footer_shortcode_class = '';
if(!empty($footer_shortcode)) {
    $footer_shortcode_class = 'footer-top-space';
};

if(!empty($footer_shortcode)) {
    echo do_shortcode($footer_shortcode);
}
?>

<?php if (cityscape()->is_cityscape_core_active()) : ?>    
    <div class="footer footer-style-two bg-cover footer-active-class <?php echo esc_attr($footer_shortcode_class); ?>" style="background-image: url('<?php echo esc_attr($footer_one_bg_img_url); ?>')"> 
<?php else : ?>     
    <div class="footer footer-style-two bg-cover <?php echo esc_attr($footer_shortcode_class); ?>"> 
<?php endif; ?>
    <footer class="footer-wraps">
        <div class="footer-wrap-inner">
            <div class="container">
                <?php get_template_part('template-parts/content/footer-widget'); ?>
            </div>
        </div>
        <div class="copyright-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 align-self-center">
                        <div class="copyright-content">
                            <div class="copyright-text pt-3 pb-3">
                                <?php
                                echo wp_kses($copyright_text, cityscape()->kses_allowed_html(array('a')));
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php if (has_nav_menu('footer-menu')) { ?>
                        <div class="col-lg-6 mt-lg-0 mt-2 text-lg-end align-self-center">
                            <?php wp_nav_menu(array(
                                'theme_location' => 'footer-menu',
                            )); ?>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </footer>
</div>