<?php
/**
 * Template part for displaying single team post
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cityscape
 */

$cityscape = cityscape();
$cityscape_meta = get_post_meta(get_the_ID(), 'cityscape_team_options', true);
$img_id = get_post_thumbnail_id(get_the_ID()) ? get_post_thumbnail_id(get_the_ID()) : false;
$img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'full', false) : '';
$img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
$img_alt = $img_id ? get_post_meta($img_id, '_wp_attachment_image_alt', true) : '';
$designation = isset($cityscape_meta['designation']) && !empty($cityscape_meta['designation']) ? $cityscape_meta['designation'] : '';
$description = isset($cityscape_meta['description']) && !empty($cityscape_meta['description']) ? $cityscape_meta['description'] : '';
$description_2 = isset($cityscape_meta['description_2']) && !empty($cityscape_meta['description_2']) ? $cityscape_meta['description_2'] : '';
$team_info = isset($cityscape_meta['team-info']) && !empty($cityscape_meta['team-info']) ? $cityscape_meta['team-info'] : '';

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('cityscape-details-content-area team-details-section'); ?>>
    <div class="entry-content">
        <?php
        the_content();
        $cityscape->link_pages();
        ?>
    </div>
</article><!-- #post-<?php the_ID(); ?> -->