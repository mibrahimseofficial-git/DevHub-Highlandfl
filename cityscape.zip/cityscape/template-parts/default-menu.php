<?php

// Fallback Menu

?>

<div class="btn-wrap menu-set-up pt-3 pb-3">
    <a class="btn btn-main" href="<?php echo admin_url('nav-menus.php'); ?>"><?php esc_html_e( 'Set Up Menu', 'cityscape' ); ?></a>
</div>