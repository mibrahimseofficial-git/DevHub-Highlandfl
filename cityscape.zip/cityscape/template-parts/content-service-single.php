<?php
/**
 * Template part for displaying single service post
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cityscape
 */

$cityscape = cityscape();
$post_single_meta = Cityscape_Group_Fields_Value::post_meta('service_single_post');
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('service-details-item'); ?>>
    <div class="entry-content">
        <?php
            the_content();
        ?>
    </div>
</article>