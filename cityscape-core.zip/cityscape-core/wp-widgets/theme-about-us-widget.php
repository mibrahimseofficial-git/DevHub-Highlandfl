<?php
/**
 * Theme About Us Widget
 * @package Cityscape
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); //exit if access directly
}
// Control core classes for avoid errors
if (class_exists('CSF')) {


    // Create a About Widget
    CSF::createWidget('cityscape_about_widget', array(
        'title' => esc_html__('Cityscape: About Us', 'cityscape-core'),
        'classname' => 'cityscape-widget-about',
        'description' => esc_html__('Display about us widget', 'cityscape-core'),
        'fields' => array(
            array(
                'id' => 'logo-area',
                'type' => 'media',
                'title' => esc_html__('Upload Your Photo', 'cityscape-core'),
            ),
            array(
                'id' => 'description',
                'type' => 'textarea',
                'title' => esc_html__('Description', 'Cityscape-core'),
                'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.', 'cityscape-core')
            ),
            array(
                'id' => 'shortcode',
                'type' => 'textarea',
                'title' => esc_html__('Shortcode', 'Cityscape-core'),
            ),

            array(
                'id' => 'cityscape-footer-social-icon-repeater',
                'type' => 'repeater',
                'title' => esc_html__('Social Icon', 'cityscape-core'),
                'fields' => array(

                    array(
                        'id' => 'cityscape-footer-social-icon',
                        'type' => 'icon',
                        'title' => esc_html__('Icon', 'cityscape-core'),
                        'default' => 'flaticon-call'
                    ),
                    array(
                        'id' => 'cityscape-footer-social-text',
                        'type' => 'text',
                        'title' => esc_html__('Enter Your Url', 'cityscape-core'),
                        'default' => esc_html__('#', 'cityscape-core')
                    ),

                ),
            ),
        )
    ));


    if (!function_exists('cityscape_about_widget')) {
        function cityscape_about_widget($args, $instance)
        {

            echo $args['before_widget'];

            $logo = $instance['logo-area'];
            $img_id = $logo['id'] ?? '';
            $img_print = $img_id ? wp_get_attachment_image_src($img_id,'full')[0] : '';
            $alt_text = get_post_meta($img_id, '_wp_attachment_image_alt', true);
            $paragraph = $instance['description'] ?? '';
            $shortcode = $instance['shortcode'] ?? '';
            $socialIcon = is_array($instance['cityscape-footer-social-icon-repeater']) && !empty($instance['cityscape-footer-social-icon-repeater']) ? $instance['cityscape-footer-social-icon-repeater'] : [];


            ?>
            <div class="footer-widget widget">
                <div class="about_us_widget style-01">
                    <a href="<?php echo get_home_url(); ?>" class="footer-logo"><?php
                        if (!empty($img_print)) {
                            printf('<img src="%1$s" alt="%2$s"/>', esc_url($img_print), esc_attr($alt_text));
                        }
                    ?>  
                    </a>
                    <div class="footer-item__desc pb-2">
                        <?php echo $paragraph; ?>
                    </div>
                    <?php if (!empty($socialIcon)) { ?>
                        <ul class="social-list style3 mt-4">
                            <?php
                            foreach ($socialIcon as $icon) {
                                echo '<li class="social-list__item mb-0 mt-0">
                                <div class="icon">
                                    <a class="social-list__link flx-center" href="'.$icon['cityscape-footer-social-text'].'">
                                        <i class="' . $icon['cityscape-footer-social-icon'] . '"></i>
                                    </a>
                                </div>
                            </li>';
                            };
                            ?>
                        </ul>
                    <?php } ?>
                </div>
            </div>

            <?php

            echo $args['after_widget'];

        }
    }

}

?>