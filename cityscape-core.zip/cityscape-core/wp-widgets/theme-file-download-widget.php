<?php
/**
 * Theme File Download Widget
 * @package Cityscape
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); //exit if access directly
}
// Control core classes for avoid errors
if (class_exists('CSF')) {


    // Create a About Widget
    CSF::createWidget('cityscape_file_download_widget', array(
        'title' => esc_html__('Cityscape: File Download', 'cityscape-core'),
        'classname' => 'cityscape-widget-file-download',
        'description' => esc_html__('Display File Download widget', 'cityscape-core'),
        'fields' => array(
            array(
                'id' => 'title',
                'type' => 'text',
                'title' => esc_html__('Title', 'Cityscape-core'),
                'default' => esc_html__('Download', 'cityscape-core')
            ),

            array(
                'id' => 'cityscape-file-download-repeater',
                'type' => 'repeater',
                'title' => esc_html__('File Download', 'cityscape-core'),
                'fields' => array(
                    array(
                        'id' => 'cityscape-file-download',
                        'type' => 'media',
                        'title' => esc_html__('File', 'cityscape-core'),
                    ),
                    array(
                        'id' => 'cityscape-file-download-text',
                        'type' => 'text',
                        'title' => esc_html__('File Text', 'cityscape-core'),
                        'default' => esc_html__('Company Profile', 'cityscape-core')
                    ),

                ),
            ),
        )
    ));


    if (!function_exists('cityscape_file_download_widget')) {
        function cityscape_file_download_widget($args, $instance)
        {

            echo $args['before_widget'];

            $title = $instance['title'] ?? '';
            $file_download = is_array($instance['cityscape-file-download-repeater']) && !empty($instance['cityscape-file-download-repeater']) ? $instance['cityscape-file-download-repeater'] : [];


            ?>
            <div class="widget_download">
                <h5 class="widget-headline style-01"><?php echo esc_html($title); ?></h5>               
                <ul>
                    <?php
                        foreach ($file_download as $file) {
                            echo '<li class="mb-0 mt-0">
                                <a download href="'.$file['cityscape-file-download']['url'].'">
                                    ' . $file['cityscape-file-download-text'] . '
                                    <i class="fa fa-angle-double-right"></i>
                                </a>
                            </li>';
                        };
                    ?>
                </ul>
            </div>
            <?php

            echo $args['after_widget'];

        }
    }

}

?>