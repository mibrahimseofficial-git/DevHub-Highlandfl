<?php
/**
 * Theme Social Share Widget
 * @package Cityscape
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); //exit if access directly
}
// Control core classes for avoid errors
if (class_exists('CSF')) {


    // Create a About Widget
    CSF::createWidget('cityscape_social_share_widget', array(
        'title' => esc_html__('Cityscape: Social Share', 'cityscape-core'),
        'classname' => 'cityscape-social-share-about',
        'description' => esc_html__('Display Social Share widget', 'cityscape-core'),
        'fields' => array(
            array(
                'id' => 'heading',
                'type' => 'text',
                'title' => esc_html__('Enter Your Header Title', 'cityscape-core'),
                'default' => esc_html__('Never Miss News', 'cityscape-core')
            ),
            array(
                'id' => 'cityscape-social-icon-repeater',
                'type' => 'repeater',
                'title' => esc_html__('Social Icon', 'cityscape-core'),
                'fields' => array(
                    array(
                        'id' => 'cityscape-social-icon',
                        'type' => 'icon',
                        'title' => esc_html__('Icon', 'cityscape-core'),
                        'default' => 'fab fa-facebook'
                    ),
                    array(
                        'id' => 'cityscape-social-text',
                        'type' => 'text',
                        'title' => esc_html__('Enter Your Ulr', 'cityscape-core'),
                        'default' => '#'
                    ),
                ),
            ),
        )
    ));


    if (!function_exists('cityscape_social_share_widget')) {
        function cityscape_social_share_widget($args, $instance)
        {

            echo $args['before_widget'];
            

            $heading_title = $instance['heading'] ?? '';
            $socialIcon = is_array($instance['cityscape-social-icon-repeater']) && !empty($instance['cityscape-social-icon-repeater']) ? $instance['cityscape-social-icon-repeater'] : [];


            ?>
            <div class="social-share-widget">
                <h4 class="widget-headline"><?php echo esc_html($heading_title); ?></h4>
                <ul class="social-icon style-03">
                    <?php
                    foreach ($socialIcon as $icon) {
                        printf('<li><a href="%2$s"><i class="%1$s"></i></a></li>', esc_html($icon['cityscape-social-icon']), esc_url($icon['cityscape-social-text']));
                    };
                    ?>
                </ul>
            </div>

            <?php

            echo $args['after_widget'];

        }
    }

}

?>