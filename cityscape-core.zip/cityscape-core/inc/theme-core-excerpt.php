<?php
/**
 * Theme Excerpt Class
 * @package cityscape
 * @since 1.0.0
 */

if (!defined('ABSPATH')){
	exit(); //exit if access it directly
}

if (!class_exists('Cityscape_Core_excerpt')):
class Cityscape_Core_excerpt {

    public static $length = 55;

    public static $types = array(
      'short' => 25,
      'regular' => 55,
      'long' => 100,
      'promo'=>15
    );

    public static $more = true;

    /**
     * Sets the length for the excerpt
     * @package cityscape
     */ 
    public static function length($new_length = 55, $more = true) {
        Cityscape_Core_excerpt::$length = $new_length;
        Cityscape_Core_excerpt::$more = $more;

        add_filter( 'excerpt_more', 'Cityscape_Core_excerpt::auto_excerpt_more' );

        add_filter('excerpt_length', 'Cityscape_Core_excerpt::new_length');

        Cityscape_Core_excerpt::output();
    }

    public static function new_length() {
        if( isset(Cityscape_Core_excerpt::$types[Cityscape_Core_excerpt::$length]) )
            return Cityscape_Core_excerpt::$types[Cityscape_Core_excerpt::$length];
        else
            return Cityscape_Core_excerpt::$length;
    }

    public static function output() {
        the_excerpt();
    }

    public static function continue_reading_link() {

        return '<span class="readmore"><a href="'.get_permalink().'">'.esc_html__('Read More','cityscape-core').'</a></span>';
    }

    public static function auto_excerpt_more( ) {
        if (Cityscape_Core_excerpt::$more) :
            return ' ';
        else :
            return ' ';
        endif;
    }

} //end class
endif;

if (!function_exists('cityscape_core_excerpt')){

	function Cityscape_Core_excerpt($length = 55, $more=true) {
		Cityscape_Core_excerpt::length($length, $more);
	}

}


?>