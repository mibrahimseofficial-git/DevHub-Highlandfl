<?php
/*
Plugin Name: Cityscape Core
Plugin URI: https://themeforest.net/user/wowtheme7/portfolio
Description: Plugin to contain short codes and custom post types of the Cityscape theme.
Author: Wowtheme7
Author URI: https://wowtheme7.com/
Version: 1.0.0
Text Domain: cityscape-core
Developer: Md Alamgir (mdalamgirhossen576@gmail.com)
*/


/**
 * If this file is called directly, abort.
 * @package cityscape
 * @since 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Plugin directory path
 * @package cityscape
 * @since 1.0.0
 */
define( 'CITYSCAPE_CORE_ROOT_PATH', plugin_dir_path( __FILE__ ) );
define( 'CITYSCAPE_CORE_ROOT_URL', plugin_dir_url( __FILE__ ) );
define( 'CITYSCAPE_CORE_SELF_PATH', 'cityscape-core/cityscape-core.php' );
define( 'CITYSCAPE_CORE_VERSION', '2.0.1' );
define( 'CITYSCAPE_CORE_INC', CITYSCAPE_CORE_ROOT_PATH .'/inc');
define( 'CITYSCAPE_CORE_LIB', CITYSCAPE_CORE_ROOT_PATH .'/lib');
define( 'CITYSCAPE_CORE_ELEMENTOR', CITYSCAPE_CORE_ROOT_PATH .'/elementor');
define( 'CITYSCAPE_CORE_DEMO_IMPORT', CITYSCAPE_CORE_ROOT_PATH .'/demo-import');
define( 'CITYSCAPE_CORE_ADMIN', CITYSCAPE_CORE_ROOT_PATH .'/admin');
define( 'CITYSCAPE_CORE_ADMIN_ASSETS', CITYSCAPE_CORE_ROOT_URL .'admin/assets');
define( 'CITYSCAPE_CORE_WP_WIDGETS', CITYSCAPE_CORE_ROOT_PATH .'/wp-widgets');
define( 'CITYSCAPE_CORE_ASSETS', CITYSCAPE_CORE_ROOT_URL .'assets/');
define( 'CITYSCAPE_CORE_CSS', CITYSCAPE_CORE_ASSETS .'css');
define( 'CITYSCAPE_CORE_JS', CITYSCAPE_CORE_ASSETS .'js');
define( 'CITYSCAPE_CORE_IMG', CITYSCAPE_CORE_ASSETS .'img');


/**
 * Load additional helpers functions
 * @package cityscape
 * @since 1.0.0
 */
if (!function_exists('cityscape_core')){
	require_once CITYSCAPE_CORE_INC .'/theme-core-helper-functions.php';
	if (!function_exists('cityscape_core')){
		function cityscape_core(){
			return class_exists('Cityscape_Core_Helper_Functions') ? new Cityscape_Core_Helper_Functions() : false;
		}
	}
}
//ob flash
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );


/**
 * Load Codestar Framework Functions
 * @package cityscape
 * @since 1.0.0
 */
if ( !cityscape_core()->is_cityscape_active()) {
	if ( file_exists( CITYSCAPE_CORE_ROOT_PATH . '/inc/csf-functions.php' ) ) {
		require_once CITYSCAPE_CORE_ROOT_PATH . '/inc/csf-functions.php';
	}
}



/**
 * Core Plugin Init
 * @package cityscape
 * @since 1.0.0
 */
if ( file_exists( CITYSCAPE_CORE_ROOT_PATH . '/inc/theme-core-init.php' ) ) {
	require_once CITYSCAPE_CORE_ROOT_PATH . '/inc/theme-core-init.php';
}