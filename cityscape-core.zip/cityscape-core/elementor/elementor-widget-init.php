<?php

/**
 * Elementor Addons Init
 * @package cityscape
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit(); // exit if access directly
}


if ( ! class_exists( 'Cityscape_Elementor_Widget_Init' ) ) {

	class Cityscape_Elementor_Widget_Init {
	   /**
		* $instance
		* @since 1.0.0
		*/
		private static $instance;

	   /**
		* construct()
		* @since 1.0.0
		*/
		public function __construct() {
			add_action( 'elementor/elements/categories_registered', array( $this, '_widget_categories' ) );
			//elementor widget registered
			add_action( 'elementor/widgets/widgets_registered', array( $this, '_widget_registered' ) );
			// elementor editor css
			add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'load_assets_for_elementor' ) );
			//add icon to elementor new icons fileds
			add_filter( 'elementor/icons_manager/native', array( $this, 'add_custom_icon_to_elementor_icons' ) );
		}

		/**
	     * getInstance()
	     * @since 1.0.0
	     */
		public static function getInstance() {
			if ( null == self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * _widget_categories()
		 * @since 1.0.0
		 */
		public function _widget_categories( $elements_manager ) {
			$elements_manager->add_category(
				'cityscape_widgets',
				[
					'title' => esc_html__( 'Cityscape Widgets', 'cityscape-core' ),
					'icon'  => 'fas fa-plug',
				]
			);
		}

		/**
		 * _widget_registered()
		 * @since 1.0.0
		 */
		public function _widget_registered() {
			if ( ! class_exists( 'Elementor\Widget_Base' ) ) {
				return;
			}
			$elementor_widgets = array(
				'heading-title',
				'button',
				'banner-one',
				'banner-two',
				'banner-five',
				'banner-six',
				'banner-four',
				'service-grid-list-one',
				'service-grid-list-two',
				'work-process-list',
				'project-slider',
				'project-slider-two',
				'project-grid-list-one',
				'project-info',
				'team-grid',
				'testimonial-slider-one',
				'testimonial-slider-two',
				'testimonial-slider-three',
				'testimonial-grid',
				'marquee',
				'pricing-one',
				'blog-grid-list-one',
				'blog-grid-list-two',
				'blog-grid-list-three',
				'about',
				'about-two',
				'about-three',
				'about-four',
				'about-five',
				'about-img',
				'about-img-two',
				'about-img-three',
				'about-img-four',
				'quote-img',
				'tab',
				'message-thumb',
				'counter-one',
				'counter-two',
				'counter-three',
				'counter-four',
				'counter-five',
				'accordion',
				'accordion-two',
				'contact-need-help',
				'contact-need-help-two',
				'video',
				'video-two',
				'gallery',
				'project-mesonary',
				'contact-box',
				//property
				'property',
				'property-two',
				'property-list',
				'property-tab',
			);


			$elementor_widgets = apply_filters( 'cityscape_elementor_widget', $elementor_widgets );
			ksort( $elementor_widgets );
			if ( is_array( $elementor_widgets ) && ! empty( $elementor_widgets ) ) {
				foreach ( $elementor_widgets as $widget ) {
					if ( file_exists( CITYSCAPE_CORE_ELEMENTOR . '/addons/elementor-' . $widget . '-widget.php' ) ) {
						require_once CITYSCAPE_CORE_ELEMENTOR . '/addons/elementor-' . $widget . '-widget.php';
					}
				}
			}
		}

		public function add_custom_icon_to_elementor_icons( $icons ) {
			$icons['flaticon'] = [
				'name'          => 'flaticon',
				'label'         => esc_html__( 'Flaticon', 'cityscape-core' ),
				'url'           => CITYSCAPE_CORE_CSS . '/flaticon.css',
				// icon css file
				'enqueue'       => [ CITYSCAPE_CORE_CSS . '/flaticon.css' ],
				// icon css file
				'prefix'        => 'flaticon-',
				//prefix ( like fas-fa  )
				'displayPrefix' => '',
				//prefix to display icon
				'labelIcon'     => 'flaticon-karate-1',
				//tab icon of elementor icons library
				'ver'           => '1.0.0',
				'fetchJson'     => CITYSCAPE_CORE_JS . '/flaticon.js',
				//json file with icon list example {"icons: ['icon class']}
				'native'        => true,
			];

			return $icons;
		}

		/**
		 * load custom assets for elementor
		 * @since 1.0.0
		*/
		public function load_assets_for_elementor() {
			wp_enqueue_style( 'flaticon', CITYSCAPE_CORE_CSS . '/flaticon.css' );
			wp_enqueue_style( 'cityscape-core-elementor-style', CITYSCAPE_CORE_ADMIN_ASSETS . '/css/elementor-editor.css' );
		}
	}

	if ( class_exists( 'Cityscape_Elementor_Widget_Init' ) ) {
		Cityscape_Elementor_Widget_Init::getInstance();
	}
}//end if


