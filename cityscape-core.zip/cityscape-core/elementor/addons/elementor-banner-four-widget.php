<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Banner_Four_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-theme-banner-four-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Banner four', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Banner', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-banner';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'banner_two_content_settings_section',
            [
                'label' => esc_html__('Content Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'right_image', [
                'label' => esc_html__('Right Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Right Image', 'cityscape-core'),
                'default' => array(
                    'url' => Utils::get_placeholder_image_src()
                )
            ]
        );
        $this->add_control(
            'shape_1', [
                'label' => esc_html__('Shape One Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Shape Image', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'shape_2', [
                'label' => esc_html__('Shape Two Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Shape Image', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'shape_3', [
                'label' => esc_html__('Shape Three Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Shape Image', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('sub Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('FinTech Fusion', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title_1st',
            [
                'label' => esc_html__('Title One', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Invest today in You', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title_2nd',
            [
                'label' => esc_html__('Title Two', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Dream Home', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => esc_html__('content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('A business consultant is a professional who provides expert advice and guidance to businesses', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'left_icon', [
                'label' => esc_html__('Left Icon', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Left Icon', 'cityscape-core'),
                'default' => array(
                    'url' => Utils::get_placeholder_image_src()
                )
            ]
        );
        $this->add_control(
            'left_title',
            [
                'label' => esc_html__('Left Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Growth Accel erato', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'left_content',
            [
                'label' => esc_html__('Left Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Your Growth Catalyst Our Expertise', 'cityscape-core'),
            ]
        );


        $this->add_control(
            'right_icon', [
                'label' => esc_html__('right Icon', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('right Icon', 'cityscape-core'),
                'default' => array(
                    'url' => Utils::get_placeholder_image_src()
                )
            ]
        );
        $this->add_control(
            'right_title',
            [
                'label' => esc_html__('right Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Growth Accel erato', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'right_content',
            [
                'label' => esc_html__('right Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Your Growth Catalyst Our Expertise', 'cityscape-core'),
            ]
        );
        $this->end_controls_section();

        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('subtitle_color', [
            'label' => esc_html__('subtitle Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .hero-style3 .sub-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_control('title_action_color', [
            'label' => esc_html__('title action Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .hero-style3 .hero-title span" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title action Typography', 'cityscape-core'),
            'name' => 'title_action_typography',
            'description' => esc_html__('title action typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .hero-style3 .hero-title span"
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>

        
        <section class="banner-four">
            <div class="banner-four__thumb">
            <img src="<?php echo $settings['right_image']['url']; ?>" alt="">
            </div>
            <img src="<?php echo $settings['shape_1']['url']; ?>" alt="Shape" class="banner-four-shape one">
            <img src="<?php echo $settings['shape_1']['url']; ?>" alt="Shape" class="banner-four-shape two">
            <img src="<?php echo $settings['shape_3']['url']; ?>" alt="Shape" class="banner-four-shape three">
            <div class="banner-four__inner">
            <div class="container">
                <div class="banner-four-content">
                <span class="banner-four-content__subtitle"><?php echo $settings['subtitle']; ?></span>
                <h1 class="banner-four-content__title"><?php echo $settings['title_1st']; ?> <span class="text-gradient"><?php echo $settings['title_2nd']; ?></span>
                </h1>
                <div class="banner-four-content__tab">
                    <ul class="common-tab style-outline nav nav-pills" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-rent-tab" data-bs-toggle="pill" data-bs-target="#pills-rent" type="button" role="tab" aria-controls="pills-rent" aria-selected="true">
                        <span class="text">Rent</span>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-buy-tab" data-bs-toggle="pill" data-bs-target="#pills-buy" type="button" role="tab" aria-controls="pills-buy" aria-selected="false">
                        <span class="text">Buy</span>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-sell-tab" data-bs-toggle="pill" data-bs-target="#pills-sell" type="button" role="tab" aria-controls="pills-sell" aria-selected="false">
                        <span class="text">Sell</span>
                        </button>
                    </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-rent" role="tabpanel" aria-labelledby="pills-rent-tab" tabindex="0">
                        <form action="#" class="search-keyword position-relative">
                        <input type="text" class="common-input common-input--lg" placeholder="Search Your keywords">
                        <button type="submit" class="btn btn-main text-capitalize">
                            <span class="icon-left icon">
                            <i class="fas fa-search"></i>
                            </span> Search </button>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="pills-buy" role="tabpanel" aria-labelledby="pills-buy-tab" tabindex="0">
                        <form action="#" class="search-keyword position-relative">
                        <input type="text" class="common-input common-input--lg" placeholder="Search Your keywords">
                        <button type="submit" class="btn btn-main text-capitalize">
                            <span class="icon-left icon">
                            <i class="fas fa-search"></i>
                            </span> Search </button>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="pills-sell" role="tabpanel" aria-labelledby="pills-sell-tab" tabindex="0">
                        <form action="#" class="search-keyword position-relative">
                        <input type="text" class="common-input common-input--lg" placeholder="Search Your keywords">
                        <button type="submit" class="btn btn-main text-capitalize">
                            <span class="icon-left icon">
                            <i class="fas fa-search"></i>
                            </span> Search </button>
                        </form>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </section>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Banner_Four_Widget());