<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_About_Five_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-about-five-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('About Five', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'About', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-editor-list-ul';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('KNOW ABOUT US', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Making Your Real Estate Dreams a Reality', 'cityscape-core'),
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__('List Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Prestige Property Management Your Dream Home Awaits', 'cityscape-core'),
            ]
        );
        $this->add_control('list_items', [
            'label' => esc_html__('List Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Real Estate is a vast industry that deals with the buying, selling, and renting of properties. It involves transactions related to residential', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_link',
            [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        
        $this->end_controls_section();

        $this->start_controls_section(
            'styling_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('subtitle_color', [
            'label' => esc_html__('Sub Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area .sub-title" => "color: {{VALUE}} !important"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('subtitle Typography', 'cityscape-core'),
            'name' => 'subtitle_typography',
            'description' => esc_html__('subtitle typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .title-area .sub-title"
        ]);
        $this->add_control('title_color', [
            'label' => esc_html__('Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 .sec-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .title-area.mb-0 .sec-title"
        ]);
        
        $this->add_control('content_color', [
            'label' => esc_html__('Content One Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 p.banner-content__desc.mt-30.mb-30.white-text" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('Content One Typography', 'cityscape-core'),
            'name' => 'content_one_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .title-area.mb-0 p.banner-content__desc.mt-30.mb-30.white-text"
        ]);
        $this->add_control('list_icon_bg_color', [
            'label' => esc_html__('list Icon Bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} span.icon.text-base-two.text-xl" => "color: {{VALUE}} !important"
            ]
        ]);
        $this->add_control('list_title_color', [
            'label' => esc_html__('list title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 ul li" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_control('content_two_color', [
            'label' => esc_html__('Content Two Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 p.fw-semibold.white-text.text-xl.mb-40" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('Content Two Typography', 'cityscape-core'),
            'name' => 'content_two_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .title-area.mb-0 p.fw-semibold.white-text.text-xl.mb-40"
        ]);
        $this->add_control('button_text_color', [
            'label' => esc_html__('Button Text hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 a.global-btn.style3.text-black.hover-white-text.px-5:hover" => "color: {{VALUE}}!important"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $list_items = $settings['list_items'];
        ?>

        <div class="about-contents">
            <div class="section-heading style-left">
                <?php if($settings['subtitle']) : ?>
                <span class="section-heading__subtitle"> <span class="text-gradient fw-semibold"><?php echo $settings['subtitle']; ?></span> </span>
                <?php endif; ?>
                <?php if($settings['title']) : ?>
                <h2 class="section-heading__title"><?php echo $settings['title']; ?></h2>
                <?php endif; ?>

                <ul class="check-list mt-4 mt-lg-5">
                <?php foreach ($list_items as $item): ?>
                    <li class="check-list__item d-flex align-items-center">
                        <span class="icon"><i class="fas fa-check"></i></span>
                        <span class="text text-body fw-normal font-16"><?php echo $item['list_title']; ?> </span>
                    </li>
                <?php endforeach; ?>
                </ul>
                <?php if($settings['content']) : ?>
                <p class="section-heading__desc"><?php echo $settings['content']; ?></p>
                <?php endif; ?>
                <div class="mt-4">
                <?php if($settings['btn_text']) : ?>
                    <a href="<?php echo $settings['btn_link']; ?>" class="simple-btn text-heading fw-semibold"><?php echo $settings['btn_text']; ?> 
                        <span class="icon-right text-gradient"> <i class="fas fa-arrow-right"></i></span>
                    </a>
                <?php endif; ?>
                </div>

            </div>
        </div>
        
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_About_Five_Widget());