<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_About_Img_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-about-img-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('About Img', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'About', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'about_img', [
                'label' => esc_html__('About_img', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('About Img', 'cityscape-core'),
                'default' => array(
                    'url' => Utils::get_placeholder_image_src()
                )
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Sub Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('20', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Years Experience', 'cityscape-core'),
            ]
        );

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'icon', [
                'label' => esc_html__('Main Image', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
            ]
        );
        $repeater->add_control(
            'social_url',
            [
                'label' => esc_html__('Social Url', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->add_control('social_items', [
            'label' => esc_html__('social Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->end_controls_section();

        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('social_bg_color', [
            'label' => esc_html__('social_bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-thumb3 .social-links" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('exp_border_color', [
            'label' => esc_html__('exp border Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-thumb3 .about-counter-wrap" => "border-color: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $social_items = $settings['social_items'];
        ?>

        <div class="about-thumb">
            <div class="img1">
                <img src="<?php echo $settings['about_img']['url']; ?>" alt="img">
            </div>
            <div class="client-statistics flx-align">
                <span class="client-statistics__icon">
                    <i class="fa fa-users text-gradient"></i>
                </span>
                <div class="client-statistics__content">
                    <?php if($settings['title']) : ?>
                        <h5 class="client-statistics__number statisticsCounter is-visible" style="visibility: visible;"><?php echo $settings['title']; ?>+</h5>
                    <?php endif; ?>
                    <?php if($settings['subtitle']) : ?>
                        <span class="client-statistics__text fs-18"><?php echo $settings['subtitle']; ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_About_Img_Widget());