<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Project_Grid_List_Three_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-project-grid-list-three-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Project Grid List Three', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-slider-album';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control('total', [
            'label' => esc_html__('Total Posts', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '-1',
            'description' => esc_html__('enter how many post you want in masonry , enter -1 for unlimited post.')
        ]);
        $this->add_control('category', [
            'label' => esc_html__('Category', 'cityscape-core'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => cityscape_core()->get_terms_names('project-cat', 'id'),
            'description' => esc_html__('select category as you want, leave it blank for all category', 'cityscape-core'),
        ]);
        $this->add_control('order', [
            'label' => esc_html__('Order', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ASC' => esc_html__('Ascending', 'cityscape-core'),
                'DESC' => esc_html__('Descending', 'cityscape-core'),
            ),
            'default' => 'ASC',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->add_control('orderby', [
            'label' => esc_html__('OrderBy', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ID' => esc_html__('ID', 'cityscape-core'),
                'title' => esc_html__('Title', 'cityscape-core'),
                'date' => esc_html__('Date', 'cityscape-core'),
                'rand' => esc_html__('Random', 'cityscape-core'),
                'comment_count' => esc_html__('Most Comments', 'cityscape-core'),
            ),
            'default' => 'ID',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->add_control('excerpt_length', [
            'label' => esc_html__('Excerpt Length', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                0 => esc_html__('None', 'cityscape-core'),
                9 => esc_html__('Short', 'cityscape-core'),
                22 => esc_html__('Regular', 'cityscape-core'),
                50 => esc_html__('Long', 'cityscape-core'),
            ),
            'default' => 9,
            'description' => esc_html__('select excerpt length', 'cityscape-core')
        ]);
        $this->end_controls_section();


        //style tab start
        $this->start_controls_section(
            'title_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('title_hover_color', [
            'label' => esc_html__('Title hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .portfolio-card-3 .portfolio-card-details_title a:hover" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .portfolio-card-3 .portfolio-card-details_title"
        ]);
        $this->add_control('subtitle_bg_color', [
            'label' => esc_html__('subTitle bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .portfolio-card-3 .portfolio-card-details_subtitle" => "background: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rand_numb = rand(333, 999999999);
        //query settings
        $total_posts = $settings['total'];
        $category = $settings['category'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];

        //setup query
        $args = array(
            'post_type' => 'project',
            'posts_per_page' => $total_posts,
            'order' => $order,
            'orderby' => $orderby,
            'post_status' => 'publish',
            'ignore_sticky_posts' => 1,
        );

        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'project-cat',
                    'field' => 'term_id',
                    'terms' => $category
                )
            );
        }
        $post_data = new \WP_Query($args);
        ?>

     
        <div class="row">
        <?php 
            while ($post_data->have_posts()):$post_data->the_post();
            //image condition here
            $img_id = get_post_thumbnail_id(get_the_ID()) ? get_post_thumbnail_id(get_the_ID()) : false;
            $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'project-image-2', false) : '';
            $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
            $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

            $comments_count = get_comments_number(get_the_ID());
            $comment_text = ($comments_count > 1) ? 'Comments (' . $comments_count . ')' : 'Comment (' . $comments_count . ')';

            $project_single_meta_data = get_post_meta(get_the_ID(), 'cityscape_project_options', true);
            $project_subtitle = isset($project_single_meta_data['project_subtitle']) && !empty($project_single_meta_data['project_subtitle']) ? $project_single_meta_data['project_subtitle'] : '';

            // icon
            $project_icon = isset($project_single_meta_data['project_icon']) && !empty($project_single_meta_data['project_icon']) ? $project_single_meta_data['project_icon'] : '';
            ?>
            <!-- my -->
            <div class="col-sm-6 filter-item">
                <div class="portfolio-card-3 mb-4">
                    <div class="portfolio-card-thumb">
                        <img src="<?php echo esc_url($img_url); ?>" alt="img">
                    </div>
                    <div class="portfolio-card-details">
                        <span class="portfolio-card-details_subtitle mb-3"><?php echo $project_subtitle; ?></span>
                        <h4 class="portfolio-card-details_title"><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                        </h4>
                        <p class="portfolio-card-details_text"><?php echo wp_trim_words(get_the_content(), 13); ?></p>
                    </div>
                </div>
            </div>
            <!-- my -->
            <?php
                endwhile;
                wp_reset_query();
                ?>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Project_Grid_List_Three_Widget());