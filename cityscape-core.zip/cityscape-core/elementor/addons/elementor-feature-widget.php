<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Feature_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-feature-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('feature', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Heading', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Business Growth Catalyst', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Et purus duis sollicitudin sed dignis sim habi tant. Egestas nulla quis venenatis Et purus duis', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'btn_text',
            [
                'label' => esc_html__('btn text', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'btn_url',
            [
                'label' => esc_html__('btn url', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->add_control('feature_items', [
            'label' => esc_html__('feature Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->end_controls_section();

        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('border_color', [
            'label' => esc_html__('border Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .feature-card" => "border-color: {{VALUE}}"
            ]
        ]);
        $this->add_control('bg_color', [
            'label' => esc_html__('bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .feature-card:hover" => "background-color: {{VALUE}}",
                "{{WRAPPER}} .feature-card:hover" => "border-color: {{VALUE}}",
            ]
        ]);
        $this->add_control('title_hover_color', [
            'label' => esc_html__('title hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .feature-card-title a:hover" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .feature-card-title a"
        ]);
        $this->add_control('btn_border_color', [
            'label' => esc_html__('btn border Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .feature-card .global-btn.style-border" => "border-color: {{VALUE}}",
            ]
        ]);
        $this->add_control('btn_hover_bg_color', [
            'label' => esc_html__('btn hover bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .feature-card .global-btn.style-border:hover:before" => "background-color: {{VALUE}}",
                "{{WRAPPER}} .feature-card .global-btn.style-border:hover:after" => "background-color: {{VALUE}}",
                "{{WRAPPER}} .feature-card .global-btn.style-border:hover" => "border-color: {{VALUE}}",
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $feature_items = $settings['feature_items'];
        ?>

        <div class="feature-area-4">
            <div class="row gy-40 justify-content-center">
                <?php foreach ($feature_items as $item): ?>
                    <div class="col-lg-12 col-md-6">
                        <div class="feature-card">
                            <h4 class="feature-card-title"><a href="service-details.html"><?php echo $item['title']; ?></a></h4>
                            <p class="feature-card-text"><?php echo $item['content']; ?></p>
                            <div class="btn-wrap">
                                <a href="<?php echo $item['btn_url']; ?>" class="global-btn style-border">
                                    <?php echo $item['btn_text']; ?> <i class="fas fa-arrow-right ms-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Feature_Widget());