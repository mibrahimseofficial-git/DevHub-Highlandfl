<?php
/**
 * Elementor Widget
 * @package cityscape
 * @since 1.0.0
 */

namespace Elementor;

class Cityscape_Project_Slider_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-project-slider-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('project Slider', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-person';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__('Slider Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('total', [
            'label' => esc_html__('Total Posts', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '-1',
            'description' => esc_html__('enter how many course you want in masonry , enter -1 for unlimited course.')
        ]);
        $this->add_control('category', [
            'label' => esc_html__('Category', 'cityscape-core'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            //'options' => cityscape()->get_terms_names('project-cat', 'id'),
            'options' => wp_list_pluck(get_terms([
                'taxonomy' => 'project-cat',
                'hide_empty' => false,
            ]), 'name', 'term_id'),
            'description' => esc_html__('select category as you want, leave it blank for all category', 'cityscape-core'),
        ]);
        $this->add_control('order', [
            'label' => esc_html__('Order', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ASC' => esc_html__('Ascending', 'cityscape-core'),
                'DESC' => esc_html__('Descending', 'cityscape-core'),
            ),
            'default' => 'ASC',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->add_control('orderby', [
            'label' => esc_html__('OrderBy', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ID' => esc_html__('ID', 'cityscape-core'),
                'title' => esc_html__('Title', 'cityscape-core'),
                'date' => esc_html__('Date', 'cityscape-core'),
                'rand' => esc_html__('Random', 'cityscape-core'),
                'comment_count' => esc_html__('Most Comments', 'cityscape-core'),
            ),
            'default' => 'ID',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->add_control(
            'items',
            [
                'label' => esc_html__('slidesToShow', 'cityscape-core'),
                'type' => Controls_Manager::NUMBER,
                'description' => esc_html__('you can set how many item show in slider', 'cityscape-core'),
                'default' => '3',
            ]
        );
        $this->add_control(
            'margin',
            [
                'label' => esc_html__('Margin', 'cityscape-core'),
                'description' => esc_html__('you can set margin for slider', 'cityscape-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 5,
                    ]
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'size_units' => ['px']
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => esc_html__('Loop', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__('Autoplay', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'nav',
            [
                'label' => esc_html__('Nav', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => 'yes'
            ]
        );
        $this->add_control(
            'dots',
            [
                'label' => esc_html__('Dots', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => 'no'
            ]
        );
        $this->add_control(
            'nav_left_arrow',
            [
                'label' => esc_html__('Nav Left Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-arrow-left',
                    'library' => 'solid',
                ],
                'condition' => ['nav' => 'yes']
            ]
        );
        $this->add_control(
            'nav_right_arrow',
            [
                'label' => esc_html__('Nav Right Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'condition' => ['nav' => 'yes']
            ]
        );
        $this->add_control(
            'center',
            [
                'label' => esc_html__('Center', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),

            ]
        );
        $this->add_control(
            'autoplaytimeout',
            [
                'label' => esc_html__('Autoplay Timeout', 'cityscape-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10000,
                        'step' => 2,
                    ]
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5000,
                ],
                'size_units' => ['px'],
                'condition' => array(
                    'autoplay' => 'yes'
                )
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'project_member_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('title_color', [
            'label' => esc_html__('Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .portfolio-item__title" => "color: {{VALUE}}",
            ]
        ]);
        $this->add_control('title_hover_color', [
            'label' => esc_html__('Title Hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .portfolio-item__title .link:hover" => "color: {{VALUE}} !important",
            ]
        ]);
        $this->add_control('content_color', [
            'label' => esc_html__('Content Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .portfolio-item__desc" => "color: {{VALUE}} !important",
            ]
        ]);
        $this->end_controls_section();

    }


    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rand_numb = rand(333, 999999999);
        //slider settings
        $slider_settings = [
            "loop" => esc_attr($settings['loop']),
            "margin" => esc_attr($settings['margin']['size'] ?? 0),
            "items" => esc_attr($settings['items'] ?? 1),
            "center" => esc_attr($settings['center']),
            "autoplay" => esc_attr($settings['autoplay']),
            "autoplaytimeout" => esc_attr($settings['autoplaytimeout']['size'] ?? 0),
            "nav" => esc_attr($settings['nav']),
            "dot" => esc_attr($settings['dots']),
            "navleft" => cityscape_core()->render_elementor_icons($settings['nav_left_arrow']),
            "navright" => cityscape_core()->render_elementor_icons($settings['nav_right_arrow'])
        ];
        //query settings
        $total_posts = $settings['total'];
        $category = $settings['category'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        //setup query
        $args = array(
            'post_type' => 'project',
            'posts_per_page' => $total_posts,
            'order' => $order,
            'orderby' => $orderby,
            'post_status' => 'publish'
        );

        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'project-cat',
                    'field' => 'term_id',
                    'terms' => $category
                )
            );
        }
        $post_data = new \WP_Query($args);
        ?>

        <div class="portfolio-wrapper slick-slider">
            <?php while ($post_data->have_posts()) : $post_data->the_post(); ?>
                <div class="portfolio-item">
                    <div class="portfolio-item__thumb">
                        <?php 
                            $asdf = get_the_post_thumbnail_url( null, 'cityscape-project-img-1', array('class'=> 'img-responsive') );
                        ?>
                        <img src="<?php echo $asdf; ?>" alt="" class="cover-img">
                    </div>
                    <div class="portfolio-item__content">
                        <a href="<?php the_permalink(); ?>" class="btn btn-icon"> 
                            <span class="text-gradient line-height-0">
                                <i class="fa fa-arrow-right"></i>
                            </span> 
                        </a>
                        <div class="portfolio-item__inner">
                            <h6 class="portfolio-item__title">
                                <a href="<?php the_permalink(); ?>" class="link"><?php echo get_the_title(); ?></a>
                            </h6>
                            <p class="portfolio-item__desc"><?php echo wp_trim_words(get_the_content(), 14); ?></p>
                        </div>
                    </div>
                </div> 
                <?php endwhile; ?>
            </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Project_Slider_Widget());