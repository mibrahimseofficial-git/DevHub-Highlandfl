<?php
/**
 * Elementor Widget
 * @package cityscape
 * @since 1.0.0
 */

namespace Elementor;

class Cityscape_Team_Details_Info_Widget extends Widget_Base
{

    /**
     * Get widget name.
     * 
     * Retrieve Elementor widget name.
     * 
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-team-details-info-widget';
    }

    /**
     * Get widget title.
     * 
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Team Details Info', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-person';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__('Slider Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'main_image', [
                'label' => esc_html__('main Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload main image', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-play',
                    'library' => 'solid',
                ]
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Biography', 'cityscape-core'),
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'count_title',
            [
                'label' => esc_html__('Count Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Design', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'count_value',
            [
                'label' => esc_html__('Count value', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('80', 'cityscape-core'),
            ]
        );
        $this->add_control('team_progress_items', [
            'label' => esc_html__('team progress Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'image' => array(
                        'url' => Utils::get_placeholder_image_src()
                    )
                ]
            ],
        ]);
        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Content One', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('This category focuses on the design and construction of buildings and the This category focuses on the design and construction of buildings and arrangement of furniture and decorative elements within themarrangement', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content_two',
            [
                'label' => esc_html__('Content One', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('This category focuses on the design and construction of buildings and the This category focuses on the design and construction of buildings', 'cityscape-core'),
            ]
        );
        $this->end_controls_section();

    }


    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display(); 
        $team_progress_items = $settings['team_progress_items'];
        ?>

        <div class="team-about-card mb-0">
            <div class="row g-lg-0">
                <div class="col-lg-6">
                    <div class="team-about-card_img">
                        <img class="w-100" src="<?php echo $settings['main_image']['url']; ?>" alt="team image">
                    </div>
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="team-about-card_box">
                        <?php if($settings['title']) : ?>
                            <h3 class="team-about-card_title"><?php echo $settings['title']; ?></h3>
                        <?php endif; ?>

                        <?php foreach ($team_progress_items as $team_progress_item) : ?>
                            <div class="skill-feature position-relative">
                                <h3 class="skill-feature_title"><?php echo $team_progress_item['count_title']; ?></h3>
                                <div class="progress">
                                    <div class="progress-bar" style="width: <?php echo $team_progress_item['count_value']; ?>%;">
                                    </div>
                                    <div class="progress-value"><span class="counter-number"><?php echo $team_progress_item['count_value']; ?></span>%</div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <?php if($settings['content_one']) : ?>
                            <p><?php echo $settings['content_one']; ?></p>
                        <?php endif; ?>
                        <?php if($settings['content_two']) : ?>
                            <p class="mb-n2"><?php echo $settings['content_two']; ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Team_Details_Info_Widget());