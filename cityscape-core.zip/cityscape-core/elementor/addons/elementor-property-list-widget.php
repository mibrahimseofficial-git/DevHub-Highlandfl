<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Property_List_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-property-list-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Property List', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-image-box';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control('property_grid', [
            'label' => esc_html__('Property Grid', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'col-lg-3' => esc_html__('col-lg-2', 'cityscape-core'),
                'col-lg-3' => esc_html__('col-lg-3', 'cityscape-core'),
                'col-lg-4' => esc_html__('col-lg-4', 'cityscape-core'),
                'col-lg-6' => esc_html__('col-lg-6', 'cityscape-core'),
                'col-lg-12' => esc_html__('col-lg-12', 'cityscape-core'),
            ),
            'default' => 'col-lg-4',
            'description' => esc_html__('Select Property Grid', 'cityscape-core')
        ]);
        $this->add_control(
            'read_more',
            [
                'label' => esc_html__('Read More Show/Hide', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('show/hide description', 'cityscape-core'),
                'default' => 'yes',
            ]
        );
        $this->add_control('read-btn', [
            'label' => esc_html__('Read More', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'description' => esc_html__('enter read button text', 'cityscape-core'),
            'default' => esc_html__('BOOK NOW', 'cityscape-core'),
            'condition' => ['read_more' => 'yes'],
        ]);
        $this->add_control('total', [
            'label' => esc_html__('Total Posts', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '-1',
            'description' => esc_html__('enter how many post you want in masonry , enter -1 for unlimited post.')
        ]);
        $this->add_control('category', [
            'label' => esc_html__('Category', 'cityscape-core'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => cityscape_core()->get_terms_names('at_biz_dir-category', 'id'),
            'description' => esc_html__('select category as you want, leave it blank for all category', 'cityscape-core'),
        ]);
        $this->add_control('order', [
            'label' => esc_html__('Order', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ASC' => esc_html__('Ascending', 'cityscape-core'),
                'DESC' => esc_html__('Descending', 'cityscape-core'),
            ),
            'default' => 'DESC',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->add_control('orderby', [
            'label' => esc_html__('OrderBy', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ID' => esc_html__('ID', 'cityscape-core'),
                'title' => esc_html__('Title', 'cityscape-core'),
                'date' => esc_html__('Date', 'cityscape-core'),
                'rand' => esc_html__('Random', 'cityscape-core'),
                'comment_count' => esc_html__('Most Comments', 'cityscape-core'),
            ),
            'default' => 'ID',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->end_controls_section();

        //style tab start
        $this->start_controls_section(
            'title_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        //query settings
        $total_posts = $settings['total'];
        $category = $settings['category'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];

        $args = array(
            'post_type' => 'at_biz_dir',
            'posts_per_page' => $total_posts,
            'order' => $order,
            'orderby' => $orderby,
            'post_status' => 'publish'
        );

        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'at_biz_dir-category',
                    'field' => 'term_id',
                    'terms' => $category
                )
            );
        }

        $post_data = new \WP_Query($args);

        ?>
        <div class="latest-property">
            <div class="row gy-4">
                <?php while ($post_data->have_posts()): $post_data->the_post(); 
                    $post_id = get_the_ID();
                    $img_id = get_post_thumbnail_id($post_id) ? get_post_thumbnail_id($post_id) : false;
                    $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'full', false) : '';
                    $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                    $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

                    // $locations = get_the_terms(get_the_ID(), 'at_biz_dir-location');
                    // $location_name = $locations && !is_wp_error($locations) ? $locations[0]->name : esc_html__('No location assigned', 'your-text-domain');
                    $categories = get_the_terms(get_the_ID(), 'at_biz_dir-category');
                    $category_name = $categories && !is_wp_error($categories) ? $categories[0]->name : esc_html__('No category assigned', 'your-text-domain');
                    ?>  
                    <div class="col-lg-4 col-sm-6">
                        <div class="property-item">
                            <?php if($img_url) : ?>
                                <div class="property-item__thumb">
                                    <a href="property-details.html" class="link">
                                        <img src="<?php echo $img_url; ?>" alt="" class="cover-img">
                                    </a> 
                                    <?php if(!empty($categories[0]->name)) : ?>
                                        <span class="property-item__badge">
                                            <?php echo $categories[0]->name ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <div class="property-item__content">
                                <h6 class="property-item__price">$500.00 <span class="day">/per day</span> </h6>
                                <h6 class="property-item__title"> <a href="<?php echo get_the_permalink(); ?>" class="link"><?php echo get_the_title(); ?></a> </h6>
                                <p class="property-item__location d-flex gap-2"> <span class="icon color-base float-left"> <i class="fa fa-map-marker"></i></span> 
                                    66 Broklyant, New York America
                                </p>
                                <div class="property-item__bottom flx-between gap-2">
                                    <ul class="amenities-list flx-align">
                                        <li class="amenities-list__item flx-align">
                                            <span class="icon"><i class="fa fa-bed"></i></span>
                                            <span class="text">3 Beds</span>
                                        </li>
                                        <li class="amenities-list__item flx-align">
                                            <span class="icon"><i class="fa fa-bath"></i></span>
                                            <span class="text">3 Baths</span>
                                        </li>
                                    </ul>
                                    <a href="<?php echo get_the_permalink(); ?>" class="simple-btn">Book Now <span class="icon-right"> <i class="fa fa-arrow-right"></i> </span> </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                endwhile;
                wp_reset_query();
                ?>
            </div>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Property_List_Widget());