<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Message_Thumb_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-message-thumb-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Message Thumb', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'message', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-image-box';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'image', [
                'label' => esc_html__('Background Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Background image', 'cityscape-core'),
            ]
        );
        $this->add_control(
			'shortcode',
			[
				'label' => esc_html__( 'Shortcode', 'textdomain' ),
				'type' => Controls_Manager::TEXTAREA,
				'rows' => 5,
				'placeholder' => esc_html__( 'Type your description here', 'textdomain' ),
			]
		);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="message">
            <div class="container container-two">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="message-thumb">
                        <?php if($settings['image']) : ?>
                            <img src="<?php echo $settings['image']['url']; ?>" alt="" class="cover-img">
                        <?php endif; ?>
                        </div>
                    </div>
                    <?php if($settings['shortcode']) : ?>
                        <div class="col-lg-7">
                            <?php echo do_shortcode($settings['shortcode']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <!-- My -->
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Message_Thumb_Widget());