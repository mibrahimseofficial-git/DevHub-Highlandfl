<?php
/**
 * Elementor Widget
 * @package cityscape
 * @since 1.0.0
 */

namespace Elementor;

class Cityscape_Service_Slider_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-service-slider-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Service Slider', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-person';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__('Slider Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('read-btn', [
            'label' => esc_html__('Read More', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'description' => esc_html__('enter read button text', 'cityscape-core'),
            'default' => esc_html__('Read More', 'cityscape-core'),
        ]);
        $this->add_control('total', [
            'label' => esc_html__('Total Posts', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '-1',
            'description' => esc_html__('enter how many course you want in masonry , enter -1 for unlimited course.')
        ]);
        $this->add_control('category', [
            'label' => esc_html__('Category', 'cityscape-core'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => cityscape()->get_terms_names('service-cat', 'id'),
            'description' => esc_html__('select category as you want, leave it blank for all category', 'cityscape-core'),
        ]);
        $this->add_control('order', [
            'label' => esc_html__('Order', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ASC' => esc_html__('Ascending', 'cityscape-core'),
                'DESC' => esc_html__('Descending', 'cityscape-core'),
            ),
            'default' => 'ASC',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
       
        $this->add_control('orderby', [
            'label' => esc_html__('OrderBy', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ID' => esc_html__('ID', 'cityscape-core'),
                'title' => esc_html__('Title', 'cityscape-core'),
                'date' => esc_html__('Date', 'cityscape-core'),
                'rand' => esc_html__('Random', 'cityscape-core'),
                'comment_count' => esc_html__('Most Comments', 'cityscape-core'),
            ),
            'default' => 'ID',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->end_controls_section();

        $this->start_controls_section(
            'service_member_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('title_hover_color', [
            'label' => esc_html__('title_hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .service-box_title a:hover" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .service-box_title a"
        ]);
        $this->end_controls_section();

    }


    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        //query settings
        $total_posts = $settings['total'];
        $category = $settings['category'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        //setup query
        $args = array(
            'post_type' => 'service',
            'posts_per_page' => $total_posts,
            'order' => $order,
            'orderby' => $orderby,
            'post_status' => 'publish'
        );

        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'service-cat',
                    'field' => 'term_id',
                    'terms' => $category
                )
            );
        }
        $post_data = new \WP_Query($args);
        ?>
            <div class="row gx-30 global-carousel service-slider2" data-slide-show="4" data-xl-slide-show="3"
                data-lg-slide-show="2" data-md-slide-show="2" data-sm-slide-show="1" data-dots="true"
                data-xl-dots="true" data-ml-dots="true" data-lg-dots="true" data-md-dots="true">
                <?php
                while ($post_data->have_posts()) : $post_data->the_post();
                    $post_id = get_the_ID();
                    $img_id = get_post_thumbnail_id($post_id) ? get_post_thumbnail_id($post_id) : false;
                    $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'full', false) : '';
                    $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                    $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
                    $service_single_meta_data = get_post_meta(get_the_ID(), 'cityscape_service_options', true);

                    
                    $social_icons = isset($service_single_meta_data['social-icons']) && !empty($service_single_meta_data['social-icons']) ? $service_single_meta_data['social-icons'] : '';

                    // icon
                     $service_icon = isset($service_single_meta_data['service_icon']) && !empty($service_single_meta_data['service_icon']) ? $service_single_meta_data['service_icon'] : '';
                    $service_details = isset($service_single_meta_data['service_content']) && !empty($service_single_meta_data['service_content']) ? $service_single_meta_data['service_content'] : '';

                    ?>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="service-box mt-5">
                            <div class="service-box_content">
                                <div class="service-box_icon">
                                <?php
                                        if(!empty($service_icon['url'])) : ?>
                                            <img src="<?php echo esc_url($service_icon['url']); ?>" alt="<?php echo esc_attr('img', 'cityscape-core'); ?>">
                                        <?php endif; 
                                    ?>
                                </div>
                                <h4 class="service-box_title h5"><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a>
                                </h4>
                                <p class="service-box_text"><?php echo $service_details; ?></p>
                                <a href="<?php the_permalink(); ?>" class="global-btn style-border"><?php echo esc_html($settings['read-btn']); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    

                <?php endwhile; ?>
            </div>
        <!-- my -->
        
              <!-- my -->
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Service_Slider_Widget());