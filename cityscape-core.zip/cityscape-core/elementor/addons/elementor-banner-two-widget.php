<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Banner_Two_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-theme-banner-two-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Banner Two', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Banner', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-banner';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'banner_two_content_settings_section',
            [
                'label' => esc_html__('Content Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'banner_two_title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Every Corner Holds Possibilities Your Home', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'banner_two_description',
            [
                'label' => esc_html__('Description', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => esc_html__('enter  description.', 'cityscape-core'),
                'default' => esc_html__('We have been operating for over a decade, providing top-notch services to our clients and building strong track reco industry been operating', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'phone_icon',
            [
                'label' => esc_html__('Phone Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
            ]
        );
        $this->add_control(
            'phone_title',
            [
                'label' => esc_html__('Phone Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Need help?', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'phone_number',
            [
                'label' => esc_html__('Phone Number', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('(319) 555-0115', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'banner_img',
            [
                'label' => esc_html__('Banner img', 'vaptek-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $this->end_controls_section();

        //Style tab style
        $this->start_controls_section(
            'style_settings_section',
            [
                'label' => esc_html__('Style Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('title_action_color', [
            'label' => esc_html__('Title Action Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .hero-style2 .hero-title .hero-title2" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .hero-style2 .hero-title"
        ]);
        $this->add_control('btn_bg_color', [
            'label' => esc_html__('btn bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .hero-style2 .global-btn" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('video_bg_color', [
            'label' => esc_html__('Video Bg', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .media-wrap .icon" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('content_color', [
            'label' => esc_html__('Content Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .banner-two .contact-content__desc" => "color: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        
        <div class="banner-two">
            <div class="container container-two">
                <div class="banner-two__content flx-between">
                    <h1 class="banner-two__title text-white"> 
                        <?php echo $settings['banner_two_title']; ?>
                    </h1>
                    <div class="contact-content">
                        <p class="contact-content__desc font-18">
                            <?php echo $settings['banner_two_description']; ?>
                        </p>
                        <div class="d-flex align-items-center gap-3">
                            <div class="contact-content__icon">
                                <?php Icons_Manager::render_icon($settings['phone_icon'], ['aria-hidden' => 'true']); ?>
                            </div>
                            <div class="contact-content__infos">
                                <p class="contact-content__text mb-1"><?php echo $settings['phone_title']; ?></p> 
                                <a href="#" class="contact-content__contact"><?php echo $settings['phone_number']; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="banner-two__filter background-img" style="background-image: url('<?php echo $settings['banner_img']['url']; ?>')">
                    <div class="filter--box ms-auto">
                        <ul class="common-tab nav nav-pills" id="pills-tabFilter" role="tablist">
                            <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-rentTwo-tab" data-bs-toggle="pill" data-bs-target="#pills-rentTwo" type="button" role="tab" aria-controls="pills-rentTwo" aria-selected="true">Rent</button>
                            </li>
                            <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-buyTwo-tab" data-bs-toggle="pill" data-bs-target="#pills-buyTwo" type="button" role="tab" aria-controls="pills-buyTwo" aria-selected="false">Buy</button>
                            </li>
                            <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-sellTwo-tab" data-bs-toggle="pill" data-bs-target="#pills-sellTwo" type="button" role="tab" aria-controls="pills-sellTwo" aria-selected="false">Sell</button>
                            </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContentFilter">
                            <div class="tab-pane fade show active" id="pills-rentTwo" role="tabpanel" aria-labelledby="pills-rentTwo-tab" tabindex="0">
                                <div class="filter">
                                    <form action="<?php echo esc_url(home_url('/search-result'))?>">
                                        <div class="row gy-sm-4 gy-3">
                                            <div class="col-lg-12">
                                                <input type="text" class="common-input" placeholder="Enter Keyword">      
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="select-has-icon icon-black">
                                                    <select class="select common-input">
                                                        <option value="1" disabled>Property Type</option>
                                                        <option value="1">Apartment</option>
                                                        <option value="1">House</option>
                                                        <option value="1">Land</option>
                                                        <option value="1">Single Family</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="select-has-icon icon-black">
                                                    <select class="select common-input">
                                                        <option value="1" disabled>Location</option>
                                                        <option value="1">Bangladesh</option>
                                                        <option value="1">Japan</option>
                                                        <option value="1">Korea</option>
                                                        <option value="1">Singapore</option>
                                                        <option value="1">Germany</option>
                                                        <option value="1">Thailand</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <button type="submit" class="btn btn-main w-100 d-block">Find Now</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-buyTwo" role="tabpanel" aria-labelledby="pills-buyTwo-tab" tabindex="0">
                                <div class="filter">
                                    <form action="<?php echo esc_url(home_url('/search-result'))?>">
                                        <div class="row gy-sm-4 gy-3">
                                            <div class="col-lg-12">
                                                <input type="text" class="common-input" placeholder="Enter Keyword">      
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="select-has-icon icon-black">
                                                    <select class="select common-input">
                                                        <option value="1" disabled>Property Type</option>
                                                        <option value="1">Apartment</option>
                                                        <option value="1">House</option>
                                                        <option value="1">Land</option>
                                                        <option value="1">Single Family</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="select-has-icon icon-black">
                                                    <select class="select common-input">
                                                        <option value="1" disabled>Location</option>
                                                        <option value="1">Bangladesh</option>
                                                        <option value="1">Japan</option>
                                                        <option value="1">Korea</option>
                                                        <option value="1">Singapore</option>
                                                        <option value="1">Germany</option>
                                                        <option value="1">Thailand</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <button type="submit" class="btn btn-main w-100 d-block">Find Now</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-sellTwo" role="tabpanel" aria-labelledby="pills-sellTwo-tab" tabindex="0">
                                <div class="filter">
                                    <form action="<?php echo esc_url(home_url('/search-result'))?>">
                                        <div class="row gy-sm-4 gy-3">
                                            <div class="col-lg-12">
                                                <input type="text" class="common-input" placeholder="Enter Keyword">      
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="select-has-icon icon-black">
                                                    <select class="select common-input">
                                                        <option value="1" disabled>Property Type</option>
                                                        <option value="1">Apartment</option>
                                                        <option value="1">House</option>
                                                        <option value="1">Land</option>
                                                        <option value="1">Single Family</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="select-has-icon icon-black">
                                                    <select class="select common-input">
                                                        <option value="1" disabled>Location</option>
                                                        <option value="1">Bangladesh</option>
                                                        <option value="1">Japan</option>
                                                        <option value="1">Korea</option>
                                                        <option value="1">Singapore</option>
                                                        <option value="1">Germany</option>
                                                        <option value="1">Thailand</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <button type="submit" class="btn btn-main w-100 d-block">Find Now</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
        </div>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Banner_Two_Widget());