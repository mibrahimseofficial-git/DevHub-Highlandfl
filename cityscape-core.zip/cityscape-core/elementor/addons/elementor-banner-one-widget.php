<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Banner_One_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-theme-banner-one-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Banner: 01', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Banner', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    
    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'banner_one_content_settings_section',
            [
                'label' => esc_html__('Content Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'banner_subtitle',
            [
                'label' => esc_html__('Sub Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('CityScape Fusion', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'banner_title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Invest today in You Dream Home', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'banner_title_shape',
            [
                'label' => esc_html__('Title Shape', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );
        $this->add_control(
            'banner_description',
            [
                'label' => esc_html__('Description', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => esc_html__('enter  description.', 'cityscape-core'),
                'default' => esc_html__('Unlock the Power of Real Estate Making Your Real Estate Dreams a Reality Real Estate here Unlock the Power of Real Estate', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'banner_right_image', [
                'label' => esc_html__('Right Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => array(
                    'url' => Utils::get_placeholder_image_src()
                ),
            ]
        );
        $this->add_control(
            'animate_img_hr', [
                'label' => __('animate img hr', 'cityscape-core'),
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $this->add_control(
            'animate_img_1', [
                'label' => esc_html__('animate img 1', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $this->add_control(
            'animate_img_2', [
                'label' => esc_html__('animate img 2', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $this->add_control(
            'animate_img_3', [
                'label' => esc_html__('animate img 3', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $this->end_controls_section();

        //Style tab style
        $this->start_controls_section(
            'style_settings_section',
            [
                'label' => esc_html__('Style Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('banner_bg_color', [
            'label' => esc_html__('Banner bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .banner" => "background-color: {{VALUE}}"
            ]
        ]);
        $this->add_responsive_control(
            'banner_padding',
            [
                'label' => __('banner padding', 'cityscape-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .banner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control('subtitle_bg_color', [
            'label' => esc_html__('subtitle bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .banner-content__subtitle" => "color: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>

        <div class="banner">
            <div class="container container-two">
                <div class="position-relative">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="banner-inner position-relative">
                                <div class="banner-content">
                                    <?php if($settings['banner_subtitle']) : ?>
                                        <span class="banner-content__subtitle text-uppercase font-14"><?php echo $settings['banner_subtitle']; ?></span>
                                    <?php endif; ?>
                                    <?php if($settings['banner_title']) : ?>
                                        <h1 class="banner-content__title">
                                            <?php echo $settings['banner_title'];
                                            if($settings['banner_title_shape']) :
                                                echo $settings['banner_title_shape'];
                                            endif; ?>
                                        </h1>
                                    <?php endif; ?>
                                    <?php if($settings['banner_description']) : ?>
                                        <p class="banner-content__desc font-18"><?php echo $settings['banner_description']; ?></p>
                                    <?php endif; ?>
                                </div>            
                            </div>
                        </div>
                        <?php if($settings['banner_right_image']['url']) : ?>
                            <div class="col-lg-6 order-lg-0 order-1">
                                <div class="banner-thumb">
                                    <img src="<?php echo $settings['banner_right_image']['url']; ?>" alt="img">
                                    <?php if($settings['animate_img_1']['url']) : ?>
                                        <img src="<?php echo $settings['animate_img_1']['url']; ?>" alt="img" class="shape-element one">
                                    <?php endif; ?>
                                    <?php if($settings['animate_img_2']['url']) : ?>
                                        <img src="<?php echo $settings['animate_img_2']['url']; ?>" alt="img" class="shape-element two">
                                    <?php endif; ?>
                                    <?php if($settings['animate_img_3']['url']) : ?>
                                        <img src="<?php echo $settings['animate_img_3']['url']; ?>" alt="img" class="shape-element three">
                                    <?php endif; ?>
                                </div>  
                            </div>
                        <?php endif; ?>
                        
                        <div class="col-lg-12">
                            <ul class="common-tab nav nav-pills" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="pills-rent-tab" data-bs-toggle="pill" data-bs-target="#pills-rent" type="button" role="tab" aria-controls="pills-rent" aria-selected="true">Rent</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-buy-tab" data-bs-toggle="pill" data-bs-target="#pills-buy" type="button" role="tab" aria-controls="pills-buy" aria-selected="false">Buy</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-sell-tab" data-bs-toggle="pill" data-bs-target="#pills-sell" type="button" role="tab" aria-controls="pills-sell" aria-selected="false">Sell</button>
                                </li>
                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-rent" role="tabpanel" aria-labelledby="pills-rent-tab" tabindex="0">
                                    
                                    <div class="filter">
                                        <form action="<?php echo esc_url(home_url('/search-result'))?>">
                                            <div class="row gy-sm-4 gy-3">
                                                <div class="col-lg-3 col-sm-6 col-xs-6">
                                                    <input type="text" class="common-input" placeholder="Enter Keyword">      
                                                </div>
                                                <div class="col-lg-3 col-sm-6 col-xs-6">
                                                    <div class="select-has-icon icon-black">
                                                        <select class="select common-input">
                                                            <option value="1" disabled>Property Type</option>
                                                            <option value="1">Apartment</option>
                                                            <option value="1">House</option>
                                                            <option value="1">Land</option>
                                                            <option value="1">Single Family</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6 col-xs-6">
                                                    <div class="select-has-icon icon-black">
                                                        <select class="select common-input">
                                                            <option value="1" disabled>Location</option>
                                                            <option value="1">Bangladesh</option>
                                                            <option value="1">Japan</option>
                                                            <option value="1">Korea</option>
                                                            <option value="1">Singapore</option>
                                                            <option value="1">Germany</option>
                                                            <option value="1">Thailand</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6 col-xs-6">
                                                    <button type="submit" class="btn btn-main w-100 d-block">Find Now</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="pills-buy" role="tabpanel" aria-labelledby="pills-buy-tab" tabindex="0">
                                    
                                    <div class="filter">
                                        <form action="<?php echo esc_url(home_url('/search-result'))?>">
                                            <div class="row gy-sm-4 gy-3">
                                                <div class="col-lg-3 col-sm-6 col-xs-6">
                                                    <input type="text" class="common-input" placeholder="Enter Keyword">      
                                                </div>
                                                <div class="col-lg-3 col-sm-6 col-xs-6">
                                                    <div class="select-has-icon icon-black">
                                                        <select class="select common-input">
                                                            <option value="1" disabled>Property Type</option>
                                                            <option value="1">Apartment</option>
                                                            <option value="1">House</option>
                                                            <option value="1">Land</option>
                                                            <option value="1">Single Family</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6 col-xs-6">
                                                    <div class="select-has-icon icon-black">
                                                        <select class="select common-input">
                                                            <option value="1" disabled>Location</option>
                                                            <option value="1">Bangladesh</option>
                                                            <option value="1">Japan</option>
                                                            <option value="1">Korea</option>
                                                            <option value="1">Singapore</option>
                                                            <option value="1">Germany</option>
                                                            <option value="1">Thailand</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-sm-6 col-xs-6">
                                                    <button type="submit" class="btn btn-main w-100 d-block">Find Now</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="pills-sell" role="tabpanel" aria-labelledby="pills-sell-tab" tabindex="0">
                                                            
                                <div class="filter">
                                    <form action="<?php echo esc_url(home_url('/search-result'))?>">
                                        <div class="row gy-sm-4 gy-3">
                                            <div class="col-lg-3 col-sm-6 col-xs-6">
                                                <input type="text" class="common-input" placeholder="Enter Keyword">      
                                            </div>
                                            <div class="col-lg-3 col-sm-6 col-xs-6">
                                                <div class="select-has-icon icon-black">
                                                    <select class="select common-input">
                                                        <option value="1" disabled>Property Type</option>
                                                        <option value="1">Apartment</option>
                                                        <option value="1">House</option>
                                                        <option value="1">Land</option>
                                                        <option value="1">Single Family</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 col-sm-6 col-xs-6">
                                                <div class="select-has-icon icon-black">
                                                    <select class="select common-input">
                                                        <option value="1" disabled>Location</option>
                                                        <option value="1">Bangladesh</option>
                                                        <option value="1">Japan</option>
                                                        <option value="1">Korea</option>
                                                        <option value="1">Singapore</option>
                                                        <option value="1">Germany</option>
                                                        <option value="1">Thailand</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 col-sm-6 col-xs-6">
                                                <button type="submit" class="btn btn-main w-100 d-block">Find Now</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Banner_One_Widget());