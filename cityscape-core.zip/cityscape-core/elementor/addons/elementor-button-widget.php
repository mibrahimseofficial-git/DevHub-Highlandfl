<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Button_Widget extends Widget_Base
{

    /**
     * Get widget name.
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'cityscape-button-widget';
    }

    /**
     * Get widget title.
     * @return string Widget title.
     */
    public function get_title()
    {
        return __('Cityscape Button', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Button', "CodexShaper", 'Cityscape'];
    }

    /**
     * Get widget icon.
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-button';
    }

    /**
     * Get widget categories.
     * @return array Widget categories.
     *
     */
    public function get_categories()
    {
        return ['Cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     * Adds different input fields to allow the user to change and customize the widget settings.
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => __('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label' => __('Btn text', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => __('enter  btn text.', 'cityscape-core'),
                'default' => __('Discover More ', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_url',
            [
                'label' => __('Btn url', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => __('Enter  btn url.', 'cityscape-core'),
                'default' => __('#', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_icon',
            [
                'label' => __('Btn Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => __('enter  btn Icon.', 'cityscape-core'),
            ]
        );
        $this->add_control('icon_alignment', [
            'label' => __('Icon Alignment', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'float-end' => __('Icon Right', 'cityscape-core'),
                'float-start' => __('Icon Left', 'cityscape-core'),
            ),
            'default' => 'float-end',
        ]);
        $this->end_controls_section();

        //style tab start
        $this->start_controls_section(
            'styling_section',
            [
                'label' => __('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'btn_padding',
            [
                'label' => __('Button Padding', 'cityscape-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .btn-wrapper .btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'btn_border_radius',
            [
                'label' => __('Button Border Radius', 'cityscape-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .btn-wrapper .btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'btn_icon_margin',
            [
                'label' => __('Button Icon Margin', 'cityscape-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .btn-wrapper .btn svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control('btn_color', [
            'label' => __('btn Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .btn-wrapper .btn" => "color: {{VALUE}} !important"
            ]
        ]);
        $this->add_control('btn_bg_color', [
            'label' => __('btn bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .btn-wrapper .btn" => "background-color: {{VALUE}}"
            ]
        ]);
        $this->add_control('btn_hover_color', [
            'label' => __('btn hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .btn-wrapper .btn:hover" => "color: {{VALUE}} !important"
            ]
        ]);
        $this->add_control('btn_hover_bg_color', [
            'label' => __('btn hover bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .btn-wrapper .btn:hover" => "background-color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'btn_extra_typography',
            'label' => __('Btn Typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .btn-wrapper .btn"
        ]);
        
        $this->add_control('btn_icon_hover_color', [
            'label' => __('btn Icon hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .btn-wrapper .btn:hover svg" => "fill: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $icon_alignment = $settings['icon_alignment'];
    ?>

    <div class="btn-wrapper">
        <a class="btn btn-main" href="<?php echo $settings['btn_url'] ?>">
            <?php echo $settings['btn_text'] ?>
            <?php if($settings['btn_icon']) : ?>
                <span class="<?php echo $icon_alignment; ?>">
                    <?php Icons_Manager::render_icon($settings['btn_icon'], ['aria-hidden' => 'true']); ?>
                </span>
            <?php endif; ?>
        </a>
    </div>

    <?php
    }
}
Plugin::instance()->widgets_manager->register(new Cityscape_Button_Widget());