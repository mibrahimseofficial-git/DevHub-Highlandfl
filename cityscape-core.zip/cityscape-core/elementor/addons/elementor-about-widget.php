<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_About_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-about-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('About', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'About', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('About Us', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Sub Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Achieve Your a of Business', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => esc_html__('content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Achieve Your a of Business', 'cityscape-core'),
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__('List Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Strategic Solutions Pro', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'list_content',
            [
                'label' => esc_html__('List content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('There are many variati of passages of engineer’s available. The majority have suffered alteration in engineer’s available.', 'cityscape-core'),
            ]
        );
        $this->add_control('list_items', [
            'label' => esc_html__('List Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);


        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Btn Text', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Read More', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_url',
            [
                'label' => esc_html__('Btn Url', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'image', [
                'label' => esc_html__('Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Main image', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'image2', [
                'label' => esc_html__('Img 2', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Shape image', 'cityscape-core'),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'client_settings_section',
            [
                'label' => esc_html__('Client Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'client_img', [
                'label' => esc_html__('Client Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Main image', 'cityscape-core'),
            ]
        );
        $this->add_control('client_items', [
            'label' => esc_html__('client Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->end_controls_section();

        $this->start_controls_section(
            'styling_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('subtitle_color', [
            'label' => esc_html__('Sub Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-content-wrap .sub-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('subtitle Typography', 'cityscape-core'),
            'name' => 'subtitle_typography',
            'description' => esc_html__('subtitle typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .about-content-wrap .sub-title"
        ]);
        $this->add_control('title_color', [
            'label' => esc_html__('Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-content-wrap .sec-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .about-content-wrap .sec-title"
        ]);
        $this->add_control('content_color', [
            'label' => esc_html__('content Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-content-wrap .sec-text" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_control('list_icon_color', [
            'label' => esc_html__('list icon Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .achive-about_icon svg path" => "fill: {{VALUE}}"
            ]
        ]);
        $this->add_control('list_title_color', [
            'label' => esc_html__('list title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .achive-about .box-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_control('btn_bg_color', [
            'label' => esc_html__('btn bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-content-wrap .global-btn" => "background: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $list_items = $settings['list_items'];
        $client_items = $settings['client_items'];
        ?>

        <div class="about-area-1 position-relative space-top">
            <?php if($settings['image']['url']) : ?>
                <div class="about1-shape-img1">
                    <img class="about1-shape-img-1" src="<?php echo $settings['image']['url']; ?>" alt="img">
                </div>
            <?php endif; ?>
            <?php if($settings['image2']['url']) : ?>
                <div class="about1-shape-img2">
                    <img class="about1-shape-img-2" src="<?php echo $settings['image2']['url']; ?>" alt="img">
                </div>
            <?php endif; ?>
            <div class="container">
                <div class="row gx-60 align-items-center">
                    <div class="col-xl-6">
                        <div class="about-content-wrap me-xl-5">
                            <div class="title-area mb-20">
                                <span class="sub-title">
                                    <img src="<?php echo get_template_directory_uri().'/assets/img/title_left.svg'; ?>" alt="shape">
                                    <?php echo $settings['subtitle']; ?>
                                </span>
                                <h2 class="sec-title"><?php echo $settings['title']; ?></h2>
                                <p class="sec-text mb-35"><?php echo $settings['content']; ?></p>
                            </div>
                            <?php foreach ($list_items as $item): ?>
                                <div class="achive-about">
                                    <div class="achive-about_content">
                                        <div class="achive-about_icon">
                                            <i class="fas fa-check"></i>
                                        </div>
                                        <div class="media-body">
                                            <h3 class="box-title"><?php echo $item['list_title']; ?></h3>
                                            <p class="achive-about_text"><?php echo $item['list_content']; ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <div class="btn-wrap mt-20">
                                <a href="<?php echo $settings['btn_url']; ?>" class="global-btn mt-xl-0 mt-20"><?php echo $settings['btn_text']; ?> <i
                                        class="fas fa-arrow-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="client-bg-area-2 space-bottom z-indez-3">
            <div class="client-area-2">
                <div class="global-carousel" data-slide-show="4" data-xxl-slide-show="3" data-lg-slide-show="3"
                    data-md-slide-show="3" data-sm-slide-show="2">
                    <?php foreach ($client_items as $c_item): ?>
                        <div class="col-lg-auto">
                            <div class="client-logo">
                                <a href="#"><img src="<?php echo $c_item['client_img']['url']; ?>" alt="img"></a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_About_Widget());