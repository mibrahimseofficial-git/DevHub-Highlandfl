<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_About_Four_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-about-four-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('About Four', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'About', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-editor-list-ul';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('KNOW ABOUT US', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Making Your Real Estate Dreams a Reality', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Et purus duis sollicitudin dignissim habitant. Egestas nulla quis venenatis cras sed eu massa eu faucibus Urna fusce', 'cityscape-core'),
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__('List Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Prestige Property Management Your Dream Home Awaits', 'cityscape-core'),
            ]
        );
        $this->add_control('list_items', [
            'label' => esc_html__('List Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->end_controls_section();

        $this->start_controls_section(
            'styling_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('subtitle_color', [
            'label' => esc_html__('Sub Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area .sub-title" => "color: {{VALUE}} !important"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('subtitle Typography', 'cityscape-core'),
            'name' => 'subtitle_typography',
            'description' => esc_html__('subtitle typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .title-area .sub-title"
        ]);
        $this->add_control('title_color', [
            'label' => esc_html__('Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 .sec-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .title-area.mb-0 .sec-title"
        ]);
        
        $this->add_control('content_color', [
            'label' => esc_html__('Content One Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 p.banner-content__desc.mt-30.mb-30.white-text" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('Content One Typography', 'cityscape-core'),
            'name' => 'content_one_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .title-area.mb-0 p.banner-content__desc.mt-30.mb-30.white-text"
        ]);
        $this->add_control('list_icon_bg_color', [
            'label' => esc_html__('list Icon Bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} span.icon.text-base-two.text-xl" => "color: {{VALUE}} !important"
            ]
        ]);
        $this->add_control('list_title_color', [
            'label' => esc_html__('list title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 ul li" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_control('content_two_color', [
            'label' => esc_html__('Content Two Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 p.fw-semibold.white-text.text-xl.mb-40" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('Content Two Typography', 'cityscape-core'),
            'name' => 'content_two_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .title-area.mb-0 p.fw-semibold.white-text.text-xl.mb-40"
        ]);
        $this->add_control('button_text_color', [
            'label' => esc_html__('Button Text hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .title-area.mb-0 a.global-btn.style3.text-black.hover-white-text.px-5:hover" => "color: {{VALUE}}!important"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $list_items = $settings['list_items'];
        ?>

        <div class="about-content">
            <div class="section-heading style-left">
                <span class="section-heading__subtitle bg-white"> <span class="text-gradient fw-semibold"><?php echo $settings['subtitle']; ?></span> </span>
                <h2 class="section-heading__title"><?php echo $settings['title']; ?></h2>
                <p class="section-heading__desc font-18"><?php echo $settings['content']; ?></p>
            </div>
            <ul class="check-list">
            <?php foreach ($list_items as $item): ?>
                <li class="check-list__item d-flex align-items-center">
                    <span class="icon"><i class="fas fa-check"></i></span>
                    <span class="text fw-normal text-body font-16"><?php echo $item['list_title']; ?></span>
                </li>
            <?php endforeach; ?>
            </ul>
        </div>
        
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_About_Four_Widget());