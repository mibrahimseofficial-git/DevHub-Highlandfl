<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Section_Title_One_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-theme-section-title-one-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Heading Title: 01', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Heading', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Sub Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Latest service', 'cityscape-core'),
                'description' => esc_html__('enter title. use {c} color text {/c} for color text', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Empowering Business The Excellence', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => esc_html__('content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Button text', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $this->add_control(
            'btn_url',
            [
                'label' => esc_html__('Button Url', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->add_responsive_control(
            'text_align',
            [
                'label' => esc_html__('Alignment', 'cityscape-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'cityscape-core'),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'cityscape-core'),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'cityscape-core'),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
                'selectors' => [
                    "{{WRAPPER}} .section-heading" => "text-align: {{VALUE}}"
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'styling_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('subtitle_bg_color', [
            'label' => esc_html__('Sub Title BG Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .section-heading__subtitle" => "background: {{VALUE}} !important"
            ]
        ]);
        $this->add_control('subtitle_color', [
            'label' => esc_html__('Sub Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .section-heading__subtitle" => "color: {{VALUE}} !important"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('subtitle Typography', 'cityscape-core'),
            'name' => 'subtitle_typography',
            'description' => esc_html__('subtitle typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .section-heading__subtitle"
        ]);
        $this->add_control('title_color', [
            'label' => esc_html__('Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .section-heading__title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .section-heading__title"
        ]);
        $this->add_control('content_color', [
            'label' => esc_html__('content Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .section-heading p" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('content Typography', 'cityscape-core'),
            'name' => 'content_typography',
            'description' => esc_html__('content typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .section-heading p"
        ]);
        $this->add_responsive_control(
            'subtitle_margin',
            [
                'label' => __('Content Margin', 'docshipper-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .section-heading p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="section-heading">
            <?php if (!empty($settings['subtitle'])) : ?>
                <span class="section-heading__subtitle">
                    <span class="text-gradient fw-semibold"> 
                        <?php 
                            $subtitle = str_replace(['{c}', '{/c}'], ['<span class="text-gradient fw-semibold">', '</span>'], $settings['subtitle']);
                            print wp_kses($subtitle, cityscape_core()->kses_allowed_html('all'));
                        ?>  
                    </span>
                </span>
            <?php endif; ?>
            <h2 class="section-heading__title">
                <?php
                    $title = str_replace(['{c}', '{/c}'], ['<span>', '</span>'], $settings['title']);
                    print wp_kses($title, cityscape_core()->kses_allowed_html('all'));
                ?>
            </h2>
            <?php
                if(!empty($settings['content'])){ ?>
                    <p class="sec-text section-heading__desc"><?php echo $settings['content']; ?></p>
                <?php }
            ?>
            <?php if (!empty($settings['btn_text'])) : ?>
            <div class="heading_button">
                <a href="<?php echo $settings['btn_url']; ?>" class="btn btn-outline-lightInDark text-white fw-normal"><?php echo $settings['btn_text']; ?> 
                    <span class="icon-right icon text-gradient"> 
                        <i class="fas fa-arrow-right"></i>
                        </span> 
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Section_Title_One_Widget());