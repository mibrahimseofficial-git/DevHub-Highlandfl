<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Cta_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-cta-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('CTA', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'cta', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    
    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'banner_one_content_settings_section',
            [
                'label' => esc_html__('Content Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Let’s Do Great!', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Dictum ultrices porttitor amet nec sollicitudin mi molestie', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Btn Text', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Learn More', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_url',
            [
                'label' => esc_html__('Btn Url', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title_2',
            [
                'label' => esc_html__('title_2', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Our Services', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'subtitle_2',
            [
                'label' => esc_html__('subtitle_2', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Worldwide clients', 'cityscape-core'),
            ]
        );

        $this->add_control( 'imagelist', [
            'label'       => esc_html__( 'Hero Card', 'cityscape-core' ),
            'type'        => Controls_Manager::REPEATER,
            'default'     => [
                [
                    'title'        => esc_html__( 'Hero Card' ),
                ]
            ],
            'fields'      => [

                [
					'name'        => 'image',
					'label'       => esc_html__( 'Card Image', 'cityscape-core' ),
					'type'        => Controls_Manager::MEDIA,
					'default'     =>
						array(
							'url' => Utils::get_placeholder_image_src(),
						),
					'description' => esc_html__( 'Upload Card Image', 'cityscape-core' )
				],


            ],
            'title_field' => "{{name}}"
        ] );
        
        $this->end_controls_section();

        //Style tab style
        $this->start_controls_section(
            'style_settings_section',
            [
                'label' => esc_html__('Style Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('left_side_bg_color', [
            'label' => esc_html__('left side bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .cta-wrap1:before" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('left_title_color', [
            'label' => esc_html__('left title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .cta-wrap1 .title-area .sec-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('left title Typography', 'cityscape-core'),
            'name' => 'left_title_typography',
            'description' => esc_html__('left title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .cta-wrap1 .title-area .sec-title"
        ]);

        $this->add_control('right_side_bg_color', [
            'label' => esc_html__('right side bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .cta-wrap1:before" => "background: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $imagelist = $settings['imagelist'];
        ?>

        <div class="cta-area-1">
            <div class="container">
                <div class="cta-wrap1">
                    <div class="row gy-4 justify-content-md-between align-items-center">
                        <div class="col-lg-6 col-md-8">
                            <div class="title-area mb-md-0">
                                <h2 class="sec-title style2 mb-4"><?php echo $settings['title']; ?></h2>
                                <p class="cta-desc text-white mb-0"><?php echo $settings['content']; ?></p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="client-box mb-sm-0 mb-5">
                                <div class="client-thumb">
                                    <div class="client-thumb-group">
                                        <?php foreach ( $imagelist as $item ): ?>
                                            <div class="thumb">
                                                <img src="<?php echo $item['image']['url']; ?>" alt="avater">
                                            </div>
                                        <?php endforeach; ?>
                                        <div class="thumb icon"><i class="fas fa-plus"></i></div>
                                    </div>
                                    <div class="client-box-content">
                                        <h4 class="cilent-box_counter"><?php echo $settings['title_2']; ?></h4>
                                        <span class="cilent-box_title"><?php echo $settings['subtitle_2']; ?></span>
                                    </div>
                                </div>
                                <div class="cta-btn">
                                    <a class="global-btn style-border" href="<?php echo $settings['btn_url']; ?>"><?php echo $settings['btn_text']; ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Cta_Widget());