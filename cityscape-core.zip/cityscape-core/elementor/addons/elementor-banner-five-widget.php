<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Banner_Five_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-theme-banner-five-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Banner five', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Banner', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-banner';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'banner_two_content_settings_section',
            [
                'label' => esc_html__('Content Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'image', [
                'label' => esc_html__('Main  Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Image', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('sub Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('FinTech Fusion', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Beyond Walls We Build Dreams', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Unlock the Power of Real Estate Making Your Real Estate Dreams a Reality Real Estate here Unlock the Power of Real Estate', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Button Text', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Learn More', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_url',
            [
                'label' => esc_html__('content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->end_controls_section();

        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('subtitle_color', [
            'label' => esc_html__('subtitle Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .hero-style3 .sub-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_control('title_action_color', [
            'label' => esc_html__('title action Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .hero-style3 .hero-title span" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title action Typography', 'cityscape-core'),
            'name' => 'title_action_typography',
            'description' => esc_html__('title action typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .hero-style3 .hero-title span"
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="banner-five banner bg-white">
            <div class="container container-two">
                <div class="row gy-4">
                    <div class="col-lg-6">
                        <div class="banner-inner position-relative">
                            <div class="banner-content">
                                <span class="banner-content__subtitle text-uppercase font-14"><?php echo $settings['subtitle']; ?></span>
                                <h1 class="banner-content__title"><?php echo $settings['title']; ?></h1>
                                <p class="banner-content__desc font-18"><?php echo $settings['content']; ?></p>
                                <div class="banner-content__button">
                                    <a href="<?php echo $settings['btn_url']; ?>" class="btn btn-main fw-normal"><?php echo $settings['btn_text']; ?>
                                        <span class="icon-right"> <i class="fas fa-arrow-right"></i> </span> 
                                    </a>
                                </div>
                            </div>            
                        </div>
                    </div>
                    <div class="col-lg-6 order-lg-0 order-1">
                        <div class="banner-five__thumb">
                            <img src="<?php echo $settings['image']['url']; ?>" alt="">
                        </div>  
                    </div>
                </div>
            </div>
        </section>
        <!-- my -->

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Banner_Five_Widget());