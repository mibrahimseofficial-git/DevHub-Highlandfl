<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Pricing_One extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-pricing-one-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Pricing 01', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-editor-list-ul';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'floor_no', [
                'label' => esc_html__('Floor No', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Type floor no.', 'cityscape-core'),
                'default' => esc_html__('Floor No.', 'cityscape-core')
            ]
        );
        $this->add_control(
            'bathroom', [
                'label' => esc_html__('Bathroom', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Bathroom', 'cityscape-core'),
                'default' => esc_html__('Bathroom', 'cityscape-core')
            ]
        );

        $this->add_control(
            'rooms', [
                'label' => esc_html__('Rooms', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Rooms', 'cityscape-core'),
                'default' => esc_html__('Rooms', 'cityscape-core')
            ]
        );
        $this->add_control(
            'totals', [
                'label' => esc_html__('Total', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Total', 'cityscape-core'),
                'default' => esc_html__('Total Area SQ.M', 'cityscape-core')
            ]
        );
        $this->add_control(
            'pricing', [
                'label' => esc_html__('Pricing', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Pricing', 'cityscape-core'),
                'default' => esc_html__('Pricing Area SQ.M', 'cityscape-core')
            ]
        );
        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'floor', [
                'label' => esc_html__('First', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('1st', 'cityscape-core'),
                'default' => esc_html__('1st', 'cityscape-core')
            ]
        );
        $repeater->add_control(
            'bath', [
                'label' => esc_html__('Bathroom', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('enter title.', 'cityscape-core'),
                'default' => esc_html__('02', 'cityscape-core')
            ]
        );
        $repeater->add_control(
            'room', [
                'label' => esc_html__('Rooms', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Rooms Number.', 'cityscape-core'),
                'default' => esc_html__('02', 'cityscape-core')
            ]
        );
        $repeater->add_control(
            'total', [
                'label' => esc_html__('Total', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Rooms Number.', 'cityscape-core'),
                'default' => esc_html__('02', 'cityscape-core')
            ]
        );
        $repeater->add_control(
            'price', [
                'label' => esc_html__('Price', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('price Number.', 'cityscape-core'),
                'default' => esc_html__('$1200', 'cityscape-core')
            ]
        );
        $repeater->add_control(
            'price_btn', [
                'label' => esc_html__('Price', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Enter price btn', 'cityscape-core'),
                'default' => esc_html__('MORE ABOUT', 'cityscape-core')
            ]
        );
        $repeater->add_control(
            'price_btn_url', [
                'label' => esc_html__('Price Url', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('enter price btn url.', 'cityscape-core'),
                'default' => esc_html__('#', 'cityscape-core')
            ]
        );
        $this->add_control('pricing_items', [
            'label' => esc_html__('Pricing Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);

        
        $this->end_controls_section();


        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('price_color', [
            'label' => esc_html__('price Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .pricing-card_price" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('price Typography', 'cityscape-core'),
            'name' => 'price_typography',
            'description' => esc_html__('price typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .pricing-card_price"
        ]);
        $this->add_control('subtitle_color', [
            'label' => esc_html__('subtitle Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .pricing-card_title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_control('list_icon_color', [
            'label' => esc_html__('list icon Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .pricing-card-details .checklist li svg" => "color: {{VALUE}}"
            ]
        ]);

        $this->add_control('btn_hover_bg_color', [
            'label' => esc_html__('btn hover bg color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .pricing-card .global-btn:before" => "background: {{VALUE}}",
                "{{WRAPPER}} .pricing-card .global-btn:after" => "background: {{VALUE}}",
            ]
        ]);
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $pricing_items = $settings['pricing_items'];
        ?>
            <!-- my -->
            <div class="table-card table-responsive">
                <table class="table common-table">
                    <thead>
                    <tr>
                        <th><?php echo $settings['floor_no']; ?></th>
                        <th><?php echo $settings['bathroom']; ?></th>
                        <th><?php echo $settings['rooms']; ?></th>
                        <th><?php echo $settings['totals']; ?></th>
                        <th><?php echo $settings['pricing']; ?></th>
                        <th> <span class="d-none">Action</span> </th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($pricing_items as $item): 
                                ?>
                        <tr>
                            <td><?php echo $item['floor']; ?></td>
                            <td><?php echo $item['bath']; ?></td>
                            <td><?php echo $item['room']; ?></td>
                            <td><?php echo $item['total']; ?></td>
                            <td><?php echo $item['price']; ?></td>
                            <td>
                                <a href="<?php echo $item['price_btn_url']; ?>" class="simple-btn text-gradient fw-semibold font-14"><?php echo $item['price_btn']; ?> 
                                    <span class="icon-right"> <i class="fa fa-arrow-right"></i> </span> 
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <!-- my -->


        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Pricing_One());