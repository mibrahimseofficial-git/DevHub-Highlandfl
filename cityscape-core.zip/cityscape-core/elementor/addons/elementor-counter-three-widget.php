<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Counter_Three extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-counter-three-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Counter Three', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-counter';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'icon', [
                'label' => esc_html__('Main Image', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
            ]
        );
        $this->add_control(
            'number', [
                'label' => esc_html__('Number', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('enter title.', 'cityscape-core'),
                'default' => esc_html__('200+', 'cityscape-core')
            ]
        );
        $this->add_control(
            'title', [
                'label' => esc_html__('title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('enter title.', 'cityscape-core'),
                'default' => esc_html__('Team member', 'cityscape-core')
            ]
        );
        $this->end_controls_section();


        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->end_controls_tabs();

        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>


        <div class="counter-three-item flx-align">
            <span class="counter-three-item__icon">
                <?php
                    Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']);
                ?>
            </span>
            <div class="counter-three-item__content">
            <?php if($settings['number']) : ?>
                <h2 class="counter-three-item__number"><?php echo $settings['number']; ?></h2>
            <?php endif; ?>
            <?php if($settings['title']) : ?>
                <span class="counter-three-item__text fw-light"><?php echo $settings['title']; ?></span>
            <?php endif; ?>
            </div>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Counter_Three());