<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Work_Process_List_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
    */
    public function get_name()
    {
        return 'cityscape-work-process-list-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Work Process List', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'work process', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-editor-list-ol';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    
    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'banner_one_content_settings_section',
            [
                'label' => esc_html__('Content Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'number',
            [
                'label' => esc_html__('Number', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('01.', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__('List Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Home Staging', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'list_content',
            [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Lorem ipsum dolor sit amet consectetur', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->add_control('list_items', [
            'label' => esc_html__('List Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);

        
        $this->end_controls_section();

        //Style tab style
        $this->start_controls_section(
            'style_settings_section',
            [
                'label' => esc_html__('Style Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('left_side_bg_color', [
            'label' => esc_html__('left side bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .cta-wrap1:before" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('left_title_color', [
            'label' => esc_html__('left title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .cta-wrap1 .title-area .sec-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('left title Typography', 'cityscape-core'),
            'name' => 'left_title_typography',
            'description' => esc_html__('left title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .cta-wrap1 .title-area .sec-title"
        ]);

        $this->add_control('right_side_bg_color', [
            'label' => esc_html__('right side bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .cta-wrap1:before" => "background: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $list_items = $settings['list_items'];
        ?>

        <?php foreach ($list_items as $item): ?>
        <div class="working-process-item d-flex align-items-center">
            <a href="<?php echo $item['link']; ?>" class="working-process-item__link"><i class="las la-long-arrow-alt-right"></i></a>
            <h2 class="working-process-item__number"><?php echo $item['number']; ?></h2>
            <div class="working-process-item__content">
                <h6 class="working-process-item__title"><?php echo $item['list_title']; ?></h6>
                <p class="working-process-item__desc font-18"><?php echo $item['list_content']; ?></p>
            </div>
        </div>
        <?php endforeach; ?>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Work_Process_List_Widget());