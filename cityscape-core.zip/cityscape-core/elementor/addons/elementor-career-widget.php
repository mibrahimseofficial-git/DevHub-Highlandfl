<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Career_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-career-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Career', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-editor-list-ul';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'career-image', [
                'label' => esc_html__('Main Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Main image', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'title', [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Networ Infra Tructure Solutions', 'cityscape-core'),
                'show_label' => true,
                'description' => esc_html__('type title', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'content', [
                'label' => esc_html__('Marquee Url', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => esc_html__('enter content.', 'cityscape-core'),
                'default' => esc_html__('IT Technology is a category a encompassing', 'cityscape-core')
            ]
        );
        
        $this->add_control('career_items', [
            'label' => esc_html__('Marquee Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->end_controls_section();


        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->end_controls_tabs();

        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        
        $settings = $this->get_settings_for_display();
        $career_items = $settings['career_items'];
        
        ?>

        <div class="wcu-card-wrap">
            <?php foreach ($career_items as $item): ?>
            <div class="wcu-card">
                <div class="icon">
                    <?php if (!empty($item['career-image'])) : ?>
                        <img src="<?php echo $item['career-image']['url']; ?>" alt="img">
                    <?php endif; ?>
                </div>
                <div class="wcu-card-details">
                    <h4 class="wcu-card-title"><?php echo $item['title']; ?></h4>
                    <p class="wcu-card-text"><?php echo $item['content']; ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
            
                        

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Career_Widget());