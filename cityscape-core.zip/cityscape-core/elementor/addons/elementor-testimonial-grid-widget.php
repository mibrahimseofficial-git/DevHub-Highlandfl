<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Testimonial_Grid_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-testimonial-grid-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Testimonial Grid', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Testimonial', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-image-box';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'image', [
                'label' => esc_html__('About_img', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('About Img One', 'cityscape-core'),
                'default' => array(
                    'url' => Utils::get_placeholder_image_src()
                )
            ]
        );
        $this->add_control(
            'number',
            [
                'label' => esc_html__('Number', 'cityscape-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => esc_html__('01', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Dream Dwell Properties', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content',
            [
                'label' => esc_html__('Subtitle', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Real Estate is a vast industry that deals with the buying, selling', 'cityscape-core'),
            ]
        );
        $this->end_controls_section();

        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('social_bg_color', [
            'label' => esc_html__('social_bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-thumb3 .social-links" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('exp_border_color', [
            'label' => esc_html__('exp border Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-thumb3 .about-counter-wrap" => "border-color: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>

        <div class="property-type-five-item">
        <?php if($settings['image']) : ?>
            <div class="property-type-five-item__thumb">
                <img src="<?php echo $settings['image']['url']; ?>" alt="Image" class="cover-img">
            </div>
        <?php endif; ?>
            <div class="property-type-five-item__content">
            <?php if($settings['number']) : ?>
                <span class="property-type-five-item__date"><?php echo $settings['number']; ?></span>
            <?php endif; ?>
            <?php if($settings['title']) : ?>
                <h6 class="property-type-five-item__title"><?php echo $settings['title']; ?></h6>
             <?php endif; ?>
            <?php if($settings['content']) : ?>
                <p class="property-type-five-item__desc"><?php echo $settings['content']; ?></p>
            <?php endif; ?>
            </div>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Testimonial_Grid_Widget());