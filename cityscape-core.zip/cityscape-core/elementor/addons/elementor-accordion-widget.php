<?php
/**
 * Elementor Widget
 * @package Fixturbo
 * @since 1.0.0
 */

namespace Elementor;
class Fixturbo_Accordion_One extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'fixturbo-accordion-one-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Accordion 01', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-editor-list-ul';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['fixturbo_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('acc_style', [
            'label' => esc_html__('acc style', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'one' => esc_html__('accordion 1', 'cityscape-core'),
                'two' => esc_html__('accordion 2', 'cityscape-core'),
                'three' => esc_html__('accordion 3', 'cityscape-core'),
            ),
            'default' => 'one',
        ]);

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'title', [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('enter title.', 'cityscape-core'),
                'default' => esc_html__('Data Entry Services', 'cityscape-core')
            ]
        );
        $repeater->add_control(
            'date', [
                'label' => esc_html__('date', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('October 19, 2022', 'cityscape-core'),
                'condition' => ['acc_style' => 'two'],
            ]
        );
        $repeater->add_control(
            'content_title', [
                'label' => esc_html__('Content Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => esc_html__('enter title.', 'cityscape-core'),
                'default' => esc_html__('The decision comes amid accumulating warnings from scientists that human-caused climate change is increasing the likelihood of more severe floods, droughts, storms and other calamities.great for:', 'cityscape-core')
            ]
        );
        $this->add_control('accordion_items', [
            'label' => esc_html__('Accordion Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->end_controls_section();

        $this->start_controls_section(
            'team_member_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('title_hover_color', [
            'label' => esc_html__('Title hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .accordion-card.style3 .accordion-button" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .accordion-card.style3 .accordion-button"
        ]);
        $this->add_control('icon_active_color', [
            'label' => esc_html__('icon active Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .accordion-card.style3 .accordion-button:not(.collapsed):after" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('accordion_bg_color', [
            'label' => esc_html__('accordion bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .accordion-card.style3:has(.accordion-button:not(.collapsed))" => "background: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $accordion_items = $settings['accordion_items'];
        $random_number = rand(999, 999999);
        ?>

        <?php if($settings['acc_style'] == 'one') : ?>
            <div class="common-accordion accordion" id="accordionExample">
                <?php $i = 0; foreach ($accordion_items as $item): ?>
                    <?php
                        $j = '';
                        $k = '';
                        if($i < 1) {
                            $j = 'show';
                            $k = 'collapsed';
                        }else {
                            $k = '';
                        }
                    ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?php echo $i; ?>">
                            <button class="accordion-button <?php echo $k; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $i; ?>" aria-expanded="true" aria-controls="collapse<?php echo $i; ?>">
                                <?php echo esc_html($item['title']); ?>
                            </button>
                        </h2>
                        <div id="collapse<?php echo $i; ?>" class="accordion-collapse collapse <?php echo $j; ?>" aria-labelledby="heading<?php echo $i; ?>" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p class="accordion-body__desc"><?php echo esc_html($item['content_title']); ?></p>
                            </div>
                        </div>
                    </div>
                <?php $i++; endforeach; ?>
            </div>
        <?php elseif($settings['acc_style'] == 'two') : ?>
            <div class="accordion-area accordion" id="eventAccordion">
                <?php $a = 10; foreach ($accordion_items as $item): ?>
                    <?php
                        $b = '';
                        $c = '';
                        if($a < 11) {
                            $b = 'show';
                            $c = 'collapsed';
                        }else {
                            $c = '';
                        }
                    ?>
                    <div class="accordion-card style4">
                        <h2 class="accordion-header" id="heading<?php echo $a; ?>">
                            <button class="accordion-button <?php echo $c; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $a; ?>" aria-expanded="true" aria-controls="collapse<?php echo $a; ?>">
                                <?php echo esc_html($item['title']); ?>
                                <span class="event-date"><?php echo esc_html($item['date']); ?></span>
                            </button>
                        </h2>
                        <div id="collapse<?php echo $a; ?>" class="accordion-collapse collapse <?php echo $b; ?>" aria-labelledby="heading<?php echo $a; ?>" data-bs-parent="#eventAccordion">
                            <div class="accordion-body">
                                <?php echo esc_html($item['content_title']); ?>
                            </div>
                        </div>
                    </div>
                <?php $a++; endforeach; ?>
            </div>
        <?php elseif($settings['acc_style'] == 'three') : ?>
            <div class="accordion-area accordion" id="faqAccordion">
                <?php $a = 20; foreach ($accordion_items as $item): ?>
                    <?php
                        $b = '';
                        $c = '';
                        if($a < 21) {
                            $b = 'show';
                            $c = 'collapsed';
                        }else {
                            $c = '';
                        }
                    ?>
                    <div class="accordion-card">
                        <h2 class="accordion-header" id="heading<?php echo $a; ?>">
                            <button class="accordion-button <?php echo $c; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $a; ?>" aria-expanded="true" aria-controls="collapse<?php echo $a; ?>">
                                <?php echo esc_html($item['title']); ?>
                                <span class="event-date"><?php echo esc_html($item['date']); ?></span>
                            </button>
                        </h2>
                        <div id="collapse<?php echo $a; ?>" class="accordion-collapse collapse <?php echo $b; ?>" aria-labelledby="heading<?php echo $a; ?>" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                <?php echo esc_html($item['content_title']); ?>
                            </div>
                        </div>
                    </div>
                <?php $a++; endforeach; ?>
            </div>
        <?php else : ?>
            <h2>Please Select Accordion Style</h2>
        <?php endif; ?>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Fixturbo_Accordion_One());