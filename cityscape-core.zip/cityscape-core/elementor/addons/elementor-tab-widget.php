<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Tab_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-tab-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Floor Tab', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'Tab', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Select Floor', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Select Floor', 'cityscape-core'),
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'name1',
            [
                'label' => esc_html__('Name 1', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Room', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'count1',
            [
                'label' => esc_html__('Count 1', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('04', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'name2',
            [
                'label' => esc_html__('Name 2', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Bathroom', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'count2',
            [
                'label' => esc_html__('Count 2', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('04', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'name3',
            [
                'label' => esc_html__('Name 3', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Total Area SQ.M', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'count3',
            [
                'label' => esc_html__('Count 3', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('13,002', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'name4',
            [
                'label' => esc_html__('Name 4', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Parking', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'count4',
            [
                'label' => esc_html__('Count 4', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('05', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'name5',
            [
                'label' => esc_html__('Name 5', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Total Price', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'count5',
            [
                'label' => esc_html__('Count 5', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('$2306.2', 'cityscape-core'),
            ]
        );
        $this->add_control('list_items', [
            'label' => esc_html__('List Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);

        $this->add_control(
            'bottom_content',
            [
                'label' => esc_html__('bottom content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('*Real estate is a lucrative industry that involves the buying selling and renting of properties. It encompasses', 'cityscape-core'),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'styling_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('tab_btn_active_color', [
            'label' => esc_html__('tab btn active Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .goal-tabs-wrapper .nav-tabs.goal-tabs-tabs .nav-link.active" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('tab_btn_hover_color', [
            'label' => esc_html__('tab btn hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .goal-tabs-wrapper .nav-tabs.goal-tabs-tabs .nav-link.hover" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('tab_btn_active_border_color', [
            'label' => esc_html__('tab btn active Border Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .goal-tabs-wrapper .nav-tabs.goal-tabs-tabs .nav-link.active" => "border-color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('btn Typography', 'cityscape-core'),
            'name' => 'btn_typography',
            'description' => esc_html__('btn typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .goal-tabs-wrapper .nav-tabs.goal-tabs-tabs .nav-link"
        ]);
        $this->add_control('tab_list_title_color', [
            'label' => esc_html__('tab list title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .goal-content .box-title" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_control('tab_list_icon_color', [
            'label' => esc_html__('tab btn icon Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .goal-content_wrapp svg path" => "fill: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $list_items = $settings['list_items'];
        ?>

        <div class="floor-plan__content">
            <div class="flx-align gap-4">
                <h6 class="text fw-normal mb-0 floor-plan__title text-white"><?php echo $settings['title']; ?></h6>
                <ul class="common-tab style-two nav nav-pills mb-0" id="pills-tab" role="tablist">
                    <?php 
                        $i = 0; 
                        foreach($list_items as $l_item) :
                        $i++;
                        
                        $active = '';
                        if($i < 2){
                            $active = 'active';
                        }
                    ?>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link <?php echo $active; ?>" id="pills-<?php echo $i; ?>-tab" data-bs-toggle="pill" data-bs-target="#pills-<?php echo $i; ?>" type="button" role="tab" aria-controls="pills-<?php echo $i; ?>" aria-selected="true"> <span class="text"><?php echo $i; ?></span> </button>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="tab-content" id="pills-tabContent">
                <?php 
                    $j = 0; 
                    foreach($list_items as $l_item) :
                    $j++;
                    
                    $active = '';
                    if($j < 2){
                        $active = 'show active';
                    }
                ?>
                <div class="tab-pane fade <?php echo $active; ?>" id="pills-<?php echo $j; ?>" role="tabpanel" aria-labelledby="pills-<?php echo $j; ?>-tab" tabindex="0">
                    <ul class="floor-plan-list">
                        <?php if($l_item['name1']) : ?>
                            <li class="floor-plan-list__item flx-between">
                                <h6 class="text fw-normal mb-0 text-white "><?php echo $l_item['name1']; ?></h6>
                                <span class="number font-16 text-white "><?php echo $l_item['count1']; ?></span>
                            </li>
                        <?php endif; ?>
                        <?php if($l_item['name2']) : ?>
                            <li class="floor-plan-list__item flx-between">
                                <h6 class="text fw-normal mb-0 text-white "><?php echo $l_item['name2']; ?></h6>
                                <span class="number font-16 text-white "><?php echo $l_item['count2']; ?></span>
                            </li>
                        <?php endif; ?>
                        <?php if($l_item['name3']) : ?>
                            <li class="floor-plan-list__item flx-between">
                                <h6 class="text fw-normal mb-0 text-white "><?php echo $l_item['name3']; ?></h6>
                                <span class="number font-16 text-white "><?php echo $l_item['count3']; ?></span>
                            </li>
                        <?php endif; ?>
                        <?php if($l_item['name4']) : ?>
                            <li class="floor-plan-list__item flx-between">
                                <h6 class="text fw-normal mb-0 text-white "><?php echo $l_item['name4']; ?></h6>
                                <span class="number font-16 text-white "><?php echo $l_item['count4']; ?></span>
                            </li>
                        <?php endif; ?>
                        <?php if($l_item['name5']) : ?>
                            <li class="floor-plan-list__item flx-between">
                                <h6 class="text fw-normal mb-0 text-white "><?php echo $l_item['name5']; ?></h6>
                                <span class="number font-16 text-white "><?php echo $l_item['count5']; ?></span>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <?php endforeach; ?>

            </div>
            <?php if($settings['bottom_content']) : ?>
                <p class="floor-plan__desc font-18 fw-light"><?php echo $settings['bottom_content']; ?></p>
            <?php endif; ?>
        </div>
    
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Tab_Widget());