<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Accordion_Two_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-accordion-two-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Accordion 02', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-editor-list-ul';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'subtitle', [
                'label' => esc_html__('subTitle', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('enter subtitle.', 'cityscape-core'),
                'default' => esc_html__('Ask question', 'cityscape-core')
            ]
        );
        $this->add_control(
            'title', [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('enter title.', 'cityscape-core'),
                'default' => esc_html__('Let us find the perfect property for you', 'cityscape-core')
            ]
        );

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'title', [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('enter title.', 'cityscape-core'),
                'default' => esc_html__('Data Entry Services', 'cityscape-core')
            ]
        );
        $repeater->add_control(
            'date', [
                'label' => esc_html__('date', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('October 19, 2022', 'cityscape-core'),
                'condition' => ['acc_style' => 'two'],
            ]
        );
        $repeater->add_control(
            'content_title', [
                'label' => esc_html__('Content Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => esc_html__('enter title.', 'cityscape-core'),
                'default' => esc_html__('The decision comes amid accumulating warnings from scientists that human-caused climate change is increasing the likelihood of more severe floods, droughts, storms and other calamities.great for:', 'cityscape-core')
            ]
        );
        $this->add_control('accordion_items', [
            'label' => esc_html__('Accordion Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->add_control(
            'right_img', [
                'label' => esc_html__('Right_img', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Right Img', 'cityscape-core'),
                'default' => array(
                    'url' => Utils::get_placeholder_image_src()
                )
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'team_member_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('title_hover_color', [
            'label' => esc_html__('Title hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .accordion-card.style3 .accordion-button" => "color: {{VALUE}}"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .accordion-card.style3 .accordion-button"
        ]);
        $this->add_control('icon_active_color', [
            'label' => esc_html__('icon active Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .accordion-card.style3 .accordion-button:not(.collapsed):after" => "background: {{VALUE}}"
            ]
        ]);
        $this->add_control('accordion_bg_color', [
            'label' => esc_html__('accordion bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .accordion-card.style3:has(.accordion-button:not(.collapsed))" => "background: {{VALUE}}"
            ]
        ]);
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $accordion_items = $settings['accordion_items'];
        $random_number = rand(999, 999999);
        ?>

        <section class="faq padding-y-120 mt-minus-120">
            <div class="container container-two">
                <div class="row">
                    <div class="col-lg-6 pe-xl-5">
                        <div class="section-heading style-left mb-lg-5 mb-4">
                            <span class="section-heading__subtitle bg-gray-100"> 
                                <span class="text-gradient fw-semibold"><?php echo $settings['subtitle']; ?></span>
                            </span>
                            <h2 class="section-heading__title"><?php echo $settings['title']; ?></h2>
                        </div>
                        <div class="common-accordion accordion" id="accordionExample">
                            <?php $i = 0; foreach ($accordion_items as $item): ?>
                                <?php
                                    $j = '';
                                    $k = '';
                                    if($i < 1) {
                                        $j = 'show';
                                        $k = 'collapsed';
                                        $l = '';
                                    }else {
                                        $k = '';
                                        $l = 'collapsed';
                                    }
                                ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading<?php echo $i; ?>">
                                        <button class="accordion-button <?php echo $k; ?> <?php echo $l; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $i; ?>" aria-expanded="true" aria-controls="collapse<?php echo $i; ?>">
                                            <?php echo esc_html($item['title']); ?>
                                        </button>
                                    </h2>
                                    <div id="collapse<?php echo $i; ?>" class="accordion-collapse collapse <?php echo $j; ?>" aria-labelledby="heading<?php echo $i; ?>" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p class="accordion-body__desc"><?php echo esc_html($item['content_title']); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php $i++; endforeach; ?>
                        </div>
                    </div>
                    <div class="col-lg-6  d-lg-block d-none">
                        <div class="faq-thumb">
                            <img src="<?php echo $settings['right_img']['url']; ?>" alt="img">
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Accordion_Two_Widget());