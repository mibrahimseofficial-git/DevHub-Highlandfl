<?php
/**
 * Elementor Widget
 * @package cityscape
 * @since 1.0.0
 */

namespace Elementor;

class Cityscape_Testimonial_Slider_One_Two_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-testimonial-slider-two';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Testimonial Slider Two', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-slides';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__('Slider Content', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'subtitle', [
                'label' => esc_html__('Subtitle', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('clients testimonial', 'cityscape-core'),
                'show_label' => true,
                'description' => esc_html__('upload subtitle', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title', [
                'label' => esc_html__('Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Your satisfaction is our top a the priority', 'cityscape-core'),
                'show_label' => true,
                'description' => esc_html__('upload title', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content', [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Real estate is a lucrative ind involves the buying selling and reproperties. It Real estate is a lucrative ind involves. Real estate is a lucrative', 'cityscape-core'),
                'show_label' => true,
                'description' => esc_html__('upload content', 'cityscape-core'),
            ]
        );

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'image', [
                'label' => esc_html__('Main Image', 'cityscape-core'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Upload Main image', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'name', [
                'label' => esc_html__('Name', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Jhon Suria', 'cityscape-core'),
                'show_label' => true,
                'description' => esc_html__('upload name', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'designation', [
                'label' => esc_html__('Designation', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Marketing Coordinator', 'cityscape-core'),
                'description' => esc_html__('upload designation', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'content', [
                'label' => esc_html__('Content', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'show_label' => false,
                'default' => esc_html__('Real estate is a lucrativ ind involves the buying selling and Real estate a is a lucrative indinvolves buyingrep pertiesen cos residentialreproperties. It encompasses residential  Real estate a is a lucrative'),
                'description' => esc_html__('Upload Content', 'cityscape-core'),
            ]
        );
        $repeater->add_control(
            'rating', [
                'label' => esc_html__('Rating', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('5', 'cityscape-core'),
            ]
        );
        $this->add_control('testimonial_items', [
            'label' => esc_html__('Testimonial Slider Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'image' => array(
                        'url' => Utils::get_placeholder_image_src()
                    )
                ]
            ],
        ]);
        $this->end_controls_section();


        $this->start_controls_section(
            'slider_control_section',
            [
                'label' => esc_html__('Slider Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('nav_position', [
            'label' => esc_html__('Nav Position', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'style-1' => esc_html__('default', 'cityscape-core'),
                'slider-control-right-top' => esc_html__('Top Right', 'cityscape-core'),
            ),
            'default' => 'style-1',
            'description' => esc_html__('Select price style', 'cityscape-core')
        ]);
        $this->add_control(
            'items',
            [
                'label' => esc_html__('slidesToShow', 'cityscape-core'),
                'type' => Controls_Manager::NUMBER,
                'description' => esc_html__('you can set how many item show in slider', 'cityscape-core'),
                'default' => '1',
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => esc_html__('Loop', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__('Autoplay', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'nav',
            [
                'label' => esc_html__('Nav', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => 'yes'
            ]
        );
        $this->add_control(
            'nav_left_arrow',
            [
                'label' => esc_html__('Nav Left Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-angle-left',
                    'library' => 'solid',
                ],
                'condition' => ['nav' => 'yes']
            ]
        );
        $this->add_control(
            'nav_right_arrow',
            [
                'label' => esc_html__('Nav Right Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-angle-right',
                    'library' => 'solid',
                ],
                'condition' => ['nav' => 'yes']
            ]
        );
        $this->add_control(
            'center',
            [
                'label' => esc_html__('Center', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),

            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'brand_member_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('icon_bg_color', [
            'label' => esc_html__('icon bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .testi-box .quote-icon" => "background: {{VALUE}}"
            ]
        ]);

        $this->end_controls_section();

    }


    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $all_testimonial_items = $settings['testimonial_items'];

        $rand_numb = rand(333, 999999999);
        //slider settings
        $slider_settings = [
            "loop" => esc_attr($settings['loop']),
            "items" => esc_attr($settings['items'] ?? 1),
            "center" => esc_attr($settings['center']),
            "autoplay" => esc_attr($settings['autoplay']),
            "nav" => esc_attr($settings['nav']),
            "navleft" => cityscape_core()->render_elementor_icons($settings['nav_left_arrow']),
            "navright" => cityscape_core()->render_elementor_icons($settings['nav_right_arrow'])
        ];
        
        ?>
        
        <div class="testimonials-three">
            <div class="testimonials-three__inner position-relative">
                <div class="row align-items-center gy-4">
                    <div class="col-lg-5">
                        <div class="testimonials-three__box">
                            <div class="section-heading style-left mb-0">
                                <span class="section-heading__subtitle bg-white"> 
                                <span class="text-gradient fw-semibold"><?php echo $settings['subtitle']; ?></span> 
                                </span>
                                <h2 class="section-heading__title"><?php echo $settings['title']; ?></h2>
                                <p class="section-heading__desc text-heading"><?php echo $settings['content']; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="testimonials-three__wrapper">
                        <?php foreach ($all_testimonial_items as $testimonial_item): ?>
                            <div class="testimonial-item style-two">
                                <div class="testimonial-item__top flx-between gap-2">
                                    <div class="testimonial-item__info flx-align">
                                        <div class="testimonial-item__thumb">
                                            <img src="<?php echo $testimonial_item['image']['url']; ?>" alt="">
                                        </div>
                                        <div>
                                            <h6 class="testimonial-item__name"><?php echo esc_html($testimonial_item['name']); ?></h6>
                                            <span class="testimonial-item__designation"><?php echo esc_html($testimonial_item['designation']); ?></span>
                                        </div>
                                    </div>
                                    <ul class="star-rating flx-align justify-content-end">
                                        <?php
                                            for ($i=0; $i < $testimonial_item['rating']; $i++) {  ?>
                                                <li class="star-rating__item"><i class="fa fa-star"></i></li>
                                            <?php }
                                        ?>
                                    </ul>
                                </div>
                                <p class="testimonial-item__desc mb-0"><?php echo esc_html($testimonial_item['content']); ?></p>
                            </div>
                        <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Testimonial_Slider_One_Two_Widget());