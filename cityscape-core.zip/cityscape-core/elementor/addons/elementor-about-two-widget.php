<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_About_Two_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-about-two-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('About Two', 'cityscape-core');
    }

    public function get_keywords()
    {
        return ['Section', 'About', 'Title', "HugeBinary", 'Cityscape'];
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-heading';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('KNOW ABOUT US', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => esc_html__('Sub Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Making Your Real Estate Dreams a Reality', 'cityscape-core'),
            ]
        );
        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            'list_title',
            [
                'label' => esc_html__('List Title', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Prestige Property Management Your Dream Home Awaits', 'cityscape-core'),
            ]
        );
        $this->add_control('list_items', [
            'label' => esc_html__('List Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);


        $this->add_control(
            'btn_text',
            [
                'label' => esc_html__('Btn Text', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Add Listing', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'btn_url',
            [
                'label' => esc_html__('Btn Url', 'cityscape-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'styling_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('subtitle_color', [
            'label' => esc_html__('Sub Title Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-two__content .section-heading__subtitle span" => "color: {{VALUE}} !important"
            ]
        ]);
        $this->add_control('subtitle_bg_color', [
            'label' => esc_html__('Sub Title Bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .about-two__content .section-heading__subtitle" => "background-color: {{VALUE}} !important"
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .about-two__content .section-heading__title"
        ]);
        $this->end_controls_section();
    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $list_items = $settings['list_items'];
        ?>

        <!-- My -->
        <div class="about-two__content">
            <div class="section-heading style-left">
                <span class="section-heading__subtitle bg-transparent"> <span class="text-gradient fw-semibold"><?php echo $settings['subtitle']; ?></span> </span>
                <h2 class="section-heading__title text-white"><?php echo $settings['title']; ?></h2>
            </div>
            <ul class="check-list pt-lg-5 mt-4">
                <?php foreach ($list_items as $item): ?>
                    <li class="check-list__item d-flex align-items-center ps-0">
                        <span class="icon"><i class="fa fa-check"></i></span>
                        <span class="text  text-white fw-light font-16"><?php echo $item['list_title']; ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
            <div class="about-two__button">
                <a href="<?php echo $settings['btn_url']; ?>" class="btn btn-main"> <?php echo $settings['btn_text']; ?> 
                    <span class="icon-right icon"> 
                    <i class="fa fa-arrow-right"></i> 
                    </span>
                </a>
            </div>
        </div>
        <!-- My -->
        
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_About_Two_Widget());