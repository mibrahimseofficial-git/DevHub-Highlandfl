<?php
/**
 * Elementor Widget
 * @package cityscape
 * @since 1.0.0
 */

namespace Elementor;

class Cityscape_Blog_Slider_Three_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-blog-slider-three-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Blog Slider three', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-person';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__('Slider Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('read-btn', [
            'label' => esc_html__('Read More', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'description' => esc_html__('enter read button text', 'cityscape-core'),
            'default' => esc_html__('Read More', 'cityscape-core'),
        ]);
        $this->add_control('total', [
            'label' => esc_html__('Total Posts', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '-1',
            'description' => esc_html__('enter how many course you want in masonry , enter -1 for unlimited course.')
        ]);
        $this->add_control('category', [
            'label' => esc_html__('Category', 'cityscape-core'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => cityscape()->get_terms_names('service-cat', 'id'),
            'description' => esc_html__('select category as you want, leave it blank for all category', 'cityscape-core'),
        ]);
        $this->add_control('order', [
            'label' => esc_html__('Order', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ASC' => esc_html__('Ascending', 'cityscape-core'),
                'DESC' => esc_html__('Descending', 'cityscape-core'),
            ),
            'default' => 'ASC',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
       
        $this->add_control('orderby', [
            'label' => esc_html__('OrderBy', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ID' => esc_html__('ID', 'cityscape-core'),
                'title' => esc_html__('Title', 'cityscape-core'),
                'date' => esc_html__('Date', 'cityscape-core'),
                'rand' => esc_html__('Random', 'cityscape-core'),
                'comment_count' => esc_html__('Most Comments', 'cityscape-core'),
            ),
            'default' => 'ID',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->end_controls_section();

        $this->start_controls_section(
            'blog_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'image_height',
            [
                'label' => esc_html__('Image Height', 'sastek-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-card .blog-img img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control('title_hover_color', [
            'label' => esc_html__('title_hover_color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .blog-title a:hover" => "color: {{VALUE}}",
            ]
        ]);
        $this->add_group_control(Group_Control_Typography::get_type(), [
            'label' => esc_html__('title Typography', 'cityscape-core'),
            'name' => 'title_typography',
            'description' => esc_html__('title typography', 'cityscape-core'),
            'selector' => "{{WRAPPER}} .blog-title"
        ]);
        $this->add_control('blog_icon_color', [
            'label' => esc_html__('blog_icon_color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .blog-card .blog-meta p svg" => "color: {{VALUE}}",
            ]
        ]);
        $this->end_controls_section();

    }


    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rand_numb = rand(333, 999999999);
        //slider settings
        $slider_settings = [
            "margin" => esc_attr($settings['margin']['size'] ?? 0),
            "items" => esc_attr($settings['items'] ?? 1),
        ];
        //query settings
        $total_posts = $settings['total'];
        $category = $settings['category'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        //setup query
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $total_posts,
            'order' => $order,
            'orderby' => $orderby,
            'post_status' => 'publish'
        );

        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'service-cat',
                    'field' => 'term_id',
                    'terms' => $category
                )
            );
        }
        $post_data = new \WP_Query($args);
        ?>

        <div class="row global-carousel blog-slider slider-shadow" data-slide-show="3" data-lg-slide-show="2"
            data-md-slide-show="1" data-sm-slide-show="1" data-xs-slide-show="1" data-dots="false">

            <?php while ($post_data->have_posts()) : $post_data->the_post();
        
                //image condition here
                $img_id = get_post_thumbnail_id(get_the_ID()) ? get_post_thumbnail_id(get_the_ID()) : false;
                $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'fixturbo_grid_blog_12', false) : '';
                $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

                $comments_count = get_comments_number(get_the_ID());
                $comment_text = ($comments_count > 1) ? 'Comments (' . $comments_count . ')' : 'Comment (' . $comments_count . ')';
                ?> 

                <div class="col-md-6 col-lg-4">
                    <div class="blog-box">
                        <div class="blog-img">
                            <img src="<?php echo esc_url($img_url); ?>" alt="blog image">
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <a href="blog.html"><i class="fas fa-calendar-alt"></i> <?php echo date('F j, Y') ?></a>
                                <a href="blog.html"><i class="fas fa-comments"></i> <?php cityscape()->comment_count(); ?></a>
                            </div>
                            <h3 class="blog-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <p class="blog-desc"><?php echo wp_trim_words(get_the_content(), 12); ?></p>
                            <?php if($settings['read-btn']) : ?>
                                <a class="global-btn style-border" href="<?php the_permalink(); ?>">
                                    <?php echo $settings['read-btn']; ?>
                                    <svg class="svg-inline--fa fa-arrow-right fa-w-14 ms-2" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><path fill="currentColor" d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"></path></svg>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Blog_Slider_Three_Widget());