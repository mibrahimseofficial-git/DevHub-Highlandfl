<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Project_Info_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-project-info-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Project Info', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-slider-album';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('client_name', [
            'label' => esc_html__('client_name', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Sandi leo rakiul', 'cityscape-core'),
        ]);
        $this->add_control('amount', [
            'label' => esc_html__('amount', 'cityscape-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('150000 USD', 'cityscape-core'),
        ]);
        $this->add_control('category', [
            'label' => esc_html__('category', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Planing, Real Estate', 'cityscape-core'),
        ]);
        $this->add_control('date', [
            'label' => esc_html__('date', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Starline shimlasi', 'cityscape-core'),
        ]);

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            's_icon',
            [
                'label' => esc_html__('Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('select Icon.', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-phone-alt',
                    'library' => 'solid',
                ],
            ]
        );
        $repeater->add_control(
            's_url', [
                'label' => esc_html__('Social url', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->add_control('social_items', [
            'label' => esc_html__('social Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display(); 
        $social_items = $settings['social_items'];
        ?>

        <div class="project-sidebar__box">
            <ul class="project-sidebar">
                <?php if($settings['client_name']) : ?>
                    <li class="project-sidebar__item">
                        <span class="project-sidebar__text font-12">Client</span>
                        <h6 class="project-sidebar__title font-16 fw-semibold mb-0"><?php echo $settings['client_name']; ?></h6>
                    </li>
                <?php endif; ?>
                <?php if($settings['amount']) : ?>
                    <li class="project-sidebar__item">
                        <span class="project-sidebar__text font-12"><?php echo $settings['amount']; ?></span>
                        <h6 class="project-sidebar__title font-16 fw-semibold mb-0">consultation real estate </h6>
                    </li>
                <?php endif; ?>
                <?php if($settings['category']) : ?>
                    <li class="project-sidebar__item">
                        <span class="project-sidebar__text font-12">Category</span>
                        <h6 class="project-sidebar__title font-16 fw-semibold mb-0"><?php echo $settings['category']; ?></h6>
                    </li>
                <?php endif; ?>
                <?php if($settings['date']) : ?>
                    <li class="project-sidebar__item">
                        <span class="project-sidebar__text font-12">Date</span>
                        <h6 class="project-sidebar__title font-16 fw-semibold mb-0"><?php echo $settings['date']; ?></h6>
                    </li>
                <?php endif; ?>
            </ul>
            <ul class="social-share-list style-two mt-lg-5 mt-4">
                <?php foreach ($social_items as $s_item) : ?>
                    <li class="social-share-list__item">
                        <a href="<?php echo $s_item['s_url']; ?>" class="social-share-list__link">
                            <?php
                                Icons_Manager::render_icon($s_item['s_icon'], ['aria-hidden' => 'true']);
                            ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Project_Info_Widget());