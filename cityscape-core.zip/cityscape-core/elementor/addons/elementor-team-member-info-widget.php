<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Team_member_Info_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-team-member-info-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Team member Info', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-slider-album';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('name', [
            'label' => esc_html__('name', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Fahad Bhuiyan', 'cityscape-core'),
        ]);
        $this->add_control('designation', [
            'label' => esc_html__('designation', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => esc_html__('Mnager', 'cityscape-core'),
        ]);
        $this->add_control('content', [
            'label' => esc_html__('content', 'cityscape-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('This category focuses on the design construction of buildings and the This a category focuses on the design and construction of buildings', 'cityscape-core'),
        ]);
        $this->add_control('address', [
            'label' => esc_html__('address', 'cityscape-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('Burmsille Street, MN 55337, <br> United States', 'cityscape-core'),
        ]);
        $this->add_control('phone', [
            'label' => esc_html__('phone', 'cityscape-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('+(1) 123 456 7890 <br> +(1) 098 765 4321', 'cityscape-core'),
        ]);
        $this->add_control('email', [
            'label' => esc_html__('email', 'cityscape-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => esc_html__('info@fixturbo.com <br> info.example@fixturbo.com', 'cityscape-core'),
        ]);

        $repeater = new \Elementor\Repeater();
        $repeater->add_control(
            's_icon',
            [
                'label' => esc_html__('Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('select Icon.', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-phone-alt',
                    'library' => 'solid',
                ],
            ]
        );
        $repeater->add_control(
            's_url', [
                'label' => esc_html__('Social url', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'cityscape-core'),
            ]
        );
        $this->add_control('social_items', [
            'label' => esc_html__('social Item', 'cityscape-core'),
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
        ]);
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display(); 
        $social_items = $settings['social_items'];
        ?>

        <div class="team-details-wrap">
            <?php if($settings['name']) : ?>
                <h4 class="team-details-wrap-title"><?php echo $settings['name']; ?></h4>
            <?php endif; ?>
            <?php if($settings['designation']) : ?>
                <h6 class="team-details-wrap-desig"><?php echo $settings['designation']; ?></h6>
            <?php endif; ?>
            <?php if($settings['content']) : ?>
                <p class="team-details-wrap-text mb-30"><?php echo $settings['content']; ?></p>
            <?php endif; ?>
            <div class="team-details-wrap_info">
                <span class="icon"><i class="fas fa-map-marker-alt"></i></span>
                <p><?php echo $settings['address']; ?></p>
            </div>
            <div class="team-details-wrap_info">
                <span class="icon"><i class="fas fa-phone-alt"></i></span>
                <p><?php echo $settings['phone']; ?></p>
            </div>
            <div class="team-details-wrap_info">
                <span class="icon"><i class="fas fa-envelope"></i></span>
                <p><?php echo $settings['email']; ?></p>
            </div>
            <div class="social-btn style4 mt-35">
                <?php foreach ($social_items as $s_item) : ?>
                    <a href="<?php echo $s_item['s_url']; ?>" tabindex="-1">
                        <?php
                            Icons_Manager::render_icon($s_item['s_icon'], ['aria-hidden' => 'true']);
                        ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Team_member_Info_Widget());