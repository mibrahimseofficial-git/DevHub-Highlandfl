<?php
/**
 * Elementor Widget
 * @package cityscape
 * @since 1.0.0
 */

namespace Elementor;

class Cityscape_Team_Slider_One_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-team-slider-one-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Team Slider One', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-person';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'slider_settings_section',
            [
                'label' => esc_html__('Slider Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('total', [
            'label' => esc_html__('Total Posts', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '-1',
            'description' => esc_html__('enter how many course you want in masonry , enter -1 for unlimited course.')
        ]);
        $this->add_control('category', [
            'label' => esc_html__('Category', 'cityscape-core'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => cityscape()->get_terms_names('team-cat', 'id'),
            'description' => esc_html__('select category as you want, leave it blank for all category', 'cityscape-core'),
        ]);
        $this->add_control('order', [
            'label' => esc_html__('Order', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ASC' => esc_html__('Ascending', 'cityscape-core'),
                'DESC' => esc_html__('Descending', 'cityscape-core'),
            ),
            'default' => 'ASC',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->add_control('orderby', [
            'label' => esc_html__('OrderBy', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ID' => esc_html__('ID', 'cityscape-core'),
                'title' => esc_html__('Title', 'cityscape-core'),
                'date' => esc_html__('Date', 'cityscape-core'),
                'rand' => esc_html__('Random', 'cityscape-core'),
                'comment_count' => esc_html__('Most Comments', 'cityscape-core'),
            ),
            'default' => 'ID',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->add_control(
            'items',
            [
                'label' => esc_html__('slidesToShow', 'cityscape-core'),
                'type' => Controls_Manager::NUMBER,
                'description' => esc_html__('you can set how many item show in slider', 'cityscape-core'),
                'default' => '3',
            ]
        );
        $this->add_control(
            'margin',
            [
                'label' => esc_html__('Margin', 'cityscape-core'),
                'description' => esc_html__('you can set margin for slider', 'cityscape-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 5,
                    ]
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'size_units' => ['px']
            ]
        );
        $this->add_control(
            'loop',
            [
                'label' => esc_html__('Loop', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__('Autoplay', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'nav_left_arrow',
            [
                'label' => esc_html__('Nav Left Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-arrow-left',
                    'library' => 'solid',
                ],
                'condition' => ['nav' => 'yes']
            ]
        );
        $this->add_control(
            'nav_right_arrow',
            [
                'label' => esc_html__('Nav Right Icon', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),
                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
                'condition' => ['nav' => 'yes']
            ]
        );
        $this->add_control(
            'center',
            [
                'label' => esc_html__('Center', 'cityscape-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes/no to enable/disable', 'cityscape-core'),

            ]
        );
        $this->add_control(
            'autoplaytimeout',
            [
                'label' => esc_html__('Autoplay Timeout', 'cityscape-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10000,
                        'step' => 2,
                    ]
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5000,
                ],
                'size_units' => ['px'],
                'condition' => array(
                    'autoplay' => 'yes'
                )
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'team_member_styling_settings_section',
            [
                'label' => esc_html__('Styling Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('social_bg', [
            'label' => esc_html__('Social bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .team-card .global-social" => "background-color: {{VALUE}}"
            ]
        ]);
        $this->add_control('social_icon', [
            'label' => esc_html__('Social Icon Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .team-social .global-social a" => "color: {{VALUE}}",
            ]
        ]);
        $this->add_control('title_hover_color', [
            'label' => esc_html__('Title hover Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .team-card_content h4.team-card_title a:hover" => "color: {{VALUE}}",
            ]
        ]);
        $this->add_control('slick_arrow_style_border', [
            'label' => esc_html__('slick arrow style border', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .slick-carousel-controls .slick-arrow" => "border-color: {{VALUE}}",
            ]
        ]);
        $this->add_control('slick_arrow_style', [
            'label' => esc_html__('slick arrow style', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .slick-carousel-controls .slick-arrow" => "color: {{VALUE}}",
                "{{WRAPPER}} .slick-carousel-controls .slick-arrow:hover" => "background: {{VALUE}}",
            ]
        ]);
        $this->add_control('slick_arrow_style_hover', [
            'label' => esc_html__('slick arrow style Hover', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .slick-carousel-controls .slick-arrow:hover" => "color: {{VALUE}}",
            ]
        ]);
        $this->end_controls_section();

    }


    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rand_numb = rand(333, 999999999);
        //slider settings
        $slider_settings = [
            "loop" => esc_attr($settings['loop']),
            "margin" => esc_attr($settings['margin']['size'] ?? 0),
            "items" => esc_attr($settings['items'] ?? 1),
            "center" => esc_attr($settings['center']),
            "autoplay" => esc_attr($settings['autoplay']),
            "autoplaytimeout" => esc_attr($settings['autoplaytimeout']['size'] ?? 0),
            "navleft" => cityscape_core()->render_elementor_icons($settings['nav_left_arrow']),
            "navright" => cityscape_core()->render_elementor_icons($settings['nav_right_arrow'])
        ];
        //query settings
        $total_posts = $settings['total'];
        $category = $settings['category'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        //setup query
        $args = array(
            'post_type' => 'team',
            'posts_per_page' => $total_posts,
            'order' => $order,
            'orderby' => $orderby,
            'post_status' => 'publish'
        );

        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'team-cat',
                    'field' => 'term_id',
                    'terms' => $category
                )
            );
        }
        $post_data = new \WP_Query($args);
        ?>

        <div class="team-area-1">
            <div class="row gx-30 global-carousel team-slider2" data-slide-show="4" data-xl-slide-show="3"
                data-lg-slide-show="3" data-md-slide-show="2" data-sm-slide-show="1" data-dots="true" data-xl-dots="true"
                data-ml-dots="true" data-lg-dots="true" data-md-dots="true">
                <?php
                while ($post_data->have_posts()) : $post_data->the_post();
                    $post_id = get_the_ID();
                    $img_id = get_post_thumbnail_id($post_id) ? get_post_thumbnail_id($post_id) : false;
                    $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'full', false) : '';
                    $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                    $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
                    $team_single_meta_data = get_post_meta(get_the_ID(), 'cityscape_team_options', true);

                    
                    $social_icons = isset($team_single_meta_data['social-icons']) && !empty($team_single_meta_data['social-icons']) ? $team_single_meta_data['social-icons'] : '';

                    // icon
                     $team_icon = isset($team_single_meta_data['team_icon']) && !empty($team_single_meta_data['team_icon']) ? $team_single_meta_data['team_icon'] : '';

                    ?>
                    <div class="col-lg-6">
                        <div class="team-card">
                            <div class="team-card_wrapp">
                                <div class="team-card_img">
                                    <img src="<?php echo esc_url($img_url) ?>" alt="img">
                                </div>
                                <div class="team-social">
                                    <div class="plus-btn">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                            <path d="M14 3C14 4.65625 12.6562 6 11 6C10.1875 6 9.4375 5.6875 8.90625 5.1875L5.96875 6.65625C5.96875 6.75 5.96875 6.875 5.96875 7C5.96875 7.125 5.96875 7.25 5.96875 7.375L8.90625 8.84375C9.4375 8.34375 10.1875 8 11 8C12.6562 8 14 9.34375 14 11C14 12.6562 12.6562 14 11 14C9.3125 14 8 12.6562 8 11C8 10.875 8 10.75 8 10.6562L5.0625 9.1875C4.53125 9.6875 3.78125 10 3 10C1.3125 10 0 8.65625 0 7C0 5.34375 1.3125 4 3 4C3.78125 4 4.53125 4.34375 5.0625 4.84375L8 3.375C8 3.25 8 3.125 8 3C8 1.34375 9.3125 0 11 0C12.6562 0 14 1.34375 14 3ZM2.96875 8C3.53125 8 3.96875 7.5625 3.96875 7C3.96875 6.46875 3.53125 6 2.96875 6C2.4375 6 1.96875 6.46875 1.96875 7C1.96875 7.5625 2.4375 8 2.96875 8ZM11 2C10.4375 2 10 2.46875 10 3C10 3.5625 10.4375 4 11 4C11.5312 4 12 3.5625 12 3C12 2.46875 11.5312 2 11 2ZM11 12C11.5312 12 12 11.5625 12 11C12 10.4688 11.5312 10 11 10C10.4375 10 10 10.4688 10 11C10 11.5625 10.4375 12 11 12Z" fill="#19352D"/>
                                        </svg>
                                    </div>
                                    <div class="global-social">
                                        <?php
                                            if (!empty($social_icons)) {
                                                foreach ($social_icons as $item) {
                                                    printf('<a href="%1$s"><i class="%2$s"></i></a>', $item['url'], $item['icon']);
                                                }
                                            }
                                        ?> 
                                    </div>
                                </div>
                            </div>
                            <div class="team-card_content">
                                <h4 class="team-card_title"><a href="<?php the_permalink() ?>"><?php echo esc_html(get_the_title($post_id)) ?></a>
                                </h4>
                                <span class="team-card_desig"><?php echo $team_single_meta_data['designation'] ?></span>

                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Team_Slider_One_Widget());