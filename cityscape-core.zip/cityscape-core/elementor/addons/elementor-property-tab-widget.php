<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Property_Tab_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-property-tab-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Property Tab', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-slider-album';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control('read_more', [
            'label' => esc_html__('Read More', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'description' => esc_html__('enter read button text', 'cityscape-core'),
            'default' => esc_html__('Read More', 'cityscape-core'),
        ]);
        $this->add_control('total', [
            'label' => esc_html__('Total Posts', 'cityscape-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '-1',
            'description' => esc_html__('enter how many post you want in masonry , enter -1 for unlimited post.')
        ]);
        $this->add_control('category', [
            'label' => esc_html__('Category', 'cityscape-core'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => cityscape_core()->get_terms_names('category', 'id'),
            'description' => esc_html__('select category as you want, leave it blank for all category', 'cityscape-core'),
        ]);
        $this->add_control('order', [
            'label' => esc_html__('Order', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ASC' => esc_html__('Ascending', 'cityscape-core'),
                'DESC' => esc_html__('Descending', 'cityscape-core'),
            ),
            'default' => 'DESC',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->add_control('orderby', [
            'label' => esc_html__('OrderBy', 'cityscape-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ID' => esc_html__('ID', 'cityscape-core'),
                'title' => esc_html__('Title', 'cityscape-core'),
                'date' => esc_html__('Date', 'cityscape-core'),
                'rand' => esc_html__('Random', 'cityscape-core'),
                'comment_count' => esc_html__('Most Comments', 'cityscape-core'),
            ),
            'default' => 'ID',
            'description' => esc_html__('select order', 'cityscape-core')
        ]);
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rand_numb = rand(333, 999999999);
        //query settings
        $total_posts = $settings['total'];
        $category = $settings['category'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        ?>

        <div class="property-list-item-wrap">
            <div class="text-center">
                <ul class="common-tab nav nav-pills justify-content-center mb-40" id="pills-tab" role="tablist">
                    <?php 
                    $taxonomy = 'at_biz_dir-category';
                    $terms = get_terms($taxonomy); // Get all terms of a taxonomy

                    if ( $terms && !is_wp_error( $terms ) ) :
                    $j = 0;
                    foreach ( $terms as $term ) { 

                        if ($j<1) {
                           $active = 'active';
                        }else {
                            $active = '';
                        }

                        $thumbnail_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
                        $image = wp_get_attachment_url( $thumbnail_id );  ?>    

                        <?php
                            $term_name = $term->name;
                            $term_name_slug = str_replace(' ', '', $term_name);
                        ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link bg-transparent <?php echo $active; ?>" id="pills-<?php echo $term_name_slug; ?>-tab" data-bs-toggle="pill" data-bs-target="#pills-<?php echo $term_name_slug; ?>" type="button" role="tab" aria-controls="pills-<?php echo $term_name_slug; ?>" aria-selected="true">
                                <?php echo $term_name_slug; ?>
                            </button>
                        </li>
                        <?php $j++; } ?>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="tab-content" id="pills-tabContent">
                <?php
                $taxonomy = 'at_biz_dir-category';
                $terms = get_terms($taxonomy); // Get all terms of a taxonomy

                if ( $terms && !is_wp_error( $terms ) ) :
                $i = 0;
                foreach ( $terms as $term ) { 
                    if ($i<1) {
                       $active = 'active';
                    }else {
                        $active = '';
                    }
                    $thumbnail_id = get_term_meta( $term->term_id, 'thumbnail_id', true );
                    $image = wp_get_attachment_url( $thumbnail_id );  
                    global $product; ?> 

                    <?php
                        $term_name = $term->name;
                        $term_name_slug = str_replace(' ', '', $term_name);
                    ?>
                    <div class="tab-pane fade show <?php echo $active; ?>" id="pills-<?php echo $term_name_slug; ?>" role="tabpanel" aria-labelledby="pills-<?php echo $term_name_slug; ?>-tab" tabindex="0">
                        <div class="row gy-4">
                            <?php if($term->count > 0) : ?>
                                <?php
                                $query = new \WP_Query( array(
                                    'post_type'      => 'at_biz_dir',
                                    'posts_per_page' => $total_posts,
                                    'order' => $order,
                                    'orderby' => $orderby,
                                    'post_status'    => 'publish',
                                    'tax_query'      => array( array(
                                        'taxonomy'   => 'at_biz_dir-category',
                                        'field'      => 'term_id',
                                        'terms'      => array( $term->term_id ),
                                    ) )
                                ) );

                                while ( $query->have_posts() ) : $query->the_post();  
                                    $post_id = get_the_ID();
                                    $img_id = get_post_thumbnail_id($post_id) ? get_post_thumbnail_id($post_id) : false;
                                    $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'full', false) : '';
                                    $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                                    $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
                
                                    // $locations = get_the_terms(get_the_ID(), 'at_biz_dir-location');
                                    // $location_name = $locations && !is_wp_error($locations) ? $locations[0]->name : esc_html__('No location assigned', 'your-text-domain');
                                    $categories = get_the_terms(get_the_ID(), 'at_biz_dir-category');
                                    $category_name = $categories && !is_wp_error($categories) ? $categories[0]->name : esc_html__('No category assigned', 'your-text-domain');
                                    ?> 
                                    <div class="col-md-4 col-sm-6">
                                        <div class="property-item style-two">
                                            <div class="property-item__thumb">
                                                <a href="<?php echo get_the_permalink(); ?>" class="link">
                                                    <img src="<?php echo $img_url; ?>" alt="" class="cover-img">
                                                </a> 
                                            </div>
                                            <div class="property-item__content">
                                                <h6 class="property-item__title">
                                                    <a href="<?php echo get_the_permalink(); ?>" class="link"><?php echo get_the_title(); ?></a>
                                                </h6>
                                                <ul class="amenities-list flx-align">
                                                    <li class="amenities-list__item flx-align">
                                                        <span class="icon text-gradient"><i class="fa fa-bed"></i></span>
                                                        <span class="text">3 Beds</span>
                                                    </li>
                                                    <li class="amenities-list__item flx-align">
                                                        <span class="icon text-gradient"><i class="fa fa-bath"></i></span>
                                                        <span class="text">3 Baths</span>
                                                    </li>
                                                </ul>
                                                <h6 class="property-item__price"> $456.00
                                                    <span class="day">/per day</span> 
                                                </h6>
                                                <p class="property-item__location d-flex gap-2"> 
                                                    <span class="icon text-gradient"> <i class="fa fa-map-marker"></i></span>
                                                    66 Broklyant, New York America
                                                </p>
                                                <a href="<?php echo get_the_permalink(); ?>" class="simple-btn text-gradient fw-semibold font-14">Book Now <span class="icon-right"> <i class="fa fa-arrow-right"></i> </span> </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile;
                                wp_reset_postdata();
                            endif; ?>
                        </div>
                    </div>
                <?php 
                    $i++; } ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Property_Tab_Widget());