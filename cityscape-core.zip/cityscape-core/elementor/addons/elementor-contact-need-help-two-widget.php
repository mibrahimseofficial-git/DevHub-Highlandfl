<?php
/**
 * Elementor Widget
 * @package Cityscape
 * @since 1.0.0
 */

namespace Elementor;
class Cityscape_Contact_Need_Help_Two_Widget extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'cityscape-contact-need-help-two-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Contact Need Help Two', 'cityscape-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-help-o';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['cityscape_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        

        $this->add_control(
            'icon', [
                'label' => esc_html__('Main Image', 'cityscape-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-arrow-right',
                    'library' => 'solid',
                ],
            ]
        );
        $this->add_control(
            'title', [
                'label' => esc_html__('title', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('(Need help?', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'call_number', [
                'label' => esc_html__('Call Number', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('(307) 555-0133', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'call_link', [
                'label' => esc_html__('Call link', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('307555-0133', 'cityscape-core'),
            ]
        );
        $this->add_control(
            'content', [
                'label' => esc_html__('content', 'cityscape-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Real estate is a lucrative ind involves the selling and a reproperties. It encompasses residential', 'cityscape-core'),
            ]
        );
        $this->end_controls_section();


        /*  tab styling tabs start */
        $this->start_controls_section(
            'tab_settings_section',
            [
                'label' => esc_html__('Tab Settings', 'cityscape-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('bg_color', [
            'label' => esc_html__('bg Color', 'cityscape-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                "{{WRAPPER}} .contact-page-wrap.bg-theme" => "background: {{VALUE}} !important"
            ]
        ]);
        $this->end_controls_section();

    }

    /**
     * Render Elementor widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        
        $settings = $this->get_settings_for_display();
        
        ?>
        
        <div class="contact-content__box">
            <div class=" d-flex align-items-center gap-3">
                <div class="contact-content__icon">
                <?php
                    Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']);
                ?>
                </div>
                <div class="contact-content__infos">
                    <span class="contact-content__text"><?php echo $settings['title']; ?></span> 
                    <a href="callto:<?php echo $settings['call_link']; ?>" class="contact-content__contact font-20 fw-semibold text-heading"><?php echo $settings['call_link']; ?></a>
                </div>
            </div>
            <p class="section-heading__desc"><?php echo $settings['content']; ?></p>
        </div>
                        

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Cityscape_Contact_Need_Help_Two_Widget());