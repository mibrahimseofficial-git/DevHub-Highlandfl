(function ($) {
  "use strict";
  /*---------------------------------------------------
      * Initialize all widget js in elementor init hook
      ---------------------------------------------------*/
  $(window).on("elementor/frontend/init", function () {
    // testimonial Slider one
    elementorFrontend.hooks.addAction(
      "frontend/element_ready/cityscape-testimonial-slider-one.default",
      function ($scope) {
        activeTestimonialSliderOne($scope);
      }
    );

    // testimonial Slider two
    elementorFrontend.hooks.addAction(
      "frontend/element_ready/cityscape-testimonial-slider-two.default",
      function ($scope) {
        activeTestimonialSliderTwo($scope);
      }
    );

    // service Slider one
    elementorFrontend.hooks.addAction(
      "frontend/element_ready/cityscape-service-slider-widget.default",
      function ($scope) {
        activeServiceSliderOne($scope);
      }
    );

    // team Slider one
    elementorFrontend.hooks.addAction(
      "frontend/element_ready/cityscape-team-slider-one-widget.default",
      function ($scope) {
        activeTeamSliderOne($scope);
      }
    );

    // team Slider two
    elementorFrontend.hooks.addAction(
      "frontend/element_ready/cityscape-team-slider-two-widget.default",
      function ($scope) {
        activeTeamSliderTwo($scope);
      }
    );

    // blog Slider one
    elementorFrontend.hooks.addAction(
      "frontend/element_ready/cityscape-blog-slider-one-widget.default",
      function ($scope) {
        activeBlogSliderOne($scope);
      }
    );

  });

  // JS for rtl
  var rtlEnable = $("html").attr("dir");
  var SlickRtlValue = !(
    typeof rtlEnable === "undefined" || rtlEnable === "ltr"
  );

  /*----------------------------
        Testimonial Slider One
    * --------------------------*/
  function activeTestimonialSliderOne($scope) {
    var el = $scope.find(".testimonial-slider");
    var elSettings = el.data("settings");
    if (
      el.children("div").length < 2 ||
      elSettings.items === "0" ||
      elSettings.items === "" ||
      typeof elSettings.items == "undefined"
    ) {
      return;
    }

    let $selector = "#" + el.attr("id");

    let sliderSettings = {
      infinite: elSettings.loop === "yes",
      slidesToShow: elSettings.items,
      slidesToScroll: 1,
      arrows: elSettings.nav === "yes",
      dots: elSettings.dot === "yes",
      appendArrows: $scope.find(".slick-carousel-controls .slider-nav"),
      appendDots: $scope.find(".slick-carousel-controls .slider-dots"),
      prevArrow:
        '<div class="prev-arrow testimonial-1-prev-icon slick-prev">' +
        elSettings.navleft +
        "</div>",
      nextArrow:
        '<div class="next-arrow testimonial-1-next-icon slick-next">' +
        elSettings.navright +
        "</div>",
      autoplaySpeed: elSettings.autoplaytimeout,
      autoplay: elSettings.autoplay === "yes",
      centerMode: elSettings.center === "yes",
      centerPadding: "0",
      cssEase: "linear",
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };
    wowSlickInit($selector, sliderSettings);
  }

  /*----------------------------
        Testimonial Slider Two
    * --------------------------*/
  function activeTestimonialSliderTwo($scope) {
    var el = $scope.find(".testimonial-slider");
    var elSettings = el.data("settings");
    if (
      el.children("div").length < 2 ||
      elSettings.items === "0" ||
      elSettings.items === "" ||
      typeof elSettings.items == "undefined"
    ) {
      return;
    }

    let $selector = "#" + el.attr("id");

    let sliderSettings = {
      infinite: elSettings.loop === "yes",
      slidesToShow: elSettings.items,
      slidesToScroll: 1,
      arrows: elSettings.nav === "yes",
      dots: elSettings.dot === "yes",
      appendArrows: $scope.find(".slick-carousel-controls .slider-nav"),
      appendDots: $scope.find(".slick-carousel-controls .slider-dots"),
      prevArrow:
        '<div class="prev-arrow testimonial-1-prev-icon">' +
        elSettings.navleft +
        "</div>",
      nextArrow:
        '<div class="next-arrow testimonial-1-next-icon">' +
        elSettings.navright +
        "</div>",
      autoplaySpeed: elSettings.autoplaytimeout,
      autoplay: elSettings.autoplay === "yes",
      centerMode: elSettings.center === "yes",
      centerPadding: "0",
      cssEase: "linear",
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };
    wowSlickInit($selector, sliderSettings);
  }

  /*----------------------------
        Service Slider One
    * --------------------------*/
  function activeServiceSliderOne($scope) {
    var el = $scope.find(".service-slider2");
    var elSettings = el.data("settings");
    if (
      el.children("div").length < 2 ||
      elSettings.items === "0" ||
      elSettings.items === "" ||
      typeof elSettings.items == "undefined"
    ) {
      return;
    }
    let $selector = "#" + el.attr("id");
    let sliderSettings = {
      infinite: elSettings.loop === "yes",
      slidesToShow: elSettings.items,
      slidesToScroll: 1,
      arrows: elSettings.nav === "yes",
      dots: elSettings.dot === "yes",
      appendArrows: $scope.find(".slick-carousel-controls"),
      appendDots: $scope.find(".slick-carousel-controls"),
      prevArrow: '<div class="prev-arrow">' + elSettings.navleft + "</div>",
      nextArrow: '<div class="next-arrow">' + elSettings.navright + "</div>",
      autoplaySpeed: elSettings.autoplaytimeout,
      autoplay: elSettings.autoplay === "yes",
      centerMode: elSettings.center === "yes",
      centerPadding: "0",
      cssEase: "linear",
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };
    wowSlickInit($selector, sliderSettings);
  }

  /*----------------------------
        Team Slider One
    * --------------------------*/
  function activeTeamSliderOne($scope)  {
    var el = $scope.find(".team-carousel");
    var elSettings = el.data("settings");
    if (
      el.children("div").length < 2 ||
      elSettings.items === "0" ||
      elSettings.items === "" ||
      typeof elSettings.items == "undefined"
    ) {
      return;
    }
    let $selector = "#" + el.attr("id");
    let sliderSettings = {
      infinite: elSettings.loop === "yes",
      slidesToShow: elSettings.items,
      slidesToScroll: 1,
      arrows: elSettings.nav === "yes",
      dots: elSettings.dot === "yes",
      appendArrows: $scope.find(".slick-carousel-controls"),
      appendDots: $scope.find(".slick-carousel-controls"),
      prevArrow: '<div class="prev-arrow">' + elSettings.navleft + "</div>",
      nextArrow: '<div class="next-arrow">' + elSettings.navright + "</div>",
      autoplaySpeed: elSettings.autoplaytimeout,
      autoplay: elSettings.autoplay === "yes",
      centerMode: elSettings.center === "yes",
      centerPadding: "0",
      cssEase: "linear",
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };
    wowSlickInit($selector, sliderSettings);
  }


  /*----------------------------
        Team Slider Two
    * --------------------------*/
  function activeTeamSliderTwo($scope)  {
    var el = $scope.find(".team-slider2");
    var elSettings = el.data("settings");
    if (
      el.children("div").length < 2 ||
      elSettings.items === "0" ||
      elSettings.items === "" ||
      typeof elSettings.items == "undefined"
    ) {
      return;
    }
    let $selector = "#" + el.attr("id");
    let sliderSettings = {
      infinite: elSettings.loop === "yes",
      slidesToShow: elSettings.items,
      slidesToScroll: 1,
      arrows: elSettings.nav === "yes",
      dots: elSettings.dot === "yes",
      appendArrows: $scope.find(".slick-carousel-controls"),
      appendDots: $scope.find(".slick-carousel-controls"),
      prevArrow: '<div class="prev-arrow">' + elSettings.navleft + "</div>",
      nextArrow: '<div class="next-arrow">' + elSettings.navright + "</div>",
      autoplaySpeed: elSettings.autoplaytimeout,
      autoplay: elSettings.autoplay === "yes",
      centerMode: elSettings.center === "yes",
      centerPadding: "0",
      cssEase: "linear",
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };
    wowSlickInit($selector, sliderSettings);
  }

  /*----------------------------
        Blog Slider One
    * --------------------------*/
  function activeBlogSliderOne($scope) {
    var el = $scope.find(".blog-slider");
    var elSettings = el.data("settings");
    if (
      el.children("div").length < 2 ||
      elSettings.items === "0" ||
      elSettings.items === "" ||
      typeof elSettings.items == "undefined"
    ) {
      return;
    }
    let $selector = "#" + el.attr("id");
    let sliderSettings = {
      infinite: elSettings.loop === "yes",
      slidesToShow: elSettings.items,
      slidesToScroll: 1,
      arrows: elSettings.nav === "yes",
      dots: elSettings.dot === "yes",
      appendArrows: $scope.find(".slick-carousel-controls"),
      appendDots: $scope.find(".slick-carousel-controls"),
      prevArrow: '<div class="prev-arrow">' + elSettings.navleft + "</div>",
      nextArrow: '<div class="next-arrow">' + elSettings.navright + "</div>",
      autoplaySpeed: elSettings.autoplaytimeout,
      autoplay: elSettings.autoplay === "yes",
      centerMode: elSettings.center === "yes",
      centerPadding: "0",
      cssEase: "linear",
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
          },
        },
      ],
    };
    wowSlickInit($selector, sliderSettings);
  }

  //slick init function
  function wowSlickInit($selector, settings, animateOut = false) {
    $($selector).slick(settings);
  }




  
  // ========================= Portfolio Slick Slider Js Start ==============
  $('.portfolio-wrapper').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    rtl: $("html").attr("dir") == "rtl" ? true : false,
    autoplaySpeed: 2000,
    speed: 1500,
    dots: false,
    pauseOnHover: true,
    arrows: false,
    centerMode: true,
    prevArrow: '<button type="button" class="slick-prev"><i class="fas fa-long-arrow-alt-left"></i></button>',
    nextArrow: '<button type="button" class="slick-next"><i class="fas fa-long-arrow-alt-right"></i></button>',
    responsive: [
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 2
          }
        },
        {
          breakpoint: 530,
          settings: {
            slidesToShow: 1
          }
        }
      ]
  });

    /*----------- 08. Custom Animaiton For Slider ----------*/
    $('[data-ani-duration]').each(function () {
        var durationTime = $(this).data('ani-duration');
        $(this).css('animation-duration', durationTime);
    });
    
    $('[data-ani-delay]').each(function () {
        var delayTime = $(this).data('ani-delay');
        $(this).css('animation-delay', delayTime);
    });
    
    $('[data-ani]').each(function () {
        var animaionName = $(this).data('ani');
        $(this).addClass(animaionName);
        $('.slick-current [data-ani]').addClass('slider-animated');
    });
    
    $('.global-carousel').on('afterChange', function (event, slick, currentSlide, nextSlide) {
        $(slick.$slides).find('[data-ani]').removeClass('slider-animated');
        $(slick.$slides[currentSlide]).find('[data-ani]').addClass('slider-animated');
    })

  /*------------------------------
        counter section activation
      -------------------------------*/
  function counterupInit($scope) {
    $scope.counterUp({
      delay: 20,
      time: 3000,
    });
  }
    

    // Call On Load
    if ($(".indicator-active").length) {
        $(".indicator-active").indicator();
    }

    /*===========================================
  =         Marquee Active         =
    =============================================*/
    if ($(".marquee_mode").length) {
        $('.marquee_mode').marquee({
            speed: 100,
            gap: 0,
            delayBeforeStart: 0,
            direction: 'left',
            duplicated: true,
            pauseOnHover: true,
            startVisible:true,
        });
    }

    /*----------- 15. Filter ----------*/
    $(".filter-active").imagesLoaded(function () {
        var $filter = ".filter-active",
            $filterItem = ".filter-item",
            $filterMenu = ".filter-menu-active";

        if ($($filter).length > 0) {
            var $grid = $($filter).isotope({
                itemSelector: $filterItem,
                filter: "*",
            });

            // filter items on button click
            $($filterMenu).on("click", "button", function () {
                var filterValue = $(this).attr("data-filter");
                $grid.isotope({
                    filter: filterValue,
                });
            });

            // Menu Active Class
            $($filterMenu).on("click", "button", function (event) {
                event.preventDefault();
                $(this).addClass("active");
                $(this).siblings(".active").removeClass("active");
            });
        }
    });

    $(".masonary-active").imagesLoaded(function () {
        var $filter = ".masonary-active",
            $filterItem = ".filter-item",
            $filterMenu = ".filter-menu-active";

        if ($($filter).length > 0) {
            var $grid = $($filter).isotope({
                itemSelector: $filterItem,
                filter: "*",
                masonry: {
                    // use outer width of grid-sizer for columnWidth
                    columnWidth: 1,
                },
            });

            // filter items on button click
            $($filterMenu).on("click", "button", function () {
                var filterValue = $(this).attr("data-filter");
                $grid.isotope({
                    filter: filterValue,
                });
            });

            // Menu Active Class
            $($filterMenu).on("click", "button", function (event) {
                event.preventDefault();
                $(this).addClass("active");
                $(this).siblings(".active").removeClass("active");
            });
        }
    });

    // Active specifix
    $('.filter-active-cat1').imagesLoaded(function () {
        var $filter = '.filter-active-cat1',
        $filterItem = '.filter-item',
        $filterMenu = '.filter-menu-active';

        if ($($filter).length > 0) {
            var $grid = $($filter).isotope({
                itemSelector: $filterItem,
                filter: '.cat1',
                masonry: {
                // use outer width of grid-sizer for columnWidth
                columnWidth: 1
                }
            });

            // filter items on button click
            $($filterMenu).on('click', 'button', function () {
                var filterValue = $(this).attr('data-filter');
                $grid.isotope({
                filter: filterValue
                });
            });

            // Menu Active Class 
            $($filterMenu).on('click', 'button', function (event) {
                event.preventDefault();
                $(this).addClass('active');
                $(this).siblings('.active').removeClass('active');
            });
        };
    });

  //Odometer
  if ($(".single-counterup-01").length) {
    $(".single-counterup-01").each(function () {
      $(this).isInViewport(function (status) {
        if (status === "entered") {
          for (
            var i = 0;
            i < document.querySelectorAll(".odometer").length;
            i++
          ) {
            var el = document.querySelectorAll(".odometer")[i];
            el.innerHTML = el.getAttribute("data-odometer-final");
          }
        }
      });
    });
  }

  //Masonary Gallery
  var $caseStudyThreeContainer = $(".grid");
  if ($caseStudyThreeContainer.length > 0) {
    $(".grid").imagesLoaded(function () {
      var caseMasonry = $caseStudyThreeContainer.isotope({
        itemSelector: ".grid-item", // use a separate class for itemSelector, other than .col-
        masonry: {
          gutter: 0,
        },
      });
      $(document).on("click", "button", function () {
        var filterValue = $(this).attr("data-filter");
        caseMasonry.isotope({
          filter: filterValue,
        });
      });
    });
    $(document).on("click", "button", function () {
      $(this).siblings().removeClass("active");
      $(this).addClass("active");
    });
  }

  //testimonial
  $('.testimonials-three__wrapper').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    speed: 1500,
    rtl: $("html").attr("dir") == "rtl" ? true : false,
    dots: false,
    pauseOnHover: true,
    arrows: true,
    centerMode: true,
    prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-arrow-left"></i></button>',
    nextArrow: '<button type="button" class="slick-next"><i class="fa fa-arrow-right"></i></button>',
  });

  // ========================== Social List Visibility Js Start =====================
  $(document).on('click', function (event) {
    if (!$(event.target).closest('.social-share').length && !$(event.target).closest('.social-share__button').length) {
      $('.social-share-list').removeClass('active');
      $('.social-share__button').removeClass('active')
    }
  });

  $('.social-share__button').on('click', function () {
    $('.social-share__button').not($(this)).removeClass('active')
    $(this).toggleClass('active')
    $('.social-share-list').not($(this).siblings('.social-share-list')).removeClass('active');
    $(this).siblings('.social-share-list').toggleClass('active');
  });

  $(document).ready(function () {
    /*--------------------
          wow js init
      ---------------------*/
    new WOW().init();

    /*---------------------------------
     * Magnific Popup
     * --------------------------------*/
    $(
      ".video-play-btn, .video-play-btn-02, .video-play-btn-hover, .play-video-btn, .button-video, .video-popup__button"
    ).magnificPopup({
      type: "video",
      removalDelay: 400,
      preloader: false,
    });

    // ============== Magnific Popup Js Start =======================
    $('.popup-video-link').magnificPopup({
      type: 'iframe'
    });
    $('.gallery-popup').magnificPopup({
      type: 'image',
      gallery:{
        enabled:true
      }
    });

    // ========================= Testimonial Slick Slider Js Start ==============
    $('.testimonial-box').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      rtl: $("html").attr("dir") == "rtl" ? true : false,
      autoplaySpeed: 2000,
      speed: 1500,
      dots: false,
      pauseOnHover: true,
      arrows: true,
      fade: true,
      draggable: true,
      speed: 900,
      infinite: true,
      prevArrow: '<button type="button" class="slick-prev"><i class="fa fa-arrow-left"></i></button>',
      nextArrow: '<button type="button" class="slick-next"><i class="fa fa-arrow-right"></i></button>',
    });
    
  });
})(jQuery);